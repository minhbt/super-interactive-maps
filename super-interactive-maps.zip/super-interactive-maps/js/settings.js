/**.
**super interactive map js admin js code**
.**/
jQuery(document).ready(function(jQuery) {
	var onMapSelect = function(e) {
	jQuery('#sim_interactive_map').html('');
	var content = jQuery('#chosenSelectBox .chosen-select').find('option:selected').val();
	var sim_fg_color = [];
	var ivalue = new Array();
	var colorsmap=jQuery('#sim_wp_border_color').val();
	var sim_bg_color=jQuery('#sim_wp_bg_color').val();
	if(colorsmap==''){ colorsmap='#ffffff'; } 
	if(sim_bg_color==''){ sim_bg_color='#1e73be'; }
	content = content ? decodeURIComponent(content) : '';
	var content = content.split(",");
	var region = content[0]; 
	var resolution = content[1];
	var data = new google.visualization.DataTable();
	var display=jQuery('#sim_wp_map_region').val();
	var ttooltip='';
	var MaxValue=0;
	var width = null;
	var	height = null;
	
	if(display != "regions" && mapDataCount.length>0) {
	 data.addColumn('number', 'Lat');                                
	 data.addColumn('number', 'Long');
	}
	data.addColumn('string', 'Country'); // Implicit domain label col.
	data.addColumn('number', 'Value'); // Implicit series 1 data col.
	data.addColumn({type:'string', role: 'tooltip', p:{html:true}}); 
	 if(mapDataCount.length>0){       
			for (var key in superIntArray) {
			var ttitle = superIntArray[key]['sim_wpd_title'];
			var location = superIntArray[key]['sim_wpd_locations'];
			var dataColor = superIntArray[key]['sim_color_box'];
			var latLong=superIntArray[key]['sim_wpd_search_id'];
			var sim_url=superIntArray[key]['sim_wpd_url'];
			if(sim_url!='' && sim_url!='undefined'){ 
			  var index = location;
			}
			
			if(display == "regions") {
				data.addRows([[{v:location,f:ttitle},MaxValue,ttooltip]]);
				
			}
			else {
			var latlon = latLong.split(/ /);
			var lon = parseFloat(latlon[0]);
			var lat = parseFloat(latlon[1]);
			if(sim_url!='' && sim_url!='undefined'){ 
				var index = lat;
			}
			data.addRows([[lat,lon,ttitle,MaxValue,ttooltip]]);		
			}
			sim_fg_color.push(dataColor);
			MaxValue++;
			}
			if(sim_url!='' && sim_url!='undefined'){ 
				ivalue[index] = sim_url;
				ivalue.push(ivalue);
			}
	}		
			defmaxvalue=0;			
			if(MaxValue-1>0){
				defmaxvalue=MaxValue-1;
			}
	   		 var options = { 
					region:region,
					displayMode: display,
					backgroundColor:sim_bg_color, 
					colorAxis:  {minValue: 0, maxValue: defmaxvalue,  colors: sim_fg_color},
					sizeAxis: {minValue: 1, maxValue:1,minSize:sim_markersize,  maxSize: sim_markersize},
					enableRegionInteractivity:'true',
					datalessRegionColor: colorsmap,
					width:width,
			        height:height,
					resolution: resolution,
					legend: 'none'
				};
				var chart = new google.visualization.GeoChart(document.getElementById('sim_interactive_map'));
				var sim_img_field = document.getElementById('sim_wp_mapimage');
					google.visualization.events.addListener(chart, 'ready', function () {
					sim_img_field.value = chart.getImageURI();
				});
				
				google.visualization.events.addListener(chart, 'select', function() {
						var selection = chart.getSelection();
						if (selection.length == 1 && selection[0].row!=0) {
							var selectedRow = selection[0].row;
							var selectedRegion = data.getValue(selectedRow, 0);
							if(ivalue[selectedRegion] != "" && ivalue[selectedRegion] != undefined) { alert(ivalue[selectedRegion]); }
							}
				});

				chart.draw(data, options);
            };
           

	var updateFunction=function(e){
                 jQuery('.add_edit_loc_link').click(editMapData);
				 jQuery('.add_del_loc_link').click(deleteMapData);
				 jQuery('.edit_del_loc_link').click(deleteEditMapData);
				 jQuery('#editIdValue').val('');
				 onMapSelect();
				 setcustomcss();
				 jQuery('#sim-control-box').show();
				 //simMapEffect();

	}		

var simMapEffect= function(e){

	var marginhorizontal = document.getElementById('sim_wp_left').value; 
	var marginvertical = document.getElementById('sim_wp_top').value;  
	var percentagesize = document.getElementById('sim_wp_zoom').value; 
	var hsize = document.getElementById('sim_wp_map_heights').value; 

	//to create styles for preview
		var mapstyle = document.getElementById("sim_interactive_map").style;

		//zoom effect
		if(marginhorizontal!='') { mapstyle.marginLeft = marginhorizontal+"%"; } else { mapstyle.marginLeft = '0%'}
		if(marginvertical!='') { mapstyle.marginTop = marginvertical+"%"; } else { mapstyle.marginTop = '0%'}
		if(percentagesize!='') { mapstyle.width = percentagesize+"%"; 
		 mapstyle.height = percentagesize+"%"; } else { mapstyle.width = '100%'; mapstyle.height = '100%'}	
		 onMapSelect();
	}
	
//add location code here 
var saveLocationData = function(e) {
    var mapid=parseInt(jQuery('#numberofmap').val())+1;
	jQuery('#numberofmap').val(mapid);
	var location = document.form.sim_search_location.value,
	location2=document.form.sim_search_location_select.value,
	title = document.form.ssf_wp_title.value,
	display_mode_ver = document.form.sim_wp_display_mode.value,
	sim_wp_url = document.form.sim_wp_url.value,
	ssf_wp_search_id = document.form.ssf_wp_search_id.value,
	sim_wpd_boxsearch=document.form.sim_wpd_boxsearch.value;
	var display_mode='';
	if(location == "") {
	 location=location2;
	}else{
	location=location;
	}
	var ssf_wp_data_color=jQuery('#ssf_wp_data_color').val();
	if(display_mode_ver=='1'){ display_mode='Link to existing window'; } 
	else if(display_mode_ver=='2'){ display_mode='Link to new window'; } else if(display_mode_ver=='4' || display_mode_ver=='5'){ display_mode='Link to Super Store Finder'; } else{
	display_mode='Pop up information';
	}
	if(location==''){
		alert('Please enter location');
		return false;
	}else if(title==''){
		alert('Please enter title');
		return false;
	}
	var discription = jQuery('#sim_wp_html_discription').val();
	var information= jQuery('#sim_wp_display_mode2 .nicEdit-main').html();
	var mapids=jQuery('#editIdValue').val();
	var mapIntid;
	var discriptionshow = discription.substr(0, 100);
	//update codes 
	if(mapids!='' && mapids!=undefined){
	mapIntid=mapids;
		if(jQuery('#sim_wp_map_region').val() == "text") {
		var markercls='marker';
		}else{
		var markercls='';
		}
	jQuery('#sim_row_'+mapids).html('<td>'+location+'</td><td><span class="'+markercls+'">'+title+'</span></td><td>'+discriptionshow+'</td><td>'+display_mode+'</td><td><div class="sim_color_box" id="sim_color_box'+mapids+'"></div></td><td><a class="edit_loc_link add_edit_loc_link" id="'+mapids+'"><span class="fa fa-pencil">&nbsp;</span>Edit</a>&nbsp; | <a class="add_del_loc_link del_loc_link" id="'+mapids+'"><span class="fa fa-trash">&nbsp;</span>Delete</a></td>');
	jQuery("#sim_color_box"+mapids).css("background-color", ssf_wp_data_color);
    document.getElementById("sim-contact-form").reset();	
	jQuery('#sim_wp_display_mode2').css('display','none');
	jQuery('#sim_wp_display_mode3').css('display','none');
	var str_discription=discription;
	var str_information=escape(information);
	var upValues=superIntArray.filter(function(v){ return v["id"] == mapIntid; });
					upValues[0].id= mapIntid;
					upValues[0].sim_wpd_search_id= ssf_wp_search_id;
					upValues[0].sim_wpd_locations= location;
					upValues[0].sim_wpd_title=  title;
					upValues[0].sim_wpd_description= discription;
					upValues[0].sim_wpd_call_to_action= display_mode_ver;
					upValues[0].sim_color_box= ssf_wp_data_color;
					upValues[0].sim_wpd_url= sim_wp_url;
					upValues[0].sim_wpd_information= information;
					upValues[0].sim_wpd_boxsearch= sim_wpd_boxsearch;

	}else{
	//add codes 
	mapIntid=mapid;
	mapDataCount.push(mapid);
	jQuery('#sim_map_record').append('<tr id="sim_row_'+mapid+'"><td>'+location+'</td><td><span class="'+markercls+'">'+title+'</span></td><td>'+discriptionshow+'</td><td>'+display_mode+'</td><td><div class="sim_color_box" id="sim_color_box'+mapid+'"></div></td><td><a class="edit_loc_link add_edit_loc_link" id="'+mapid+'"><span class="fa fa-pencil">&nbsp;</span>Edit</a>&nbsp; | <a class="add_del_loc_link del_loc_link" id="'+mapid+'"><span class="fa fa-trash">&nbsp;</span>Delete</a></td></tr>');
	jQuery("#sim_color_box"+mapid).css("background-color", ssf_wp_data_color);
    document.getElementById("sim-contact-form").reset();	
	jQuery('#sim_wp_display_mode2').css('display','none');
	jQuery('#sim_wp_display_mode3').css('display','none');
	//update values
	var str_discription=discription;
	var str_information=escape(information);
	superIntArray.push({
            id: mapIntid, 
            sim_wpd_search_id: ssf_wp_search_id,
			sim_wpd_locations: location,
			sim_wpd_title: title,
			sim_wpd_description: str_discription,
			sim_wpd_call_to_action: display_mode_ver,
			sim_color_box: ssf_wp_data_color,
			sim_wpd_url: sim_wp_url,
			sim_wpd_information: str_information,
			sim_wpd_boxsearch: sim_wpd_boxsearch,
        });
	}
	var dataIntMaps=JSON.stringify(superIntArray);
	jQuery('#intMapObj').val(dataIntMaps);
	hideDataPopup();
	updateFunction();
}	


/*.* edit map pop-up data *.*/ 
var editMapData = function() {
    var a=this.id;
	var editValues=superIntArray.filter(function(v){ return v["id"] == a; });
	if(jQuery('#sim_wp_map_region').val() == "regions") {
	jQuery('#sim_search_location').val(editValues[0]['sim_wpd_locations']);
	var location_select=editValues[0]['sim_wpd_locations'];
	jQuery('#sim_search_location_select option[value="'+location_select+'"]').attr('selected', true);
	 jQuery('#sim_search_location_select').trigger("chosen:updated");
	}else{
	jQuery('#sim_search_location').val(editValues[0]['sim_wpd_locations']);
	}
	var str_discription=editValues[0]['sim_wpd_description'];
	var str_information=decodeURIComponent(editValues[0]['sim_wpd_information']);
	str_information=unescape(str_information);
	jQuery('#editIdValue').val(a);   
	jQuery('#ssf_wp_title').val(editValues[0]['sim_wpd_title']);
	jQuery('#sim_wp_html_discription').val(str_discription);
	jQuery('#sim_wp_display_mode option[value="'+editValues[0]['sim_wpd_call_to_action']+'"]').attr('selected', true);
	jQuery('#sim_wp_display_mode').val(editValues[0]['sim_wpd_call_to_action']);
	jQuery('#sim_wp_url').val(editValues[0]['sim_wpd_url']);
	if(str_information!=''){ 
	jQuery('#sim_wp_display_mode2 .nicEdit-main').html(str_information); }
	//jQuery('#sim_wp_information').val(str_information);
	//alert(str_information);
	jQuery('#sim_wpd_boxsearch').val(editValues[0]['sim_wpd_boxsearch']);
	jQuery('#ssf_wp_data_color').val(editValues[0]['sim_color_box']);	
	jQuery('#RegionMarkercolor .wp-color-result').css("background-color", editValues[0]['sim_color_box']);
	var changeVal=editValues[0]['sim_wpd_call_to_action'];
	if(changeVal=='1' || changeVal=='2'){
	  jQuery('#sim_wp_display_mode2').css('display','none');
	  jQuery('#sim_wp_display_mode1').css('display','inline-block');
	  jQuery('#sim_wp_display_mode3').css('display','none');
	}
	else if(changeVal=='4' || changeVal=='5'){
	  jQuery('#sim_wp_display_mode2').css('display','none');
	  jQuery('#sim_wp_display_mode1').css('display','inline-block');
	  jQuery('#sim_wp_display_mode3').css('display','inline-block');
	}
	
	else{
	  jQuery('#sim_wp_display_mode1').css('display','none');
	  jQuery('#sim_wp_display_mode3').css('display','none');
	  jQuery('#sim_wp_display_mode2').css('display','inline-block');
	}	
	showDataPopup();
}

/*.* delete map pop-up data *.*/ 
var deleteMapData = function(e) {
var a=this.id;
if(jQuery('#sim_row_'+a).length){
var b= confirm("Are you sure you wish to remove");
		if(b){
		var mapid=parseInt(jQuery('#numberofmap').val())-1;
		jQuery('#numberofmap').val(mapid);
		jQuery('#sim_row_'+a).remove();
		var editValues=superIntArray.filter(function(v){ return v["id"] == b; });
		
		for(var key in superIntArray)
		{
			if(superIntArray[key]['id']==a){
			superIntArray.splice(key, 1);
			}
		}
		var index = mapDataCount.indexOf(a);
		if (index > -1) {
			mapDataCount.splice(index, 1);
		}
		jQuery('#intMapObj').val(JSON.stringify(superIntArray));
		onMapSelect();
	}
	}
}	

//function deleteEditMapData(a){
var deleteEditMapData = function(e) {
var a=this.id;
if(jQuery('#sim_row_'+a).length){
var  b= confirm("Are you sure you wish to remove");
        if(b){
		 jQuery.ajax({
		  type: 'POST',
		  data: {deleteid:a},
		  url: sim_wp_base+'/sim-wp-admin/pages/updateData.php',
		  dataType:'json',
		  success: function(data, textStatus, XMLHttpRequest){
			jQuery('#sim_row_'+a).remove();
 		  },
		  error: function(MLHttpRequest, textStatus, errorThrown){
			  jQuery('#sim_row_'+a).remove();
		  }
		  });
		  var index = mapDataCount.indexOf(a);
			if (index > -1) {
				mapDataCount.splice(index, 1);
			}
			for(var key in superIntArray)
		{
			if(superIntArray[key]['id']==a){
			superIntArray.splice(key, 1);
			}
		}
		onMapSelect();
	}
  }
}	

var updateLocationData = function(e) {
	var mapid=jQuery('#editIdValue').val();
	var mapDataId=jQuery('#mapDataId').val();
	var location = document.form.sim_search_location.value,
	location2=document.form.sim_search_location_select.value,
	title = document.form.ssf_wp_title.value,
	display_mode_ver = document.form.sim_wp_display_mode.value,
	sim_wp_url = document.form.sim_wp_url.value,
	ssf_wp_search_id = document.form.ssf_wp_search_id.value,
	sim_wpd_boxsearch=document.form.sim_wpd_boxsearch.value;
	var display_mode='';
	var ssf_wp_data_color=jQuery('#ssf_wp_data_color').val();
	if(location == "") {
	 location=location2;
	}else{
	location=location;
	}
	if(display_mode_ver=='1'){ display_mode='Link to existing window'; } 
	else if(display_mode_ver=='2') { display_mode='Link to new window'; }else if(display_mode_ver=='4' || display_mode_ver=='5'){ display_mode='Link to Super Store Finder'; } else{
	display_mode='Pop up information';
	}
	if(location==''){
		alert('Please enter location');
		return false;
	}else if(title==''){
		alert('Please enter title');
		return false;
	}
	var discription = jQuery('#sim_wp_html_discription').val();;
    var information= jQuery('#sim_wp_display_mode2 .nicEdit-main').html();

	var str_information=escape(information);
	var str_information=encodeURIComponent(str_information);
	var str_discription=discription;
	var discriptionshow = discription.substr(0, 100);
	if(jQuery('#sim_wp_map_region').val() == "text") {
		var markercls='marker';
		}else{
		var markercls='';
		}
	if(mapid==''){
	 jQuery.ajax({
		  type: 'POST',
		  dataType:'json',
		  data: {simaction:'insert',sim_wpd_locations:location,sim_wpd_title:title,sim_wpd_description:str_discription,sim_wpd_call_to_action:display_mode_ver,sim_wpd_url:sim_wp_url,sim_wpd_information:str_information,sim_wpd_data_id:mapDataId,sim_wpd_data_color:ssf_wp_data_color,sim_wpd_search_id:ssf_wp_search_id,sim_wpd_boxsearch:sim_wpd_boxsearch} ,
		  url: sim_wp_base+'/sim-wp-admin/pages/updateData.php',
		  success: function(data, textStatus, XMLHttpRequest){
				mapid=data;	
				jQuery('#sim_map_record').append('<tr id="sim_row_'+mapid+'"><td>'+location+'</td><td><span class="'+markercls+'">'+title+'</span></td><td>'+discriptionshow+'</td><td>'+display_mode+'</td><td><div class="sim_color_box" id="sim_color_box'+mapid+'"></div></td><td><a class="edit_loc_link add_edit_loc_link" id="'+mapid+'"><span class="fa fa-pencil">&nbsp;</span>Edit</a>&nbsp; | <a class="edit_del_loc_link" id="'+mapid+'"><span class="fa fa-trash">&nbsp;</span>Delete</a></td></tr>')
				jQuery("#sim_color_box"+mapid).css("background-color", ssf_wp_data_color);
				mapDataCount.push(mapid);
				document.getElementById("sim-contact-form").reset();
				superIntArray.push({
					id: mapid, 
					sim_wpd_search_id: ssf_wp_search_id,
					sim_wpd_locations: location,
					sim_wpd_title: title,
					sim_wpd_description: discription,
					sim_wpd_call_to_action: display_mode_ver,
					sim_color_box: ssf_wp_data_color,
					sim_wpd_url: sim_wp_url,
					sim_wpd_information: information,
					sim_wpd_boxsearch: sim_wpd_boxsearch,
				});
				hideDataPopup();
				updateFunction();
			  },
			  error: function(MLHttpRequest, textStatus, errorThrown){
			  }
			});
		}
		  else{
		   jQuery.ajax({
		  type: 'POST',
		  dataType:'json',
		  data: {simaction:'update',id:mapid,sim_wpd_locations:location,sim_wpd_title:title,sim_wpd_description:str_discription,sim_wpd_call_to_action:display_mode_ver,sim_wpd_url:sim_wp_url,sim_wpd_information:str_information,sim_wpd_data_id:mapDataId,sim_wpd_data_color:ssf_wp_data_color,sim_wpd_search_id:ssf_wp_search_id,sim_wpd_boxsearch:sim_wpd_boxsearch} ,
		  contentType: 'application/x-www-form-urlencoded;charset=UTF-8',
		  url: sim_wp_base+'/sim-wp-admin/pages/updateData.php',
		  success: function(data, textStatus, XMLHttpRequest){
            mapid=data;
			jQuery('#sim_row_'+mapid).html('<td>'+location+'</td><td><span class="'+markercls+'">'+title+'</span></td><td>'+discriptionshow+'</td><td>'+display_mode+'</td><td><div class="sim_color_box" id="sim_color_box'+mapid+'"></div></td><td><a class="add_edit_loc_link edit_loc_link" id="'+mapid+'"><span class="fa fa-pencil">&nbsp;</span>Edit</a>&nbsp; | <a class="edit_del_loc_link" id="'+mapid+'"><span class="fa fa-trash">&nbsp;</span>Delete</a></td>');
			jQuery("#sim_color_box"+mapid).css("background-color", ssf_wp_data_color);
			 document.getElementById("sim-contact-form").reset();	
			 var upValues=superIntArray.filter(function(v){ return v["id"] == mapid; });
					upValues[0].id= mapid;
					upValues[0].sim_wpd_search_id= ssf_wp_search_id;
					upValues[0].sim_wpd_locations= location;
					upValues[0].sim_wpd_title=  title;
					upValues[0].sim_wpd_description= discription;
					upValues[0].sim_wpd_call_to_action= display_mode_ver;
					upValues[0].sim_color_box= ssf_wp_data_color;
					upValues[0].sim_wpd_url= sim_wp_url;
					upValues[0].sim_wpd_information= information;
					upValues[0].sim_wpd_boxsearch= sim_wpd_boxsearch;
			 hideDataPopup();
			 updateFunction();
 		  },
		  error: function(MLHttpRequest, textStatus, errorThrown){
		  console.log(errorThrown);
		  }
		  });
		  		  
		  }

}	


//*.*pop data mpdel code here *.*//
var showDataPopup = function(e) {
jQuery('#sim-control-box').hide();
jQuery('#mainPopupContat, #modernBrowserConatct').addClass('is-shown'); 
	jQuery('#sim_search_location_select_chosen').css('display','none');
	jQuery('#sim_search_location').css('display','inline-block');
	jQuery('#enterlRegions').css('display','none');
	jQuery('#generalRegionList').css('display','inline-block');

jQuery('#sim_wp_display_mode').on('change', function () {
	var changeVal = jQuery(this).val();
	if(changeVal=='1' || changeVal=='2'){
	  jQuery('#sim_wp_display_mode2').css('display','none');
	  jQuery('#sim_wp_display_mode1').css('display','inline-block');
	  jQuery('#sim_wp_display_mode3').css('display','none');
	  jQuery('#superStoreLearnn').css('display','none');
	}
	else if(changeVal=='4' || changeVal=='5'){
	  jQuery('#sim_wp_display_mode2').css('display','none');
	  jQuery('#sim_wp_display_mode1').css('display','inline-block');
	  jQuery('#sim_wp_display_mode3').css('display','inline-block');
	  jQuery('#superStoreLearnn').css('display','inline-block');
	  
	}
	
	else{
	  jQuery('#sim_wp_display_mode1').css('display','none');
	  jQuery('#sim_wp_display_mode3').css('display','none');
	  jQuery('#sim_wp_display_mode2').css('display','inline-block');
	  jQuery('#superStoreLearnn').css('display','none');
	}
		
});
jQuery('#generalRegionList').on('click', function () {
	jQuery('#sim_search_location_select_chosen').css('display','inline-block');
	jQuery('#sim_search_location').val('');
	jQuery('#sim_search_location').css('display','none');
	jQuery('#enterlRegions').css('display','inline-block');
	jQuery('#generalRegionList').css('display','none');
	var region='';
	var address=jQuery('#sim_search_location_select').val();
	get_coordinate(address,region);
});
jQuery('#enterlRegions').on('click', function () {
	jQuery('#sim_search_location_select_chosen').css('display','none');
	jQuery('#sim_search_location').css('display','inline-block');
	jQuery('#generalRegionList').css('display','inline-block');
	jQuery('#enterlRegions').css('display','none');
});


var address=jQuery('#sim_search_location').val();
var region='';
get_coordinate(address,region);
	
google.maps.event.trigger(map, 'resize');

}
var hideDataPopup = function(e) {
 jQuery('#mainPopupContat, #modernBrowserConatct').removeClass('is-shown');
 jQuery('#sim-control-box').show();
 } 
 
/**.** 	map zoom effect **.**/
jQuery('#sim-control-box a').on('click', function () {
    var control=this.id;
	if(control=="widthplus") {
		document.getElementById('sim_wp_zoom').value = (parseInt(document.getElementById('sim_wp_zoom').value) || 100)+5;
	}
	if(control=="widthminus") {
		document.getElementById('sim_wp_zoom').value = (parseInt(document.getElementById('sim_wp_zoom').value) || 100)-5;
	}
	if(control=="up") {
		document.getElementById('sim_wp_top').value = (parseInt(document.getElementById('sim_wp_top').value) || 0)-5;
	}
	if(control=="down") {
		document.getElementById('sim_wp_top').value = (parseInt(document.getElementById('sim_wp_top').value) || 0)+5;
	}
	if(control=="left") {
		document.getElementById('sim_wp_left').value = (parseInt(document.getElementById('sim_wp_left').value) || 0)-5;
	}
	if(control=="right") {
		document.getElementById('sim_wp_left').value = (parseInt(document.getElementById('sim_wp_left').value) || 0)+5;
	}
	if(control=="verticalplus") {
		document.getElementById('sim_wp_map_heights').value = (parseInt(document.getElementById('sim_wp_map_heights').value) || 62)+5;
	}
	if(control=="verticalminus") {
		document.getElementById('sim_wp_map_heights').value = (parseInt(document.getElementById('sim_wp_map_heights').value) || 62)-5;
	}
	if(control=="clearzoom"){
	 clearZoomValues();
	}else{
	  simMapEffect();
	}
	}
);
var clearZoomValues=function() {

	document.getElementById('sim_wp_zoom').value = '';
	document.getElementById('sim_wp_top').value = '';
	document.getElementById('sim_wp_left').value = '';
	document.getElementById('sim_wp_map_heights').value = '';
	simMapEffect();

}

function setcustomcss() {


	//Since this only runs once, we take advantage of this function to also add temp css rules:

		//styles with advanced selectors, we need to add them to the css file
		var tempcss = document.styleSheets[0];

		//height
		tempcss.insertRule('#visualization-wrap-responsive:after {}', 0);

		//hover effect
		tempcss.insertRule('#sim_interactive_map path:not([fill^="#f5f5f5"]):hover {}', 0);
		tempcss.insertRule('#sim_interactive_map circle:hover {}', 0);

		//hand cursor
		tempcss.insertRule('#sim_interactive_map path:not([fill^="#f5f5f5"]):hover {}', 0);
		tempcss.insertRule('#sim_interactive_map circle:hover { }', 0);
		tempcss.insertRule('#sim_interactive_map text:hover { }', 0);

		//borders colour
		tempcss.insertRule('#sim_interactive_map path { }', 0);
		tempcss.insertRule('#sim_interactive_map path { }', 0);
		tempcss.insertRule('#sim_interactive_map path { }', 0);
		tempcss.insertRule('#sim_interactive_map path { }', 0);

		//Tooltip
		tempcss.insertRule('#sim_interactive_map .google-visualization-tooltip {}', 0);
		tempcss.insertRule('#sim_interactive_map .google-visualization-tooltip {}', 0);
		tempcss.insertRule('#sim_interactive_map .google-visualization-tooltip {}', 0);
		tempcss.insertRule('#sim_interactive_map .google-visualization-tooltip {}', 0);
		tempcss.insertRule('#sim_interactive_map .google-visualization-tooltip {}', 0);
		tempcss.insertRule('#sim_interactive_map .google-visualization-tooltip {}', 0);
		tempcss.insertRule('#sim_interactive_map .google-visualization-tooltip {}', 0);
		

		//end temp css rules


	simMapEffect();
	

}

/**.** 	map zoom effect **.**/



//*.* html editor code *.*//
bkLib.onDomLoaded(function() { new nicEditor({fullPanel : true}).panelInstance('sim_wp_information'); });
//*.* end html editor code *.*//


//*.* Event handler script *.*//

jQuery('.hideDataModel').click(hideDataPopup);
jQuery('#editOpenDataModel').click(updateLocationData);
jQuery('#add-location-submit').click(saveLocationData);

jQuery('#openDataModel').on('click', function () {
jQuery('#editIdValue').val('');
 showDataPopup();
jQuery('#sim_wp_display_mode2 .nicEdit-main').html('');
jQuery('#RegionMarkercolor .wp-color-result').css("background-color", marker_map_color);
jQuery('#ssf_wp_data_color').val(marker_map_color);

});

jQuery('#chosenSelectBox .chosen-select').chosen().change(onMapSelect);
jQuery('.chosen-select').chosen();
jQuery('#sim_wp_map_region').on('change', function () {
	var changeVal = jQuery(this).val();
	if(changeVal!='regions'){
	    jQuery('#sim_wp_marker_show').css('display','inline-block');
	  }else{
	    jQuery('#sim_wp_marker_show').css('display','none');
	  }
	onMapSelect();
	});


var options = {packages: ['geochart'], callback : updateFunction};
google.load('visualization', 1, options);	   
var myOptionss = {
	change: function(event, ui){  setTimeout(
	function() { onMapSelect(); }, 1000);  },
	clear: function() { setTimeout(
	function() { onMapSelect(); }, 1000); },
};
 jQuery('.my-color-field').wpColorPicker(myOptionss);

//*.* End Event handler script *.*//	   
 }); 
 
 