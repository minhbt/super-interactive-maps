// JavaScript Document
/*Open Close hour and email script */
jQuery(".goo-collapsible > li > a").on("click", function(e){
	if(!jQuery(this).hasClass("active")) {
		jQuery(".goo-collapsible li ul").slideUp(350);
		jQuery(".goo-collapsible li a").removeClass("active");
      
		jQuery(this).next("ul").slideDown(350);
		jQuery(this).addClass("active");
		jQuery(this).next("span").addClass("icon-minus");
		
		
	}else if(jQuery(this).hasClass("active")) {
		
		jQuery(this).removeClass("active");
		jQuery(this).next("ul").slideUp(350);
	}
	if (jQuery('#hourCollapse').hasClass('icon-minus') )
	{
		jQuery('#hourCollapse').removeClass('icon-minus');
		jQuery('#hourCollapse').addClass('icon-plus');
	}
	else{
		jQuery('#hourCollapse').removeClass('icon-plus');
		jQuery('#hourCollapse').addClass('icon-minus');
		
	}
});


function SendMail(rcvEmail)
{
	var emailRegex = /^[A-Za-z0-9._]*\@[A-Za-z]*\.[A-Za-z]{2,5}$/;
	var name = document.form.sim_cont_name.value,
	email = document.form.sim_cont_email.value,
	phone = document.form.sim_cont_phone.value,
	message = document.form.sim_cont_msg.value;
	var storename =jQuery('#storeLocatorInfobox .store-location').html();
	
		if(name == "" )
		{
			document.form.sim_cont_name.focus() ;
			document.getElementById("sim-msg-status").innerHTML = "<span style='color:red;'>Please enter your "+sim_cont_us_name+"</span>"
			return false;
		}
		if(email == "" )
		{
			document.form.sim_cont_email.focus() ;
			document.getElementById("sim-msg-status").innerHTML = "<span style='color:red;'>Please enter your "+sim_cont_us_email+"</span>";
			return false;
		}
		else if(!emailRegex.test(email)){
		  document.form.sim_cont_email.focus();
		  document.getElementById("sim-msg-status").innerHTML = "<span style='color:red;'>Please enter an correct "+sim_cont_us_email+" </span>";
		  return false;
		  }
		if(message == "" )
		{
			document.form.sim_cont_msg.focus() ;
			document.getElementById("sim-msg-status").innerHTML = "<span style='color:red;'>Please enter your "+sim_cont_us_msg+"  </span>";
			return false;
		}
	   jQuery.ajax
		({
		type: "POST",
		url: sim_wp_base + '/sendMail.php?t='+d.getTime(),
		data: {name: name, email: email, phone: phone, message:message, rcvEmail: rcvEmail,subject: storename},
		cache: false,
		success: function (html)
		{
			 document.getElementById("sim-contact-form").reset();
			 document.getElementById("sim-msg-status").innerHTML = "<span style='color:green;' id='imageMsgAlert'>"+sim_msg_sucess+"</span>";
			 jQuery('#imageMsgAlert').fadeOut(5000);
		}
	});
}