/**.
** super interactive map js front end js code**
** Last Update : 17:01:2018
.**/
	var display='regions';
	var ttooltip='';
	var region='world';
	var resolution='countries';
	var sim_bg_color='#f5f5f5';
	var colorsmap='#ffffff';
	var simMapResize = [];
	var chart = [];
	var SimMapData = [];
	var SimMapOptions = [];
	//google.charts.load('current', {packages:['geochart']});
	google.charts.load('42', {packages:['geochart']});
	google.charts.setOnLoadCallback(super_intmap);
	var windowWidth = jQuery(window).width();
	
	
	function super_intmap() {
		for (var key in superintermap) {
			if(superintermap[key]['map_zoom']=='true') {
				super_map_zoom(superintermap[key]['id'],'bottom-left',false);
			}
		}
		onMapSelect();
	}
	
	function onMapSelect(skipNotVisible){
			var data = {};
			var values = {};
			var markersizeval;
	        for (var key in superintermap) {
			var simMapId=parseInt(superintermap[key]['id']);	
			if (skipNotVisible && simMapResize[simMapId] && !simMapResize[simMapId].div.is(':visible')) {
                continue;
            }
			var action='none';
			var sim_fg_color = [];
			var MaxValue=0;
					
					var content = superintermap[key]['content'];
					var colorsmap=superintermap[key]['colorsmap'];
					var sim_bg_color=superintermap[key]['sim_bg_color'];
					var placestxt =  superintermap[key]['placestxt']; 
					
					var display=superintermap[key]['display'];
					var markersize=parseInt(superintermap[key]['markersize']);
					var hideTitle=superintermap[key]['hideTitle'];
					var height=parseInt(superintermap[key]['sim_wp_height']);
					var width=parseInt(superintermap[key]['sim_wp_width']);
					var aspectratio=superintermap[key]['sim_wp_aspect_ratio'];
					if(markersize!=''){ markersizeval=markersize;  } else { markersizeval=parseInt(sim_markersize); }
					placestxt = placestxt.replace(/^\s+|\s+$/g,'');
					var places = placestxt.split("@;@");
					
					if(colorsmap==''){ colorsmap='#ffffff'; } 
					if(sim_bg_color==''){ sim_bg_color='#f5f5f5'; }
					content = content ? decodeURIComponent(content) : '';
					content = content.split("&#44;");
					region = content[0]; 
					resolution = content[1];
					data[simMapId] = new google.visualization.DataTable();
					if(display != "regions") {
					 data[simMapId].addColumn('number', 'Lat');                                
					 data[simMapId].addColumn('number', 'Long');
					}
					
					data[simMapId].addColumn('string', 'Country'); 
					data[simMapId].addColumn('number', 'Value');
					data[simMapId].addColumn({type:'string', role: 'tooltip', p:{html:true}});
						//locations code here 
						values[simMapId] = {};
						for (var i = 0; i < places.length-1; i++) {
							var entry = places[i].split("::");
							var ttooltip='';
									var ttitle = entry[1];
									var location = entry[2];
									var dataColor = entry[3];
									var latLong=entry[4];
									var sim_url_val=entry[5];
									sim_information=decodeURIComponent(entry[6]);
									sim_information=unescape(sim_information);
									var sim_wpd_description=entry[7];
									var sim_wpd_boxsearch=entry[8];
									var sim_url_action=entry[9];
						
							if((sim_url_val!='' && sim_url_val!='undefined') || (sim_information!='' && sim_information!='undefined'))
								{
								   var latlon = latLong.split(/ /);
								   var lon = parseFloat(latlon[0]);
								   var lat = parseFloat(latlon[1]);
								   var index = location;							
								}
								var tooltiphide='';
								if(sim_wpd_description!=''){ ttooltip=sim_wpd_description; tooltiphide='focus'; }else { tooltiphide='none'; }
									if(display == "regions") {
										data[simMapId].addRows([[{v:location,f:ttitle},MaxValue,ttooltip]]);
										
									}
									else {
									var latlon = latLong.split(/ /);
									var lon = parseFloat(latlon[0]);
									var lat = parseFloat(latlon[1]);
									if((sim_url_val!='' && sim_url_val!='undefined') || (sim_information!='' && sim_information!='undefined'))
									{
										var index = lat;							
									}
									
									data[simMapId].addRows([[lat,lon,ttitle,MaxValue,ttooltip]]);		
									}
									sim_fg_color.push(dataColor);
									if(sim_url_val!='' && sim_url_val!='undefined' && sim_url_val!='null' && (sim_url_action==1 || sim_url_action==2)){ 									  
									    values[simMapId][index] = sim_url_val;
										values[simMapId][index+'1'] = sim_url_action;
										action='1';
									}else if(sim_information!='' && sim_information!='undefined' && sim_information!='null' && sim_url_action==3){
										values[simMapId][index] = sim_information;
										values[simMapId][index+'1'] = sim_url_action;
										action='1';
									}
									
									else if(sim_wpd_boxsearch!='' && sim_wpd_boxsearch!='undefined' && sim_wpd_boxsearch!='null' && (sim_url_action==4 || sim_url_action==5)){
										 if(sim_url_val!='' && sim_wpd_boxsearch!='' && sim_wpd_boxsearch!='null'){
											values[simMapId][index] =sim_url_val+'?boxsearch='+sim_wpd_boxsearch;
										 }
										 else if(sim_url_val!='' && sim_wpd_boxsearch==''){
											values[simMapId][index] = sim_url_val;
											}
											values[simMapId][index+'1'] = sim_url_action;
											action='1';
									}
									MaxValue++;					
									
							}

							defmaxvalue=0;			
							if(MaxValue-1>0){
								defmaxvalue=MaxValue-1;
							}
							if(hideTitle=='true'){
									var toolTitle=false;
									
								}else{
									var toolTitle=true;
									tooltiphide='focus';
								}	
								defmaxvalue = 0;
								if ((places.length-2) > 0) {
								defmaxvalue = places.length-2;	
								}
								
								if(jQuery("#sim_interactive_map"+simMapId).attr('sim-data-zwidth')) {
									width = jQuery("#sim_interactive_map"+simMapId).attr('sim-data-zwidth');
									height = jQuery("#sim_interactive_map"+simMapId).attr('sim-data-zheight');
								}
							    var options = { 
									region:region,
									displayMode: display,
									backgroundColor:sim_bg_color, 
									colorAxis:  {minValue: 0, maxValue: defmaxvalue,  colors: sim_fg_color},
									sizeAxis: {minValue: 1, maxValue:1,minSize:markersizeval,  maxSize: markersizeval},
									enableRegionInteractivity:true,
									datalessRegionColor:'#F5F5F5',
									datalessRegionColor: colorsmap,
									resolution: resolution,
									keepAspectRatio: aspectratio,
									width:width,
									height:height,
									tooltip: {isHtml: false,showTitle: toolTitle ,trigger: tooltiphide},
									magnifyingGlass: {enable: true, zoomFactor: 5.0},
									legend: 'none'
								};
								var mapId="sim_interactive_map"+simMapId;  
								chart[simMapId] = new google.visualization.GeoChart(document.getElementById(mapId));

								if(action!="none") {
								 google.visualization.events.addListener(chart[simMapId], 'select', (function(x) {
								 return function () {
									var selection = chart[x].getSelection();
									if (selection.length == 1) {
										var selectedRow = selection[0].row;
										var selectedRegion = data[x].getValue(selectedRow, 0);
										if(values[x][selectedRegion]!="" && values[x][selectedRegion]!=undefined){
											sim_call_action(values[x][selectedRegion],values[x][selectedRegion+'1']);
											 chart[x].setSelection();
										
										}
									}
								}
							})(simMapId));
						}
							
				//set global variables
                SimMapData[simMapId] = data[simMapId];
                SimMapOptions[simMapId] = options;
                chart[simMapId].draw(SimMapData[simMapId], SimMapOptions[simMapId]);									
				if(!simMapResize[simMapId]) {
					simMapResize[simMapId] = {
						div: jQuery('#'+mapId)
					};
				}
				//in case there was a zoom event, we check the new sizes
				simMapResize[simMapId].lastWidth = simMapResize[simMapId].div.parent().width();	
				
		  }
	
	}
	   

//****************************call to action *************************//	
function sim_call_action(info,action) {
	if(action!='' && info!=''){
		if(action=='1'){
			if(info.substring(0, 4)!="http"){
				info ="http://"+info;
				} else {
					info = info;
				}
		 document.location = info; 
		 } 
			else if(action=='2') { 
				if(info.substring(0, 4)!="http"){
				info ="http://"+info;
				} else {
					info = info;
				}
			window.open(info); 
			} else if(action=='4' || action=='5') { 
				if(info.substring(0, 4)!="http"){
				info ="http://"+info;
				} else {
					info = info;
				}
				if(action=='4'){
				 document.location = info;
				}else{
				window.open(info); 
				}
				
			}else{
				if (!jQuery('#mainIntMapPopupHolder').length){
				jQuery('body').append("<div class=\"main-popup-holder\" id=\"mainIntMapPopupHolder\"> <div class=\"sim-popup\" id=\"modernIntBrowserPopup\"><a href=\"javascript:hidePopup();\" id=\"intmapmodel\"  class=\"popup-closer\">Close</a> <div class=\"pad-horizontal-2x\" class=\"popup-img\" id=\"popupIntData\" style=\"max-width:570px !important; padding-left:20px !important;\"></div></div></div>");
				}
				showPopup(info);
			}
		}
}

//resize code here for responsive view//

function simResizeManage(map_divs,skipcheck) {
	jQuery.each( map_divs, function( index, element ) {
			if(typeof element=='undefined'){
				return; 
			}
		    var map_div = element.div.parent();
			if(!map_div.is(':visible')) {
				if(!skipcheck){
					setTimeout(function(){  simResizeManage(map_divs,true); }, 1);
				}
			}
			else {
				//we check the parent width - site layout - for changes
				var width = map_div.parent().width();
				//if it's the same we terminate function
				if(width==element.lastWidth) {
					return; 
				}
				//else we redraw the map
				delay(function(){
				     if (typeof onMapSelect == 'function') {

				     		 map_div.animate({
							    opacity: 0,
							  }, 100, function() {
							    onMapSelect(true);
			
							  });

				     		 map_div.animate({
							    opacity: 1,
							  }, 50, function() {
							    // Animation complete.
							  });      
							  		 
					} 

				}, 200);
				//end else
			}
		//end each
		});
}

function showPopup(d) { 
				jQuery('#popupIntData').html(d);
				jQuery('#mainIntMapPopupHolder, #modernIntBrowserPopup').addClass('is-shown');
				jQuery('#intmapmodel').css('display','inline-block'); 
	} 
	var hidePopup = function(e){
						jQuery('#popupIntData').html('');
						jQuery('#intmapmodel').css('display','none');
						jQuery('#mainIntMapPopupHolder, #modernIntBrowserPopup').removeClass('is-shown'); 
						
						} 
	
	
var delay = (function(){
  var timer = 0;
  return function(callback, ms){
    clearTimeout (timer);
    timer = setTimeout(callback, ms);
  };
})();



/*jQuery('#mainIntMapPopupHolder').each(function () {
    if(jQuery('[id="' + this.id + '"]:gt(0)').remove()){
	}
});*/

jQuery(window).on('resize orientationchange', function() {	
        if (jQuery(window).width() != windowWidth) {
			windowWidth = jQuery(window).width();
			simResizeManage(simMapResize);
		}
	});
	
	
function super_map_zoom(id,position,simover) {
    var simover = simover || false;
    var CurrentMap = jQuery('#sim_interactive_map'+id);
    var container; 
    if(!simover) {
        CurrentMap.parent().prepend('<div data-step="0" id="sim-controller-'+id+'" class="sim-controller sim-controller-'+position+'"></div>');
        CurrentMap.panzoom({
                disableZoom: true,
                contain: 'invert',
                cursor: "default",
            });
        CurrentMap.mousedown(function() {
            jQuery(this).css('cursor', 'move');
        });
        CurrentMap.mouseup(function() {
            jQuery(this).css('cursor', 'pointer');
        });
    }

    if(id!=simover) {

        jQuery('#sim-controller-'+id).append(function() {

        return jQuery('<div class="sim-controller-zoom-in"><i class="fa fa-plus" aria-hidden="true"></i></div>').click(function() {

                controlparent = jQuery(this).parent();
                cur_click = parseInt(controlparent.attr('data-step'));
                map = CurrentMap;
                
                if(parseInt(map.width())<=6000) {
                    controlparent.attr('data-step',cur_click+1);
                    
                    var step = (parseInt(map.width())*0.3);

                    var newh = (parseInt(map.height())/parseInt(map.width()))*(parseInt(map.width())+step);
                    var neww = parseInt(map.width())+step;
                    var extrah = parseInt(newh) - parseInt(map.height());
                    var extraw = parseInt(neww) - parseInt(map.width());


                    if(!simover) {
                        var transform = map.css('transform');
                        var matrix = transform.replace(/[^0-9\-.,]/g, '').split(',');
                        if(matrix[5] == null) {
                            matrix[5] = 0;
                            matrix[4] = 0;
                        }
                        var ctop = parseInt(matrix[5]);
                        var cleft = parseInt(matrix[4]);
                        var newtop = ctop-(extrah/2);
                        var newleft = cleft-(extraw/2);
                        map.height(newh).width(neww);
                        map.attr('sim-data-zwidth',neww).attr('sim-data-zheight',newh);
                        map.css('transform','matrix(1, 0, 0, 1,'+newleft+','+newtop+')');
                        SimMapOptions[id].width = neww;
                        SimMapOptions[id].height = newh;
						chart[id].draw(SimMapData[id], SimMapOptions[id]);		
                        CurrentMap.panzoom('resetDimensions');

                    }
                    

                    //to apply zoom to simover map container instead
                    if(simover) {

                        var transform = container.css('transform');
                        var matrix = transform.replace(/[^0-9\-.,]/g, '').split(',');

                        if(matrix[5] == null) {
                            matrix[5] = 0;
                            matrix[4] = 0;
                        }

                        var ctop = parseInt(matrix[5]);
                        var cleft = parseInt(matrix[4]);

                        var newtop = ctop-(extrah/2);
                        var newleft = cleft-(extraw/2);

                        container.height(newh).width(neww);
                        container.css('transform','matrix(1, 0, 0, 1,'+newleft+','+newtop+')');

                        SimMapOptions[id].width = neww;
                        SimMapOptions[id].height = newh;
                        chart[id].draw(SimMapData[id], SimMapOptions[id]);
                        SimMapOptions[simover].width = neww;
                        SimMapOptions[simover].height = newh;
                        chart[simover].draw(SimMapData[simover], SimMapOptions[simover]);
                        container.panzoom('resetDimensions');
                    }

                } else {

                    //stop zooming after full zoom 

                }
                
          
            });

    }).append(function() {

        return jQuery('<div class="sim-controller-zoom-out"><i class="fa fa-minus" aria-hidden="true"></i></div>').click(function() {

                controlparent = jQuery(this).parent();
                cur_click = parseInt(controlparent.attr('data-step'));

                if(cur_click > 0) {

                    map = CurrentMap;
                    var prevw = (10*parseInt(map.width()))/13;
                    var step = parseInt(map.width()) - prevw;
                    var neww = prevw;

                    if(!simover) {
                        var parentw = parseInt(map.parent().width());
                        var parenth = parseInt(map.parent().height());

                    }

                    if(simover) {

                        var parentw = parseInt(container.parent().width());
                        var parenth = parseInt(container.parent().height());

                    }


                    if(parentw <= neww) {
                        newh = (parseInt(map.height())/parseInt(map.width()))*(parseInt(map.width())-step);
                        var extrah = parseInt(map.height())-parseInt(newh);
                        var extraw = parseInt(map.width())-parseInt(neww);

                        if(simover) {

                            var transform = container.css('transform');

                        }

                        if(!simover) {

                            var transform = map.css('transform');

                        }

                        var matrix = transform.replace(/[^0-9\-.,]/g, '').split(',');
                        var ctop = parseInt(matrix[5]);
                        var cleft = parseInt(matrix[4]);
                        var newtop = ctop+(extrah/2);
                        var newleft = cleft+(extraw/2);
                        if(newleft > 0) {
                            newleft = 0;
                        }
                        if(newtop > 0) {
                            newtop = 0;
                        }

                        var maxh = newh - parenth;
                        var maxh = maxh - (maxh)*2;
                        if(newtop < maxh) {
                            newtop = maxh;
                        }

                        var maxw = neww - parentw;
                        var maxw = maxw - (maxw)*2;
                        if(newleft < maxw) {
                            newleft = maxw;
                        }

                        if(!simover) {
                            map.height(newh);
                            map.width(neww);
                            map.attr('sim-data-zwidth',neww).attr('sim-data-zheight',newh);
                            map.css('transform','matrix(1, 0, 0, 1,'+newleft+','+newtop+')');
                            SimMapOptions[id].width = neww;
                            SimMapOptions[id].height = newh;
                            chart[id].draw(SimMapData[id], SimMapOptions[id]);
                            CurrentMap.panzoom('resetDimensions');
                            controlparent.attr('data-step',cur_click-1);
                        }
                        
                        if(simover) {
                            container.height(newh);
                            container.width(neww);
                            container.attr('sim-data-zwidth',neww).attr('sim-data-zheight',newh);
                            container.css('transform','matrix(1, 0, 0, 1,'+newleft+','+newtop+')');
                            SimMapOptions[id].width = neww;
                            SimMapOptions[id].height = newh;
                            chart[id].draw(SimMapData[id], SimMapOptions[id]);
                            SimMapOptions[simover].width = neww;
                            SimMapOptions[simover].height = newh;
                            chart[simover].draw(SimMapData[simover], SimMapOptions[simover]);
                            container.panzoom('resetDimensions');
                            controlparent.attr('data-step',cur_click-1);
                        }
        
                    }

                }
                
            });

    });

    }

}
