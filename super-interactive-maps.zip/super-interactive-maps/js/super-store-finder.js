// Javascript for Admin Area
// Google Map API Standard Code
var map;
var marker;
var geocoder;
var region = 'us';
var markers = new Array();
jQuery(document).ready(function(){
   	var address ='';
	var lat = "";
	var lng = "";
	var location = "";
	
	if(jQuery('#map_canvas').length) {
		geocoder = new google.maps.Geocoder();
	}
    var myOptions = {
					zoom: 8,
					mapTypeId: google.maps.MapTypeId.ROADMAP
				};
	map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
	
	marker = new google.maps.Marker({
				  map: map, 
				  title: 'Drag Me',
				  draggable: true
				});
				
	var infowindow = new google.maps.InfoWindow({
					maxWidth: "300",
					content: 'Drag Me'
	});
				
	infowindow.open(map,marker);
	
	google.maps.event.addListener(autocomplete, 'place_changed', function() {
			var address='';
			address =jQuery('#sim_search_location').val();
			if(address != '') {
				get_coordinate(address,region);
			}
	});
	
	var timer = null;
	jQuery('#sim_search_location').keydown(function(){
		   clearTimeout(timer); 
		   timer = setTimeout(doCoordinate, 1000)
	});
	
	function doCoordinate() {
		address =jQuery('#sim_search_location').val();
		get_coordinate(address,region);
	}
	
	jQuery('#sim_search_location_select').on('change', function () {
	var changeVal = jQuery(this).val();
		address =changeVal;
			if(address != '') {
				get_coordinate(address,region);
			}
	});
	
	
	
	
});

var autocomplete = new google.maps.places.Autocomplete(jQuery("#sim_search_location")[0], {});


/**
 * Get address location
 */
 
function get_coordinate(address, region) {
	
	if(region==null || region == '' || region == 'undefined') {
		region = 'us';
	}
	
	if(address != '') {
		jQuery('#ajax_msg').html('<p>Loading location</p>');

		geocoder.geocode( {'address':address,'region':region}, function(results, status) {

			if(status == google.maps.GeocoderStatus.OK) {
				jQuery('#ajax_msg').html('<p></p>');
				// populate form field with geo location
				var latlong= results[0].geometry.location.lng().toFixed(7) +' '+ results[0].geometry.location.lat().toFixed(7);
				jQuery('#ssf_wp_search_id').val(latlong); // latlng

				map.setZoom(10);
				map.setCenter(results[0].geometry.location);
				// Google Map Marker
				marker.setPosition(results[0].geometry.location);
			} else {

				jQuery('#ajax_msg').html('<p>Google map geocoder failed: '+status+'</p>');
			}
		});
	}
}

jQuery(".changeCheckVal").click(function(){
 var id=this.id;
 var idvalue=this.value;
	if(idvalue=='true'){
		jQuery('#'+id).val('false');
		jQuery('#'+id+'_val').val('false');
		}else{
		jQuery('#'+id).val('true');
		jQuery('#'+id+'_val').val('true');
		}
 })
 

 