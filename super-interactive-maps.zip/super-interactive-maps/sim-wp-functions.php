<?php
function sim_wp_move_upload_directories() {
	global $sim_wp_uploads_path, $sim_wp_path;
		$sim_wp_uploads_arr=wp_upload_dir();
	if (!is_dir($sim_wp_uploads_arr['baseurl'])) {
		mkdir($sim_wp_uploads_arr['baseurl'], 0755, true);
	}
	if (!is_dir(sim_WP_UPLOADS_PATH)) {
		mkdir(sim_WP_UPLOADS_PATH, 0755, true);
	}
	if (is_dir(sim_WP_ADDONS_PATH_ORIGINAL) && !is_dir(sim_WP_ADDONS_PATH)) {
		sim_wp_copyr(sim_WP_ADDONS_PATH_ORIGINAL, sim_WP_ADDONS_PATH);
		chmod(sim_WP_ADDONS_PATH, 0755);
	}
	if (is_dir(sim_WP_THEMES_PATH_ORIGINAL) && !is_dir(sim_WP_THEMES_PATH)) {
		sim_wp_copyr(sim_WP_THEMES_PATH_ORIGINAL, sim_WP_THEMES_PATH);
		chmod(sim_WP_THEMES_PATH, 0755);
	}
	if (is_dir(sim_WP_LANGUAGES_PATH_ORIGINAL) && !is_dir(sim_WP_LANGUAGES_PATH)) {
		sim_wp_copyr(sim_WP_LANGUAGES_PATH_ORIGINAL, sim_WP_LANGUAGES_PATH);
		chmod(sim_WP_LANGUAGES_PATH, 0755);
	}
	if (is_dir(sim_WP_IMAGES_PATH_ORIGINAL) && !is_dir(sim_WP_IMAGES_PATH)) {
		sim_wp_copyr(sim_WP_IMAGES_PATH_ORIGINAL, sim_WP_IMAGES_PATH);
		chmod(sim_WP_IMAGES_PATH, 0755);
	}
	
	if (is_dir(sim_WP_CSV_PATH_ORIGINAL) && !is_dir(sim_WP_CUSTOM_CSV_PATH)) {
		sim_wp_copyr(sim_WP_CSV_PATH_ORIGINAL, sim_WP_CUSTOM_CSV_PATH);
		chmod(sim_WP_CUSTOM_CSV_PATH, 0755);
	}
	
	
	if (!is_dir(sim_WP_CUSTOM_CSS_PATH)) {
		mkdir(sim_WP_CUSTOM_CSS_PATH, 0755, true);
	}
	if (!is_dir(sim_WP_CACHE_PATH)) {
	      mkdir(sim_WP_CACHE_PATH, 0755, true);
	}
	sim_wp_ht(sim_WP_CACHE_PATH, 'ht');
	sim_wp_ht(sim_WP_ADDONS_PATH);
	sim_wp_ht(sim_WP_UPLOADS_PATH);
}
function sim_wp_ht($path, $type='index'){
	if(is_dir($path) && !is_file($path."/.htaccess") && !is_file($path."/index.php")) {
		if ($type == 'ht') {
$htaccess = <<<EOQ
<FilesMatch "\.(php|gif|jpe?g|png|css|js|csv|xml|json)$">
Allow from all
</FilesMatch>
order deny,allow
deny from all
allow from none
Options All -Indexes
EOQ;
			$filename = $path."/.htaccess";
			$file_handle = @ fopen($filename, 'w+');
			@fwrite($file_handle, $htaccess);
			@fclose($file_handle);
			@chmod($file_handle, 0644);
		} elseif ($type == 'index') {
			$index ='<?php /*empty; prevents directory browsing*/ ?>';
			$filename = $path."/index.php";
			$file_handle = @ fopen($filename, 'w+');
			@fwrite($file_handle, $index);
			@fclose($file_handle);
			@chmod($file_handle, 0644);
		}	
	} elseif (is_dir($path) && is_file($path."/.htaccess") && $type == 'index') {
		
		@unlink($path."/.htaccess");
		$index ='<?php /*empty; prevents directory browsing*/ ?>';
		$filename = $path."/index.php";
		$file_handle = @ fopen($filename, 'w+');
		@fwrite($file_handle, $index);
		@fclose($file_handle);
		@chmod($file_handle, 0644);		
	}
}
/* -----------------*/

function simParseToXML($htmlStr) 
{ 
	$xmlStr=str_replace('<','&lt;',$htmlStr); 
	$xmlStr=str_replace('>','&gt;',$xmlStr); 
	$xmlStr=str_replace('"','&quot;',$xmlStr); 
	$xmlStr=str_replace("'",'&#39;',$xmlStr); 
	$xmlStr=str_replace("&",'&amp;',$xmlStr); 
	$xmlStr=str_replace("," ,"&#44;" ,$xmlStr);
	return $xmlStr; 
} 

function simParseToHXML($htmlStr) 
{ 
	$xmlStr=str_replace('&#44;',',',$htmlStr); 
	$xmlStr=str_replace('&lt;','<',$htmlStr); 
	$xmlStr=str_replace('&gt;','>',$xmlStr); 
	$xmlStr=str_replace('&quot;','"',$xmlStr); 
	$xmlStr=str_replace("&#39;","'",$xmlStr); 
	$xmlStr=str_replace("&amp;",'&',$xmlStr); 
	$xmlStr=str_replace("&#44;" ,"," ,$xmlStr);
	$xmlStr=str_replace("&lt;br&gt;","",$xmlStr);
	$xmlStr=str_replace("&nbsp;","",$xmlStr);
	return $xmlStr; 
} 
/*-----------------*/
function filter_sim_wp_mdo($the_arr) {
	$input_zone_clause = ($the_arr['input_zone'] == $GLOBALS['input_zone_type']);
	
	$output_zone_clause = ( !isset($the_arr['output_zone']) || !isset($GLOBALS['output_zone_type']) || ($the_arr['output_zone'] == $GLOBALS['output_zone_type']) );
	
	return ($input_zone_clause && $output_zone_clause);
}
function sim_wp_md_initialize() {
	global $sim_wp_vars;
	include(sim_WP_INCLUDES_PATH."/settings-options.php");
	sim_wp_data('sim_wp_vars', 'add', $sim_wp_vars);
	foreach ($sim_wp_mdo as $value) {
				
		if (isset($value['field_name']) && !is_array($value['field_name']) ) {
			$value['default'] = (!isset($value['default']))? "" : $value['default'];
			
			$default_not_set = !isset($sim_wp_vars[$value['field_name']]);
			$default_set_but_value_set_to_blank = (isset($sim_wp_vars[$value['field_name']]) && strlen(trim($sim_wp_vars[$value['field_name']])) == 0);
			
			if ( ($default_not_set || $default_set_but_value_set_to_blank) ) {
				
				$sim_wp_vars[$value['field_name']] = $value['default'];
			} 
						
			$varname = "sim_wp_".$value['field_name'];  
			global $$varname;
			$$varname = $sim_wp_vars[$value['field_name']]; 
			
		} elseif (isset($value['field_name']) && is_array($value['field_name']) ) {
		   
			$value['default'] = (!isset($value['default']))? array_fill(0, count($value['field_name']), "") : $value['default'];
		
			
			$ctr = 0;	
			foreach ($value['default'] as $the_default) {
				
				$the_field = $value['field_name'][$ctr];
				$d_n_s = !isset($sim_wp_vars[$the_field]);
				$d_s_b_v_s_t_b = (isset($sim_wp_vars[$the_field]) && strlen(trim($sim_wp_vars[$the_field])) == 0);
		
				if ( ($d_n_s || $d_s_b_v_s_t_b) ) {
					$sim_wp_vars[$the_field] = $the_default;
				}
				
				$varname = "sim_wp_".$the_field;  
				global $$varname;
				$$varname = $sim_wp_vars[$the_field];
				$ctr++;
			} 
		    
		}
	}
}
/*-----------------*/
function sim_wp_initialize_variables() {
	
global $sim_wp_height, $sim_wp_width, $sim_wp_width_units, $sim_wp_height_units, $sim_wp_radii;
global $sim_wp_icon, $sim_wp_icon2, $sim_wp_google_map_domain, $sim_wp_google_map_country, $sim_wp_theme, $sim_wp_base, $sim_wp_uploads_base, $sim_wp_location_table_view;
global $sim_wp_search_label, $sim_wp_zoom_level, $sim_wp_use_city_search, $sim_wp_use_name_search, $sim_wp_name;
global $sim_wp_radius_label, $sim_wp_website_label, $sim_wp_directions_label, $sim_wp_num_initial_displayed, $sim_wp_load_locations_default;
global $sim_wp_distance_unit, $sim_wp_map_overview_control, $sim_wp_admin_locations_per_page, $sim_wp_instruction_message;
global $sim_wp_map_character_encoding, $sim_wp_start, $sim_wp_map_language, $sim_wp_map_region, $sim_wp_sensor, $sim_wp_geolocate;
global $sim_wp_map_settings, $sim_wp_remove_credits, $sim_wp_api_key, $sim_wp_location_not_found_message, $sim_wp_no_results_found_message; 
global $sim_wp_load_results_with_locations_default, $sim_wp_vars, $sim_wp_city_dropdown_label, $sim_wp_scripts_load, $sim_wp_scripts_load_home, $sim_wp_scripts_load_archives_404;
global $sim_wp_hours_label, $sim_wp_phone_label, $sim_wp_fax_label, $sim_wp_email_label;

$sim_wp_vars=sim_wp_data('sim_wp_vars'); 
sim_wp_md_initialize();

if(!isset($sim_wp_vars['map_settings']))
	{
	$sim_wp_vars['sensor']="false";
	$sim_wp_vars['geolocate']="";
    $sim_wp_vars['api_key']="";
	$sim_wp_vars['google_map_country']= "United States";
	$sim_wp_vars['map_region']="";
	$sim_wp_vars['map_language']= "en";
	$sim_wp_vars['map_character_encoding']="";
	$sim_wp_vars['start']=date("Y-m-d H:i:s");
	$sim_wp_vars['name']="Super Interactive Maps";
	$sim_wp_vars['admin_locations_per_page']="100";
	$sim_wp_vars['location_table_view']="Normal";
	}
	else{
		if (strlen(trim($sim_wp_vars['sensor'])) == 0) {	$sim_wp_vars['sensor'] = ($sim_wp_vars['geolocate'] == '1')? "true" : "false";	}
$sim_wp_sensor=$sim_wp_vars['sensor'];


if ($sim_wp_vars['api_key'] === NULL) {	$sim_wp_vars['api_key']="";	}
$sim_wp_api_key=$sim_wp_vars['api_key'];

if (strlen(trim($sim_wp_vars['google_map_country'])) == 0) {	$sim_wp_vars['google_map_country']="United States";}
$sim_wp_google_map_country=$sim_wp_vars['google_map_country'];

if ($sim_wp_vars['map_region'] === NULL) {	$sim_wp_vars['map_region']="";	}
$sim_wp_map_region=$sim_wp_vars['map_region'];

if (strlen(trim($sim_wp_vars['map_language'])) == 0) {	$sim_wp_vars['map_language']="en";	}
$sim_wp_map_language=$sim_wp_vars['map_language'];

if ($sim_wp_vars['map_character_encoding'] === NULL) {	$sim_wp_vars['map_character_encoding']="";		}
$sim_wp_map_character_encoding=$sim_wp_vars['map_character_encoding'];

if (strlen(trim($sim_wp_vars['start'])) == 0) { 	$sim_wp_vars['start']=date("Y-m-d H:i:s"); 	} 
$sim_wp_start=$sim_wp_vars['start']; 

if (strlen(trim($sim_wp_vars['name'])) == 0) {	$sim_wp_vars['name']="Super Interactive Maps";	}  
$sim_wp_name=$sim_wp_vars['name'];


if (strlen(trim($sim_wp_vars['admin_locations_per_page'])) == 0) {	$sim_wp_vars['admin_locations_per_page']="100";	}
$sim_wp_admin_locations_per_page=$sim_wp_vars['admin_locations_per_page'];

if (strlen(trim($sim_wp_vars['location_table_view'])) == 0) {	$sim_wp_vars['location_table_view']="Normal";	}
$sim_wp_location_table_view=$sim_wp_vars['location_table_view'];


if (strlen(trim($sim_wp_vars['map_settings'])) == 0) {	$sim_wp_vars['map_settings']="google.maps.MapTypeId.ROADMAP";}
elseif ($sim_wp_vars['map_settings']=="G_NORMAL_MAP"){	$sim_wp_vars['map_settings']='google.maps.MapTypeId.ROADMAP';}
elseif ($sim_wp_vars['map_settings']=="G_SATELLITE_MAP"){	$sim_wp_vars['map_settings']='google.maps.MapTypeId.SATELLITE';}
elseif ($sim_wp_vars['map_settings']=="G_HYBRID_MAP"){	$sim_wp_vars['map_settings']='google.maps.MapTypeId.HYBRID';}
elseif ($sim_wp_vars['map_settings']=="G_PHYSICAL_MAP"){	$sim_wp_vars['map_settings']='google.maps.MapTypeId.TERRAIN';}
$sim_wp_map_settings=$sim_wp_vars['map_settings'];
		
		
	}

	sim_wp_data('sim_wp_vars', 'add', $sim_wp_vars);
}
/*--------------------------*/
function sim_wp_choose_units($unit, $input_name) {
	$unit_arr[]="%";$unit_arr[]="px";$unit_arr[]="em";$unit_arr[]="pt";
	$select_field="<select name='$input_name'>";

	
	foreach ($unit_arr as $value) {
		$selected=($value=="$unit")? " selected='selected' " : "" ;
		if (!($input_name=="height_units" && $unit=="%")) {
			$select_field.="\n<option value='$value' $selected>$value</option>";
		}
	}
	$select_field.="</select>";
	return $select_field;
}


/*----------------------------*/

function sim_wp_install_tables() {
	global $wpdb, $sim_wp_db_version, $sim_wp_path, $sim_wp_uploads_path, $sim_wp_hook;
if (!defined("sim_WP_TABLE") || !defined("sim_WP_TAG_TABLE") || !defined("sim_WP_SETTING_TABLE")){ 
	$sim_wp_db_prefix = $wpdb->prefix; 
}

	if (!defined("sim_WP_TABLE")){ define("sim_WP_TABLE", $sim_wp_db_prefix."sim_wp_map");}
	if (!defined("sim_WP_TABLE_DATA")){ define("sim_WP_TABLE_DATA", $sim_wp_db_prefix."sim_wp_map_data");}
	if (!defined("sim_WP_SETTING_TABLE")){ define("sim_WP_SETTING_TABLE", $sim_wp_db_prefix."sim_wp_setting"); }
	
	$table_name = sim_WP_TABLE;
	$sql = "CREATE TABLE ".$table_name." (
			sim_wp_id mediumint(8) unsigned NOT NULL auto_increment,
			sim_wp_name varchar(255) NULL,
			sim_wp_description mediumtext NULL,
			sim_wp_use_default varchar(255) DEFAULT true,
			sim_wp_bg_color varchar(255) NULL,
			sim_wp_border_color varchar(255) NULL,
			sim_wp_map_color varchar(255) NULL,
			sim_wp_marker_size varchar(255) NULL,
			sim_wp_hide_title varchar(255) NULL,
			sim_wp_width varchar(255) NULL,
			sim_wp_height varchar(255) NULL,
			sim_wp_aspect_ratio varchar(255) DEFAULT true,
			sim_wp_showtooltip varchar(255) NULL,
			sim_wp_map_region varchar(255) NULL,
			sim_wp_display_mode varchar(255) NULL,
			sim_wp_call_to_action varchar(255) NULL,
			sim_wp_locations varchar(255) NULL,
			sim_wp_image LONGTEXT NULL DEFAULT NULL,
			sim_wp_url varchar(255) NULL,
			sim_wp_content varchar(255) NULL,
			sim_wp_created_datetime date NULL,
			sim_wp_zoom varchar(255) NULL,
			sim_wp_top varchar(255) NULL,
			sim_wp_left varchar(255) NULL,
			sim_wp_map_height varchar(255) NULL,
			sim_wp_map_hover varchar(255) NULL,
			sim_wp_zoom_setting varchar(255) DEFAULT false,
			PRIMARY KEY  (sim_wp_id)
			) ENGINE=innoDB  DEFAULT CHARACTER SET=utf8  DEFAULT COLLATE=utf8_unicode_ci;";
	

	$table_name_2 = sim_WP_SETTING_TABLE;
	$sql .= "CREATE TABLE ".$table_name_2." (
			sim_wp_setting_id bigint(20) unsigned NOT NULL auto_increment,
			sim_wp_setting_name varchar(255) NULL,
			sim_wp_setting_value longtext NULL,
			PRIMARY KEY  (sim_wp_setting_id)
			) ENGINE=innoDB  DEFAULT CHARACTER SET=utf8  DEFAULT COLLATE=utf8_unicode_ci;";
    
	$table_name_3 = sim_WP_TABLE_DATA;
	$sql .= "CREATE TABLE ".$table_name_3." (
			sim_wpd_id bigint(20) unsigned NOT NULL auto_increment,
			sim_wpd_data_id mediumint(8) unsigned NOT NULL,
			sim_wpd_locations varchar(255) NULL,
			sim_wpd_title varchar(255) NULL,
			sim_wpd_description longtext NULL,
			sim_wpd_call_to_action varchar(255) NULL,
			sim_wpd_url varchar(255) NULL,
			sim_wpd_data_color varchar(255) NULL,
			sim_wpd_search_id varchar(255) NULL,
			sim_wpd_information longtext NULL,
			sim_wpd_boxsearch varchar(255) NULL,
			PRIMARY KEY  (sim_wpd_id)
			) ENGINE=innoDB  DEFAULT CHARACTER SET=utf8  DEFAULT COLLATE=utf8_unicode_ci;";
	
	if($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name)) != $table_name || $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name_2)) != $table_name_2  || $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name_3)) != $table_name_3) {
		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
		sim_wp_data("sim_wp_db_version", 'add', $sim_wp_db_version);
		sim_wp_initialize_variables();
	}
	$installed_ver = sim_wp_data("sim_wp_db_version");
	if( $installed_ver != $sim_wp_db_version ) {
		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
		sim_wp_data("sim_wp_db_version", 'update', $sim_wp_db_version);
	}
	if (sim_wp_data("sim_wp_db_prefix")===""){
		sim_wp_data('sim_wp_db_prefix', 'update', $sim_wp_db_prefix);
	}
	sim_wp_move_upload_directories();
}

/*-------------------------------*/

function sim_wp_head_scripts($superintermap_array) {

	global $sim_wp_dir, $sim_wp_base, $sim_wp_uploads_base, $sim_wp_path, $sim_wp_uploads_path, $wpdb, $pagename, $sim_wp_map_language, $post, $sim_wp_vars; 	
	$on_sim_wp_page=""; $sim_wp_code_is_used_in_posts=""; $post_ids_array="";
	if (empty($sim_wp_vars['scripts_load']) || $sim_wp_vars['scripts_load'] != 'all') {
		if (empty($_GET['p'])){ $_GET['p']=""; } if (empty($_GET['page_id'])){ $_GET['page_id']=""; }

		$on_sim_wp_page=$wpdb->get_results("SELECT post_name, post_content FROM ".sim_WP_DB_PREFIX."posts WHERE LOWER(post_content) LIKE '%[super-interactive-map%' AND (post_name='$pagename' OR ID='".esc_sql($_GET['p'])."' OR ID='".esc_sql($_GET['page_id'])."')", ARRAY_A);		
		$sim_wp_code_is_used_in_posts=$wpdb->get_results("SELECT post_name, ID FROM ".sim_WP_DB_PREFIX."posts WHERE LOWER(post_content) LIKE '%[super-interactive-map%' AND post_type='post'", ARRAY_A);
		if ($sim_wp_code_is_used_in_posts) {

			$sim_wp_post_ids=$sim_wp_code_is_used_in_posts;

			foreach ($sim_wp_post_ids as $val) { $post_ids_array[]=$val['ID'];}

		} else {		

			$post_ids_array=array(pow(10,15)); 

		}
	}
	$show_on_all_pages = ( !empty($sim_wp_vars['scripts_load']) && $sim_wp_vars['scripts_load'] == 'all' );
	$show_on_front_page = ( is_front_page()  && (!isset($sim_wp_vars['scripts_load_home']) || $sim_wp_vars['scripts_load_home']==1) );
	$show_on_front_page=1;
	$show_on_archive_404_pages = ( (is_archive() || is_404()) && $sim_wp_code_is_used_in_posts && (!isset($sim_wp_vars['scripts_load_archives_404']) || $sim_wp_vars['scripts_load_archives_404']==1) );
	$show_on_custom_post_types = ( is_singular() && !is_singular(array('page', 'attachment', 'post')) && !is_front_page() );
	$show_on_page_templates = ( is_page_template() && !is_front_page() );
	$on_sim_wp_post = is_single($post_ids_array);
	
	if ($show_on_all_pages || $on_sim_wp_page  || $show_on_archive_404_pages || $show_on_front_page  || $on_sim_wp_post || $show_on_custom_post_types || function_exists('show_sim_wp_scripts') || $show_on_page_templates) {
		$GLOBALS['is_on_sim_wp_page'] = 1;

		$sens=(!empty($sim_wp_vars['sensor']) && ($sim_wp_vars['sensor'] === "true" || $sim_wp_vars['sensor'] === "false" ))? "&amp;sensor=".$sim_wp_vars['sensor'] : "&amp;sensor=false" ;
		$lang_loc=(!empty($sim_wp_vars['map_language']))? "&amp;language=".$sim_wp_vars['map_language'] : "" ; 
		$region_loc=(!empty($sim_wp_vars['map_region']))? "&amp;region=".$sim_wp_vars['map_region'] : "" ;
		$key=(!empty($sim_wp_vars['api_key']))? "&amp;key=".$sim_wp_vars['api_key'] : "" ;

		if (empty($_POST) && 1==2) { 
			$nm=(!empty($post->post_name))? $post->post_name : $pagename ;
			$p=(!empty($post->ID))? $post->ID : esc_sql($_GET['p']) ;
			} else {
			sim_wp_dyn_js();
		}

		$has_custom_css=(file_exists(sim_WP_CUSTOM_CSS_PATH."/mega-superstorefinder.css"))? sim_WP_CUSTOM_CSS_BASE : sim_WP_CSS_BASE; 
		//mega locator
		$protocol = is_ssl() ? 'https' : 'http';
	    $googleurl = $protocol."://www.google.com/jsapi";
		wp_enqueue_style( 'mega-font-awesome' , $has_custom_css.'/font-awesome/css/font-awesome.css' , true , '4.1' );
		wp_enqueue_style( 'mega-normalize' , $has_custom_css.'/normalize.css' , true , '2.0' );
		wp_enqueue_style( 'mega-interactivemap' , $has_custom_css.'/mega-interactivemap.css' , true , '1.0' );
	    wp_enqueue_script('mega-chart', 'https://www.gstatic.com/charts/loader.js?ver=4.5.1','jquery');
		wp_deregister_script( 'mega-google-load' );
	    wp_register_script( 'mega-google-load', $googleurl,array(),false,false);
        wp_enqueue_script( 'mega-google-load' );
		wp_enqueue_script('PanZoom', sim_WP_JS_BASE."/jquery.panzoom.min.js", "jQuery");
		wp_enqueue_script('interactivemap', sim_WP_JS_BASE."/mega-interactivemap.js", "jQuery");
		wp_localize_script('interactivemap', 'superintermap', $superintermap_array);
		if (function_exists("do_sim_wp_hook")){do_sim_wp_hook('sim_wp_addon_head_styles');}
		sim_wp_move_upload_directories();

	}
}

function sim_wp_jq() {wp_enqueue_script( 'jquery');}

add_action('wp_enqueue_scripts', 'sim_wp_jq');

/*-----------------------------------*/

function sim_wp_add_options_page() {

	global $sim_wp_dir, $sim_wp_base, $sim_wp_uploads_base, $text_domain, $sim_wp_top_nav_links, $sim_wp_vars, $sim_wp_version;

	$parent_url = sim_WP_PARENT_URL; 

	$warning_count = 0;

	$warning_title = __("Update(s) currently available for Store Locator", sim_WP_TEXT_DOMAIN) . ":";

	$sim_wp_vars['sim_wp_latest_version_check_time'] = (empty($sim_wp_vars['sim_wp_latest_version_check_time']))? date("Y-m-d H:i:s") : $sim_wp_vars['sim_wp_latest_version_check_time'];

	if (empty($sim_wp_vars['sim_wp_latest_version']) || (time() - strtotime($sim_wp_vars['sim_wp_latest_version_check_time']))/60>=(60*12)){ //12-hr db caching of version info

		$sim_wp_latest_version = ''; 
		$sim_wp_vars['sim_wp_latest_version_check_time'] = date("Y-m-d H:i:s");
		$sim_wp_vars['sim_wp_latest_version'] = $sim_wp_latest_version;
	} else {
		$sim_wp_latest_version = $sim_wp_vars['sim_wp_latest_version'];
	}


	if (strnatcmp($sim_wp_latest_version, $sim_wp_version) > 0) { 
		$warning_title .= "\n- Store Locator v{$sim_wp_latest_version} " . __("is available, you are using", sim_WP_TEXT_DOMAIN). " v{$sim_wp_version}";

		$warning_count++;

		$sim_wp_plugin = sim_WP_DIR . "/super-interactive-map.php";

		$sim_wp_update_link = admin_url('update.php?action=upgrade-plugin&plugin=' . $sim_wp_plugin);

		$sim_wp_update_link_nonce = wp_nonce_url($sim_wp_update_link, 'upgrade-plugin_' . $sim_wp_plugin);

		$sim_wp_update_msg = "&nbsp;&gt;&nbsp;<a href='$sim_wp_update_link_nonce' style='color:#900; font-weight:bold;' onclick='confirmClick(\"".__("You will now be updating to Store Locator", sim_WP_TEXT_DOMAIN)." v$sim_wp_latest_version, ".__("click OK or Confirm to continue", sim_WP_TEXT_DOMAIN).".\", this.href); return false;'>".__("Update to", sim_WP_TEXT_DOMAIN)." $sim_wp_latest_version</a>";

	} else {

		$sim_wp_update_msg = "";

	}

	if(defined("sim_WP_ADDONS_PLATFORM_DIR")) {
	   $sim_wp_vars['sim_wp_latest_ap_check_time'] = (empty($sim_wp_vars['sim_wp_latest_ap_check_time']))? date("Y-m-d H:i:s") : $sim_wp_vars['sim_wp_latest_ap_check_time'];

	   if ( (empty($sim_wp_vars['sim_wp_latest_ap_version']) || (time() - strtotime($sim_wp_vars['sim_wp_latest_ap_check_time']))/60>=(60*12)) ) { //12-hr db caching of version info

		$ap_update = sim_wp_remote_data(array(

			'pagetype' => 'ap',

			'dir' => sim_WP_ADDONS_PLATFORM_DIR, 

			'key' => sim_wp_data('sim_wp_license_' . sim_WP_ADDONS_PLATFORM_DIR)

		));

		$ap_latest_version = (!empty($ap_update[0]))? preg_replace("@\.zip|".sim_WP_ADDONS_PLATFORM_DIR."\.@", "", $ap_update[0]['filename']) : 0;


		$sim_wp_vars['sim_wp_latest_ap_check_time'] = date("Y-m-d H:i:s");

		$sim_wp_vars['sim_wp_latest_ap_version'] = $ap_latest_version;

	   } else {

		$ap_latest_version = $sim_wp_vars['sim_wp_latest_ap_version'];

	   }


	   $ap_readme = sim_WP_ADDONS_PLATFORM_PATH."/readme.txt"; 

	   if (file_exists($ap_readme)) {

		$rm_txt = file_get_contents($ap_readme);

		preg_match("/\n[ ]*stable tag:[ ]?([^\n]+)(\n)?/i", $rm_txt, $cv); 

		$ap_version = (!empty($cv[1]))? trim($cv[1]) : "1.0" ;

	   } else {$ap_version = "1.6";}



	   if (strnatcmp($ap_latest_version, $ap_version) > 0) {

		$ap_title = ucwords(str_replace("-", " ", sim_WP_ADDONS_PLATFORM_DIR));

		$warning_title .= "\n- $ap_title v{$ap_latest_version} " . __("is available, you are using", sim_WP_TEXT_DOMAIN). " v{$ap_version}";

		$warning_count++;

	   }

	} 

	$notify = ($warning_count > 0)?  " <span class='update-plugins count-$warning_count' title='$warning_title'><span class='update-count'>" . $warning_count . "</span></span>" : "" ;
	
	$sim_role='';
	function get_sim_current_user_role() {
		global $wp_roles;
		$current_user = wp_get_current_user();
		$roles = $current_user->roles;
		$role = array_shift($roles);
		return trim($role);
    }
	$sim_role=get_sim_current_user_role();
	if(!isset($sim_wp_vars['sim_user_role'])){
		$sim_wp_vars['sim_user_role']='administrator';
	}
    $userRole=(trim($sim_wp_vars['sim_user_role'])!="")? $sim_wp_vars['sim_user_role'] : "administrator";
	$ex_cat = explode(",", $userRole);
    $ex_cat = array_map( 'trim', $ex_cat );
	if(in_array($sim_role,$ex_cat) || $sim_role=='administrator'){	
	$sim_wp_menu_pages['main'] = array('title' => __("Super Interactive Maps", sim_WP_TEXT_DOMAIN)."$notify", 'capability' => $sim_role, 'page_url' =>  $parent_url, 'icon' => sim_WP_BASE.'/images/logo.ico.png', 'menu_position' => 49);
	$sim_wp_menu_pages['sub']['information'] = array('parent_url' => $parent_url, 'title' => __("Quick Start", sim_WP_TEXT_DOMAIN), 'capability' => $sim_role, 'page_url' => $parent_url);
	$sim_wp_menu_pages['sub']['locations'] = array('parent_url' => $parent_url, 'title' => __("Maps", sim_WP_TEXT_DOMAIN), 'capability' => $sim_role, 'page_url' => sim_WP_PAGES_DIR.'/maps.php');
	$sim_wp_menu_pages['sub']['add-maps'] = array('parent_url' => $parent_url, 'title' => __("Add New Map", sim_WP_TEXT_DOMAIN), 'capability' => $sim_role, 'page_url' => sim_WP_PAGES_DIR.'/add-maps.php');
	$sim_wp_menu_pages['sub']['settings'] = array('parent_url' => $parent_url, 'title' => __("Settings", sim_WP_TEXT_DOMAIN), 'capability' => $sim_role, 'page_url' => sim_WP_PAGES_DIR.'/settings.php');
	sim_wp_menu_pages_filter($sim_wp_menu_pages);
  }
}

function sim_wp_menu_pages_filter($sim_wp_menu_pages) {

	if (function_exists('do_sim_wp_hook')){do_sim_wp_hook('sim_wp_menu_pages_filter', '', array(&$sim_wp_menu_pages));}
	
	foreach ($sim_wp_menu_pages as $menu_type => $value) {

		if ($menu_type == 'main') {
			add_menu_page ($value['title'], $value['title'], $value['capability'], $value['page_url'], '', $value['icon'], $value['menu_position']);
		}
		if ($menu_type == 'sub'){
			foreach ($value as $sub_value) {
				 add_submenu_page($sub_value['parent_url'], $sub_value['title'], $sub_value['title'], $sub_value['capability'], $sub_value['page_url']);
			}

		}

	}

}

function sim_wp_where_clause_filter(&$where){

	if (function_exists("do_sim_wp_hook")) {do_sim_wp_hook("sim_wp_where_clause_filter");}

}

/*---------------------------------------------------*/

function sim_wp_add_admin_javascript() {

global $sim_wp_base, $sim_wp_uploads_base, $sim_wp_dir, $google_map_domain, $sim_wp_path, $sim_wp_uploads_path, $sim_wp_map_language, $sim_wp_vars, $admin_int_array;
$admin_int_array = array();
$google_api_key=(trim($sim_wp_vars['sim_google_api_key'])!="")? trim($sim_wp_vars['sim_google_api_key']) : "";
 if($google_api_key!=''){
	$sim_google_api_key='key='.$sim_wp_vars['sim_google_api_key'].'&';	
	}else{
	$sim_google_api_key='';	
	} 
wp_enqueue_script( 'prettyPhoto', sim_WP_JS_BASE."/jquery.prettyPhoto.js", "jQuery");
wp_enqueue_script( 'sim_wp_func', sim_WP_JS_BASE."/functions.js", "jQuery");
wp_enqueue_script('chosenJquery', sim_WP_JS_BASE."/chosen/chosen.jquery.js", "jQuery" );
wp_enqueue_script('chosenProto', sim_WP_JS_BASE."/chosen/chosen.proto.min.js", "jQuery" );
wp_enqueue_script( 'mega-superstorfinder' , 'https://maps.googleapis.com/maps/api/js?'.$sim_google_api_key.'sensor=false&libraries=places' , array( 'jquery' ) , '1.0' , true );
wp_enqueue_script('mega-chart', 'https://www.gstatic.com/charts/loader.js','jquery');
wp_enqueue_script('mega-google-load', 'https://www.google.com/jsapi','jquery');
wp_enqueue_script('mega-finder' , sim_WP_JS_BASE.'/super-store-finder.js' , array( 'jquery' ) , '1.0' , true );
wp_enqueue_script('nicEdit', sim_WP_JS_BASE."/nicEdit.js", "jQuery" );
wp_enqueue_script('settingMap', sim_WP_JS_BASE."/settings.js", "jQuery");

        print "<script type='text/javascript'>";
		$admin_js = "
		var mapDataCount = new Array();
		var superIntArray = [];
		var marker_map_color='".$sim_wp_vars['marker_map_color']."';
        var sim_wp_dir='".$sim_wp_dir."';
        var sim_wp_google_map_country='".$sim_wp_vars['google_map_country']."';
		var sim_markersize=".$sim_wp_vars['style_marker_size'].";
        var sim_wp_base='".sim_WP_BASE."';
        var sim_wp_path='".sim_WP_PATH."';
		var style_map_color = '';
        var sim_wp_uploads_base='".sim_WP_UPLOADS_BASE."';
        var sim_wp_uploads_path='".sim_WP_UPLOADS_PATH."';
        var sim_wp_addons_base=sim_wp_uploads_base+'".str_replace(sim_WP_UPLOADS_BASE, '', sim_WP_ADDONS_BASE)."';
        var sim_wp_addons_path=sim_wp_uploads_path+'".str_replace(sim_WP_UPLOADS_PATH, '', sim_WP_ADDONS_PATH)."';
        var sim_wp_includes_base=sim_wp_base+'".str_replace(sim_WP_BASE, '', sim_WP_INCLUDES_BASE)."';
        var sim_wp_includes_path=sim_wp_path+'".str_replace(sim_WP_PATH, '', sim_WP_INCLUDES_PATH)."';
        var sim_wp_cache_path=sim_wp_uploads_path+'".str_replace(sim_WP_UPLOADS_PATH, '', sim_WP_CACHE_PATH)."';
        var sim_wp_pages_base=sim_wp_base+'".str_replace(sim_WP_BASE, '', sim_WP_PAGES_BASE)."'";
        print preg_replace("@[\\\]@", "\\\\\\", $admin_js); 
        print "</script>\n";

        if (preg_match("@add-store\.php|locations\.php@", $_SERVER['REQUEST_URI'])) {
			if (!file_exists(sim_WP_ADDONS_PATH."/point-click-add/point-click-add.js")) {
				$sens=(!empty($sim_wp_vars['sensor']))? "sensor=".$sim_wp_vars['sensor'] : "sensor=false" ;
				$lang_loc=(!empty($sim_wp_vars['map_language']))? "&amp;language=".$sim_wp_vars['map_language'] : "" ; 
				$region_loc=(!empty($sim_wp_vars['map_region']))? "&amp;region=".$sim_wp_vars['map_region'] : "" ;
				$key=(!empty($sim_wp_vars['api_key']))? "&amp;key=".$sim_wp_vars['api_key'] : "" ;
			}

            if (file_exists(sim_WP_ADDONS_PATH."/point-click-add/point-click-add.js")) {
				$sens=(!empty($sim_wp_vars['sensor']))? "sensor=".$sim_wp_vars['sensor'] : "sensor=false" ;
				$char_enc='';
				$google_map_domain="";
				//$api=sim_wp_data('store_locator_api_key');
			}
        }
		if (function_exists('do_sim_wp_hook')){do_sim_wp_hook('sim_wp_addon_admin_scripts');}
}

function sim_wp_remove_conflicting_scripts(){
	if (preg_match("@".sim_WP_DIR."@", $_SERVER['REQUEST_URI'])){
		wp_dequeue_script('ui-tabs'); 
	}
}

add_action('admin_enqueue_scripts', 'sim_wp_remove_conflicting_scripts');
add_action( 'admin_enqueue_scripts', 'mw_enqueue_color_pickers' );
function mw_enqueue_color_pickers( $hook_suffix ) {
    // first check that $hook_suffix is appropriate for your administrator's page
    wp_enqueue_style( 'wp-color-picker' );
    wp_enqueue_script( 'my-script-handle', plugins_url('js/docs.js', __FILE__ ), array( 'wp-color-picker' ), false, true );
}

function sim_wp_add_admin_stylesheet() {
  		global $sim_wp_base;
		wp_enqueue_style( 'mega-font-awesome' , sim_WP_CSS_BASE.'/font-awesome/css/font-awesome.css' , true , '4.1' );
		wp_enqueue_style( 'mega-sim-wp-admin' , sim_WP_CSS_BASE.'/sim-wp-admin.css' , true , '1.0' );
		wp_enqueue_style( 'mega-sim-wp-font' , sim_WP_CSS_BASE.'/sim-wp-pop.css' , true , '1.0' );
		wp_enqueue_style( 'mega-sim-wp-chosen' , sim_WP_JS_BASE.'/chosen/chosen.min.css' , true , '1.0' );
		// Chosen
}

/*---------------------------------*/

function sim_wp_sim_set_query_defaults() {
	global $where, $o, $d, $sim_wp_searchable_columns, $wpdb;
	$extra="";  
	if (function_exists("do_sim_wp_hook") && !empty($sim_wp_searchable_columns) && !empty($_GET['q'])) {
		foreach ($sim_wp_searchable_columns as $value) {
			$extra .= $wpdb->prepare(" OR $value LIKE '%%%s%%'", $_GET['q']);
		}
	}
	$where=(!empty($_GET['q']))? $wpdb->prepare(" WHERE sim_wp_name LIKE '%%%s%%' OR sim_wp_description LIKE '%%%s%%' OR sim_wp_map_region LIKE '%%%s%%' OR sim_wp_locations LIKE '%%%s%%'", $_GET['q'], $_GET['q'], $_GET['q'], $_GET['q'])." ".$extra : "" ; //die($where);
	$o=(!empty($_GET['o']))? esc_sql($_GET['o']) : "sim_wp_id";
	$d=(empty($_GET['d']) || $_GET['d']=="ASC")? "DESC" : "ASC";
}


function sim_set_query_defaults() {sim_wp_sim_set_query_defaults();}
/*--------------------------------------------------------------*/

function sim_do_hyperlink(&$text, $target="'_blank'", $type="both"){
  if ($type=="both" || $type=="protocol") {	
   $text = preg_replace("@[a-zA-Z]+://([.]?[a-zA-Z0-9_/?&amp;%20,=\-\+\-\#])+@s", "<a href=\"\\0\" target=$target>\\0</a>", $text);
  }

  if ($type=="both" || $type=="noprotocol") {
   $text = preg_replace("@(^| )(www([.]?[a-zA-Z0-9_/=-\+-\#])*)@s", "\\1<a href=\"http://\\2\" target=$target>\\2</a>", $text);
  }
  return $text;
}

/*-------------------------------------------------------------*/

function sim_comma($a) {
	$a=str_replace('"', "&quot;", $a);
	$a=str_replace("'", "&#39;", $a);
	$a=str_replace(">", "&gt;", $a);
	$a=str_replace("<", "&lt;", $a);
	$a=str_replace(" & ", " &amp; ", $a);
	return str_replace("," ,"&#44;" ,$a);
}

/*------------------------------------------------------------*/

if (!function_exists('addon_activation_message')) {
	function addon_activation_message($url_of_upgrade="") {
		global $sim_wp_dir, $text_domain;
		print "<div style='background-color:#eee; border:solid silver 1px; padding:7px; color:black; display:block;'>".__("You haven't activated this upgrade yet", sim_WP_TEXT_DOMAIN).". ";
		if (function_exists('do_sim_wp_hook') && !preg_match("/addons\-platform/", $url_of_upgrade) ){
			print "<a href='".sim_WP_ADDONS_PAGE."'>".__("Activate", sim_WP_TEXT_DOMAIN)."</a></div><br>";
		} else {
			print __("Go to pull-out Dashboard, and activate under 'Activation Keys' section.", sim_WP_TEXT_DOMAIN)."</div><br>";
		}
	}
}

/*-----------------------------------------------------------*/

function sim_url_test($url){
	if (preg_match("@^https?://@i", $url)) {
		return TRUE; 
	} else {
		return FALSE; 
	}
}

/*---------------------------------------------------------------*/

function sim_wp_neat_title($ttl,$separator="_") {
	$normalizeChars = array(
    'Š'=>'S', 'š'=>'s', 'Ð'=>'Dj','Ž'=>'Z', 'ž'=>'z', 'À'=>'A', 'Á'=>'A', 'Â'=>'A', 'Ã'=>'A', 'Ä'=>'A',
    'Å'=>'A', 'Æ'=>'A', 'Ç'=>'C', 'È'=>'E', 'É'=>'E', 'Ê'=>'E', 'Ë'=>'E', 'Ì'=>'I', 'Í'=>'I', 'Î'=>'I',
    'Ï'=>'I', 'Ñ'=>'N', 'Ò'=>'O', 'Ó'=>'O', 'Ô'=>'O', 'Õ'=>'O', 'Ö'=>'O', 'Ø'=>'O', 'Ù'=>'U', 'Ú'=>'U',
    'Û'=>'U', 'Ü'=>'U', 'Ý'=>'Y', 'Þ'=>'B', 'ß'=>'Ss','à'=>'a', 'á'=>'a', 'â'=>'a', 'ã'=>'a', 'ä'=>'a',
    'å'=>'a', 'æ'=>'a', 'ç'=>'c', 'è'=>'e', 'é'=>'e', 'ê'=>'e', 'ë'=>'e', 'ì'=>'i', 'í'=>'i', 'î'=>'i',
    'ï'=>'i', 'ð'=>'o', 'ñ'=>'n', 'ò'=>'o', 'ó'=>'o', 'ô'=>'o', 'õ'=>'o', 'ö'=>'o', 'ø'=>'o', 'ù'=>'u',
    'ú'=>'u', 'û'=>'u', 'ü'=>'u', 'ý'=>'y', 'ý'=>'y', 'þ'=>'b', 'ÿ'=>'y', 'ƒ'=>'f', 
    'ă'=>'a', 'î'=>'i', 'â'=>'a', 'ș'=>'s', 'ț'=>'t', 'Ă'=>'A', 'Î'=>'I', 'Â'=>'A', 'Ș'=>'S', 'Ț'=>'T');
	$ttl = strtr($ttl, $normalizeChars);
	$ttl = html_entity_decode( str_replace("&#39;","'",$ttl) );
	$ttl = preg_replace("/@+/", "$separator", 
			preg_replace("/[^[:alnum:]]/", "@", 
				trim(
					preg_replace("/[^[:alnum:]]/", " ", 
						str_replace("'", "", 
							sim_wp_truncate(
								trim(
									strtolower($ttl)
								), 
							100)
						)
					)
				)
			)
		);
	return $ttl;
}

/*-------------------------------*/

function sim_wp_truncate($var,$length=50,$mode="return", $type=1) {
	if (strlen($var)>$length) {
		if ($type==1) { 
			$var=substr($var,0,$length);
			$var=preg_replace("@[[:space:]]{1}.{1,10}$@s", "", $var); 
			$var=$var."...";
		}

		elseif ($type==2) { 
			$r_num=mt_rand();
			$r_num2=$r_num."_2";
			$var1=substr($var,0,$length);
			$var2=substr($var,$length, strlen($var)-$length);
			$var="<span id='$r_num'>$var1</span><span id='$r_num2' style='display:none'>".$var1.$var2."</span><a href='#' onclick=\"show('$r_num');show('$r_num2');this.innerHTML=(this.innerHTML.indexOf('more')!=-1)?'(...less)':'(more...)';return false;\">(more...)</a>";
		}
		elseif ($type==3) { 
			$var=substr($var,0,$length);
			$var=$var."...";
		}
	}

	if ($mode!="print") {
		return $var;
	}
	else {
		print $var;
	}
}

function sim_wp_ty($file){
	$ty = '';
	return $ty;
}

/*-----------------------------------------------------------*/

function sim_wp_data($setting_name, $i_u_d_s="select", $setting_value="") {
	global $wpdb;
	if ($i_u_d_s == "insert" || $i_u_d_s == "add" || $i_u_d_s == "update") {
		$setting_value = (is_array($setting_value))? serialize($setting_value) : $setting_value;
		$exists = $wpdb->get_var($wpdb->prepare("SELECT sim_wp_setting_id FROM ".sim_WP_SETTING_TABLE." WHERE sim_wp_setting_name = %s", $setting_name));
		if (!$exists) {	
			$q = $wpdb->prepare("INSERT INTO ".sim_WP_SETTING_TABLE." (sim_wp_setting_name, sim_wp_setting_value) VALUES (%s, %s)", $setting_name, $setting_value); 
		} else { 
			$q = $wpdb->prepare("UPDATE ".sim_WP_SETTING_TABLE." SET sim_wp_setting_value = %s WHERE sim_wp_setting_name = %s", $setting_value, $setting_name);
		}
		$wpdb->query($q);
	} elseif ($i_u_d_s == "delete") {
		$q = $wpdb->prepare("DELETE FROM ".sim_WP_SETTING_TABLE." WHERE sim_wp_setting_name = %s", $setting_name);
		$wpdb->query($q);
	} elseif ($i_u_d_s == "select" || $i_u_d_s == "get") {
		$q = $wpdb->prepare("SELECT sim_wp_setting_value FROM ".sim_WP_SETTING_TABLE." WHERE sim_wp_setting_name = %s", $setting_name);
		$r = $wpdb->get_var($q);
		$r = (@unserialize($r) !== false || $r === 'b:0;')? unserialize($r) : $r;  //checking if stored in serialized form
			return $r;
	  } 
}

/*----------------------------------------------------------------*/

function sim_wp_dyn_js($post_content=""){
	global $sim_wp_dir, $sim_wp_base, $sim_wp_uploads_base, $sim_wp_path, $sim_wp_uploads_path, $wpdb, $sim_wp_version, $pagename, $sim_wp_map_language, $post, $sim_wp_vars;
	print "<script type=\"text/javascript\">\n//<![CDATA[\n";
	$style_bg_color=(trim($sim_wp_vars['style_bg_color'])!="")? $sim_wp_vars['style_bg_color'] : "";
	$style_map_color=(trim($sim_wp_vars['style_map_color'])!="")? simParseToXML($sim_wp_vars['style_map_color']) : "";
	$style_marker_size=(trim($sim_wp_vars['style_marker_size'])!="")? simParseToXML($sim_wp_vars['style_marker_size']) : "10";
	$marker_map_color=(trim($sim_wp_vars['marker_map_color'])!="")? simParseToXML($sim_wp_vars['marker_map_color']) : "#1dba28";
	$style_width=(trim($sim_wp_vars['style_width'])!="")? simParseToXML($sim_wp_vars['style_width']) : "600";
	$sim_map_height=(trim($sim_wp_vars['sim_map_height'])!="")? simParseToXML($sim_wp_vars['sim_map_height']) : "400";
	$aspect_ratio=(trim($sim_wp_vars['aspect_ratio'])!="")? simParseToXML($sim_wp_vars['aspect_ratio']) : "true";
	$SimMapApiKey=(trim($sim_wp_vars['sim_google_api_key'])!="")? simParseToXML($sim_wp_vars['sim_google_api_key']) : "";
	
print  
"
var sim_wp_base='".sim_WP_BASE."';
var sim_markersize=".$style_marker_size.";
var default_distance = '';
var sim_map_height='".$sim_map_height."';
var marker_map_color='".$marker_map_color."';
var sim_aspect_ratio='".$aspect_ratio."';
var sim_post_id;
var pausecontent = new Array();
var zoomhere_zoom = '';
var geo_settings = '';
var sim_wp_map_code; 
var SimMapApiKey = '".$SimMapApiKey."';";

print "\n
var style_map_color = '$style_map_color';
var sim_wp_uploads_base='".sim_WP_UPLOADS_BASE."';
var sim_wp_addons_base=sim_wp_uploads_base+'".str_replace(sim_WP_UPLOADS_BASE, '', sim_WP_ADDONS_BASE)."';
var sim_wp_includes_base=sim_wp_base+'".str_replace(sim_WP_BASE, '', sim_WP_INCLUDES_BASE)."';
var sim_wp_zoom_level=''; 

\n";
	print "//]]>\n</script>\n";
	if (function_exists("do_sim_wp_hook")){do_sim_wp_hook('sim_wp_addon_head_scripts'); }
	if (function_exists("do_sim_wp_hook")){ 
		print "<script>\n//<![CDATA[\n";
		sim_wp_js_hooks();
		print "\n//]]>\n</script>\n";
	}

}

function sim_map_build_region_select_options() {
				$regions = array (
					array('name' => 'World', 'value' => 'world,countries'),
					array('name' => 'World - Continent Regions', 'value' => 'world,continents'),
					array('name' => 'World - Subcontinents Regions', 'value' => 'world,subcontinents'),
					array('name' => 'Africa', 'value' => '002,countries'),
					array('name' => 'Africa - Subcontinents Regions', 'value' => '002,subcontinents'),
					array('name' => 'Africa - Northern Africa', 'value' => '015,countries'),
					array('name' => 'Africa - Western Africa', 'value' => '011,countries'),
					array('name' => 'Africa - Middle Africa', 'value' => '017,countries'),
					array('name' => 'Africa - Eastern Africa', 'value' => '014,countries'),
					array('name' => 'Africa - Southern Africa', 'value' => '018,countries'),
					array('name' => 'Europe', 'value' => '150,countries'),
					array('name' => 'Europe - Subcontinents Regions', 'value' => '150,subcontinents'),
					array('name' => 'Europe - Northern Europe', 'value' => '154,countries'),
					array('name' => 'Europe - Western Europe', 'value' => '155,countries'),
					array('name' => 'Europe - Eastern Europe', 'value' => '151,countries'),
					array('name' => 'Europe - Southern Europe', 'value' => '039,countries'),
					array('name' => 'Americas', 'value' => '019,countries'),
					array('name' => 'Americas - Subcontinents Regions', 'value' => '019,subcontinents'),
					array('name' => 'Americas - Northern America', 'value' => '021,countries'),
					array('name' => 'Americas - Caribbean', 'value' => '029,countries'),
					array('name' => 'Americas - Central America', 'value' => '013,countries'),
					array('name' => 'Americas - South America', 'value' => '005,countries'),
					array('name' => 'Asia', 'value' => '142,countries'),
					array('name' => 'Asia - Subcontinents Regions', 'value' => '142,subcontinents'),					
					array('name' => 'Asia - Central Asia', 'value' => '143,countries'),
					array('name' => 'Asia - Eastern Asia', 'value' => '030,countries'),
					array('name' => 'Asia - Southern Asia', 'value' => '034,countries'),
					array('name' => 'Asia - South-Eastern Asia', 'value' => '035,countries'),
					array('name' => 'Asia - Western Asia', 'value' => '145,countries'),
					array('name' => 'Oceania', 'value' => '009,countries'),
					array('name' => 'Oceania - Subcontinents Regions', 'value' => '009,subcontinents'),
					array('name' => 'Oceania - Australia and New Zealand', 'value' => '053,countries'),
					array('name' => 'Oceania - Melanesia', 'value' => '054,countries'),
					array('name' => 'Oceania - Micronesia', 'value' => '057,countries'),
					array('name' => 'Oceania - Polynesia', 'value' => '061,countries'),
					array('name' => 'United States of America', 'value' => 'US,countries'),
					array('name' => 'United States of America - States', 'value' => 'US,provinces'),
					array('name' => 'United States of America - Metropolitan Areas', 'value' => 'US,metros'),
					array('name' => 'USA - Alabama - Metropolitan Areas', 'value' => 'US-AL,metros'),
					array('name' => 'USA - Alabama State', 'value' => 'US-AL,provinces'),
					array('name' => 'USA - Alaska - Metropolitan Areas', 'value' => 'US-AK,metros'),
					array('name' => 'USA - Alaska State', 'value' => 'US-AK,provinces'),
					array('name' => 'USA - Arizona - Metropolitan Areas', 'value' => 'US-AZ,metros'),
					array('name' => 'USA - Arizona State', 'value' => 'US-AZ,provinces'),
					array('name' => 'USA - Arkansas - Metropolitan Areas', 'value' => 'US-AR,metros'),
					array('name' => 'USA - Arkansas State', 'value' => 'US-AR,provinces'),
					array('name' => 'USA - California - Metropolitan Areas', 'value' => 'US-CA,metros'),
					array('name' => 'USA - California State', 'value' => 'US-CA,provinces'),
					array('name' => 'USA - Colorado - Metropolitan Areas', 'value' => 'US-CO,metros'),
					array('name' => 'USA - Colorado State', 'value' => 'US-CO,provinces'),
					array('name' => 'USA - Connecticut - Metropolitan Areas', 'value' => 'US-CT,metros'),
					array('name' => 'USA - Connecticut State', 'value' => 'US-CT,provinces'),
					array('name' => 'USA - Delaware - Metropolitan Areas', 'value' => 'US-DE,metros'),
					array('name' => 'USA - Delaware State', 'value' => 'US-DE,provinces'),
					array('name' => 'USA - District of Columbia - Metropolitan Areas', 'value' => 'US-DC,metros'),
					array('name' => 'USA - District of Columbia', 'value' => 'US-DC,provinces'),
					array('name' => 'USA - Florida - Metropolitan Areas', 'value' => 'US-FL,metros'),
					array('name' => 'USA - Florida State', 'value' => 'US-FL,provinces'),
					array('name' => 'USA - Georgia - Metropolitan Areas', 'value' => 'US-GA,metros'),
					array('name' => 'USA - Georgia State', 'value' => 'US-GA,provinces'),
					array('name' => 'USA - Hawaii - Metropolitan Areas', 'value' => 'US-HI,metros'),
					array('name' => 'USA - Hawaii State', 'value' => 'US-HI,provinces'),
					array('name' => 'USA - Idaho - Metropolitan Areas', 'value' => 'US-ID,metros'),
					array('name' => 'USA - Idaho State', 'value' => 'US-ID,provinces'),
					array('name' => 'USA - Illinois - Metropolitan Areas', 'value' => 'US-IL,metros'),
					array('name' => 'USA - Illinois State', 'value' => 'US-IL,provinces'),
					array('name' => 'USA - Indiana - Metropolitan Areas', 'value' => 'US-IN,metros'),
					array('name' => 'USA - Indiana State', 'value' => 'US-IN,provinces'),
					array('name' => 'USA - Iowa - Metropolitan Areas', 'value' => 'US-IA,metros'),
					array('name' => 'USA - Iowa State', 'value' => 'US-IA,provinces'),
					array('name' => 'USA - Kansas - Metropolitan Areas', 'value' => 'US-KS,metros'),
					array('name' => 'USA - Kansas State', 'value' => 'US-KS,provinces'),
					array('name' => 'USA - Kentucky - Metropolitan Areas', 'value' => 'US-KY,metros'),
					array('name' => 'USA - Kentucky State', 'value' => 'US-KY,provinces'),
					array('name' => 'USA - Louisiana - Metropolitan Areas', 'value' => 'US-LA,metros'),
					array('name' => 'USA - Louisiana State', 'value' => 'US-LA,provinces'),
					array('name' => 'USA - Maine - Metropolitan Areas', 'value' => 'US-ME,metros'),
					array('name' => 'USA - Maine State', 'value' => 'US-ME,provinces'),
					array('name' => 'USA - Maryland - Metropolitan Areas', 'value' => 'US-MD,metros'),
					array('name' => 'USA - Maryland State', 'value' => 'US-MD,provinces'),
					array('name' => 'USA - Massachusetts - Metropolitan Areas', 'value' => 'US-MA,metros'),
					array('name' => 'USA - Massachusetts State', 'value' => 'US-MA,provinces'),
					array('name' => 'USA - Michigan - Metropolitan Areas', 'value' => 'US-MI,metros'),
					array('name' => 'USA - Michigan State', 'value' => 'US-MI,provinces'),
					array('name' => 'USA - Minnesota - Metropolitan Areas', 'value' => 'US-MN,metros'),
					array('name' => 'USA - Minnesota State', 'value' => 'US-MN,provinces'),
					array('name' => 'USA - Mississippi - Metropolitan Areas', 'value' => 'US-MS,metros'),
					array('name' => 'USA - Mississippi State', 'value' => 'US-MS,provinces'),
					array('name' => 'USA - Missouri - Metropolitan Areas', 'value' => 'US-MO,metros'),
					array('name' => 'USA - Missouri State', 'value' => 'US-MO,provinces'),
					array('name' => 'USA - Montana - Metropolitan Areas', 'value' => 'US-MT,metros'),
					array('name' => 'USA - Montana State', 'value' => 'US-MT,provinces'),
					array('name' => 'USA - Nebraska - Metropolitan Areas', 'value' => 'US-NE,metros'),
					array('name' => 'USA - Nebraska State', 'value' => 'US-NE,provinces'),
					array('name' => 'USA - Nevada - Metropolitan Areas', 'value' => 'US-NV,metros'),
					array('name' => 'USA - Nevada State', 'value' => 'US-NV,provinces'),
					array('name' => 'USA - New Hampshire - Metropolitan Areas', 'value' => 'US-NH,metros'),
					array('name' => 'USA - New Hampshire State', 'value' => 'US-NH,provinces'),
					array('name' => 'USA - New Jersey - Metropolitan Areas', 'value' => 'US-NJ,metros'),
					array('name' => 'USA - New Jersey State', 'value' => 'US-NJ,provinces'),
					array('name' => 'USA - New Mexico - Metropolitan Areas', 'value' => 'US-NM,metros'),
					array('name' => 'USA - New Mexico State', 'value' => 'US-NM,provinces'),
					array('name' => 'USA - New York - Metropolitan Areas', 'value' => 'US-NY,metros'),
					array('name' => 'USA - New York State', 'value' => 'US-NY,provinces'),
					array('name' => 'USA - North Carolina - Metropolitan Areas', 'value' => 'US-NC,metros'),
					array('name' => 'USA - North Carolina State', 'value' => 'US-NC,provinces'),
					array('name' => 'USA - North Dakota - Metropolitan Areas', 'value' => 'US-ND,metros'),
					array('name' => 'USA - North Dakota State', 'value' => 'US-ND,provinces'),
					array('name' => 'USA - Ohio - Metropolitan Areas', 'value' => 'US-OH,metros'),
					array('name' => 'USA - Ohio State', 'value' => 'US-OH,provinces'),
					array('name' => 'USA - Oklahoma - Metropolitan Areas', 'value' => 'US-OK,metros'),
					array('name' => 'USA - Oklahoma State', 'value' => 'US-OK,provinces'),
					array('name' => 'USA - Oregon - Metropolitan Areas', 'value' => 'US-OR,metros'),
					array('name' => 'USA - Oregon State', 'value' => 'US-OR,provinces'),
					array('name' => 'USA - Pennsylvania - Metropolitan Areas', 'value' => 'US-PA,metros'),
					array('name' => 'USA - Pennsylvania State', 'value' => 'US-PA,provinces'),
					array('name' => 'USA - Rhode Island - Metropolitan Areas', 'value' => 'US-RI,metros'),
					array('name' => 'USA - Rhode Island State', 'value' => 'US-RI,provinces'),
					array('name' => 'USA - South Carolina - Metropolitan Areas', 'value' => 'US-SC,metros'),
					array('name' => 'USA - South Carolina State', 'value' => 'US-SC,provinces'),
					array('name' => 'USA - South Dakota - Metropolitan Areas', 'value' => 'US-SD,metros'),
					array('name' => 'USA - South Dakota State', 'value' => 'US-SD,provinces'),
					array('name' => 'USA - Tennessee - Metropolitan Areas', 'value' => 'US-TN,metros'),
					array('name' => 'USA - Tennessee State', 'value' => 'US-TN,provinces'),
					array('name' => 'USA - Texas - Metropolitan Areas', 'value' => 'US-TX,metros'),
					array('name' => 'USA - Texas State', 'value' => 'US-TX,provinces'),
					array('name' => 'USA - Utah - Metropolitan Areas', 'value' => 'US-UT,metros'),
					array('name' => 'USA - Utah State', 'value' => 'US-UT,provinces'),
					array('name' => 'USA - Vermont - Metropolitan Areas', 'value' => 'US-VT,metros'),
					array('name' => 'USA - Vermont State', 'value' => 'US-VT,provinces'),
					array('name' => 'USA - Virginia - Metropolitan Areas', 'value' => 'US-VA,metros'),
					array('name' => 'USA - Virginia State', 'value' => 'US-VA,provinces'),
					array('name' => 'USA - Washington - Metropolitan Areas', 'value' => 'US-WA,metros'),
					array('name' => 'USA - Washington State', 'value' => 'US-WA,provinces'),
					array('name' => 'USA - West Virginia - Metropolitan Areas', 'value' => 'US-WV,metros'),
					array('name' => 'USA - West Virginia State', 'value' => 'US-WV,provinces'),
					array('name' => 'USA - Wisconsin - Metropolitan Areas', 'value' => 'US-WI,metros'),
					array('name' => 'USA - Wisconsin State', 'value' => 'US-WI,provinces'),
					array('name' => 'USA - Wyoming - Metropolitan Areas', 'value' => 'US-WY,metros'),
					array('name' => 'USA - Wyoming State', 'value' => 'US-WY,provinces'),					
					array('name' => 'Afghanistan', 'value' => 'AF,countries'),
					array('name' => 'Afghanistan - Provinces', 'value' => 'AF,provinces'),
					array('name' => 'Aland Islands', 'value' => 'AX,countries'),
					array('name' => 'Aland Islands - Provinces', 'value' => 'AX,provinces'),
					array('name' => 'Albania', 'value' => 'AL,countries'),
					array('name' => 'Albania - Provinces', 'value' => 'AL,provinces'),
					array('name' => 'Algeria', 'value' => 'DZ,countries'),
					array('name' => 'Algeria - Provinces', 'value' => 'DZ,provinces'),
					array('name' => 'American Samoa', 'value' => 'AS,countries'),
					array('name' => 'American Samoa - Provinces', 'value' => 'AS,provinces'),
					array('name' => 'Andorra', 'value' => 'AD,countries'),
					array('name' => 'Andorra - Provinces', 'value' => 'AD,provinces'),
					array('name' => 'Angola', 'value' => 'AO,countries'),
					array('name' => 'Angola - Provinces', 'value' => 'AO,provinces'),
					array('name' => 'Anguilla', 'value' => 'AI,countries'),
					array('name' => 'Anguilla - Provinces', 'value' => 'AI,provinces'),
					array('name' => 'Antarctica', 'value' => 'AQ,countries'),
					array('name' => 'Antarctica - Provinces', 'value' => 'AQ,provinces'),
					array('name' => 'Antigua and Barbuda', 'value' => 'AG,countries'),
					array('name' => 'Antigua and Barbuda - Provinces', 'value' => 'AG,provinces'),
					array('name' => 'Argentina', 'value' => 'AR,countries'),
					array('name' => 'Argentina - Provinces', 'value' => 'AR,provinces'),
					array('name' => 'Armenia', 'value' => 'AM,countries'),
					array('name' => 'Armenia - Provinces', 'value' => 'AM,provinces'),
					array('name' => 'Aruba', 'value' => 'AW,countries'),
					array('name' => 'Aruba - Provinces', 'value' => 'AW,provinces'),
					array('name' => 'Australia', 'value' => 'AU,countries'),
					array('name' => 'Australia - Provinces', 'value' => 'AU,provinces'),
					array('name' => 'Austria', 'value' => 'AT,countries'),
					array('name' => 'Austria - Provinces', 'value' => 'AT,provinces'),
					array('name' => 'Azerbaijan', 'value' => 'AZ,countries'),
					array('name' => 'Azerbaijan - Provinces', 'value' => 'AZ,provinces'),
					array('name' => 'Bahamas', 'value' => 'BS,countries'),
					array('name' => 'Bahamas - Provinces', 'value' => 'BS,provinces'),
					array('name' => 'Bahrain', 'value' => 'BH,countries'),
					array('name' => 'Bahrain - Provinces', 'value' => 'BH,provinces'),
					array('name' => 'Bangladesh', 'value' => 'BD,countries'),
					array('name' => 'Bangladesh - Provinces', 'value' => 'BD,provinces'),
					array('name' => 'Barbados', 'value' => 'BB,countries'),
					array('name' => 'Barbados - Provinces', 'value' => 'BB,provinces'),
					array('name' => 'Belarus', 'value' => 'BY,countries'),
					array('name' => 'Belarus - Provinces', 'value' => 'BY,provinces'),
					array('name' => 'Belgium', 'value' => 'BE,countries'),
					array('name' => 'Belgium - Provinces', 'value' => 'BE,provinces'),
					array('name' => 'Belize', 'value' => 'BZ,countries'),
					array('name' => 'Belize - Provinces', 'value' => 'BZ,provinces'),
					array('name' => 'Benin', 'value' => 'BJ,countries'),
					array('name' => 'Benin - Provinces', 'value' => 'BJ,provinces'),
					array('name' => 'Bermuda', 'value' => 'BM,countries'),
					array('name' => 'Bermuda - Provinces', 'value' => 'BM,provinces'),
					array('name' => 'Bhutan', 'value' => 'BT,countries'),
					array('name' => 'Bhutan - Provinces', 'value' => 'BT,provinces'),
					array('name' => 'Bolivia, Plurinational State of', 'value' => 'BO,countries'),
					array('name' => 'Bolivia, Plurinational State of - Provinces', 'value' => 'BO,provinces'),
					array('name' => 'Bonaire, Sint Eustatius and Saba', 'value' => 'BQ,countries'),
					array('name' => 'Bonaire, Sint Eustatius and Saba - Provinces', 'value' => 'BQ,provinces'),
					array('name' => 'Bosnia and Herzegovina', 'value' => 'BA,countries'),
					array('name' => 'Bosnia and Herzegovina - Provinces', 'value' => 'BA,provinces'),
					array('name' => 'Botswana', 'value' => 'BW,countries'),
					array('name' => 'Botswana - Provinces', 'value' => 'BW,provinces'),
					array('name' => 'Bouvet Island', 'value' => 'BV,countries'),
					array('name' => 'Bouvet Island - Provinces', 'value' => 'BV,provinces'),
					array('name' => 'Brazil', 'value' => 'BR,countries'),
					array('name' => 'Brazil - Provinces', 'value' => 'BR,provinces'),
					array('name' => 'British Indian Ocean Territory', 'value' => 'IO,countries'),
					array('name' => 'British Indian Ocean Territory - Provinces', 'value' => 'IO,provinces'),
					array('name' => 'Brunei Darussalam', 'value' => 'BN,countries'),
					array('name' => 'Brunei Darussalam - Provinces', 'value' => 'BN,provinces'),
					array('name' => 'Bulgaria', 'value' => 'BG,countries'),
					array('name' => 'Bulgaria - Provinces', 'value' => 'BG,provinces'),
					array('name' => 'Burkina Faso', 'value' => 'BF,countries'),
					array('name' => 'Burkina Faso - Provinces', 'value' => 'BF,provinces'),
					array('name' => 'Burundi', 'value' => 'BI,countries'),
					array('name' => 'Burundi - Provinces', 'value' => 'BI,provinces'),
					array('name' => 'Cambodia', 'value' => 'KH,countries'),
					array('name' => 'Cambodia - Provinces', 'value' => 'KH,provinces'),
					array('name' => 'Cameroon', 'value' => 'CM,countries'),
					array('name' => 'Cameroon - Provinces', 'value' => 'CM,provinces'),
					array('name' => 'Canada', 'value' => 'CA,countries'),
					array('name' => 'Canada - Provinces', 'value' => 'CA,provinces'),
					array('name' => 'Cape Verde', 'value' => 'CV,countries'),
					array('name' => 'Cape Verde - Provinces', 'value' => 'CV,provinces'),
					array('name' => 'Cayman Islands', 'value' => 'KY,countries'),
					array('name' => 'Cayman Islands - Provinces', 'value' => 'KY,provinces'),
					array('name' => 'Central African Republic', 'value' => 'CF,countries'),
					array('name' => 'Central African Republic - Provinces', 'value' => 'CF,provinces'),
					array('name' => 'Chad', 'value' => 'TD,countries'),
					array('name' => 'Chad - Provinces', 'value' => 'TD,provinces'),
					array('name' => 'Chile', 'value' => 'CL,countries'),
					array('name' => 'Chile - Provinces', 'value' => 'CL,provinces'),
					array('name' => 'China', 'value' => 'CN,countries'),
					array('name' => 'China - Provinces', 'value' => 'CN,provinces'),
					array('name' => 'Christmas Island', 'value' => 'CX,countries'),
					array('name' => 'Christmas Island - Provinces', 'value' => 'CX,provinces'),
					array('name' => 'Cocos (Keeling) Islands', 'value' => 'CC,countries'),
					array('name' => 'Cocos (Keeling) Islands - Provinces', 'value' => 'CC,provinces'),
					array('name' => 'Colombia', 'value' => 'CO,countries'),
					array('name' => 'Colombia - Provinces', 'value' => 'CO,provinces'),
					array('name' => 'Comoros', 'value' => 'KM,countries'),
					array('name' => 'Comoros - Provinces', 'value' => 'KM,provinces'),
					array('name' => 'Congo', 'value' => 'CG,countries'),
					array('name' => 'Congo - Provinces', 'value' => 'CG,provinces'),
					array('name' => 'Congo, the Democratic Republic of the', 'value' => 'CD,countries'),
					array('name' => 'Congo, the Democratic Republic of the - Provinces', 'value' => 'CD,provinces'),
					array('name' => 'Cook Islands', 'value' => 'CK,countries'),
					array('name' => 'Cook Islands - Provinces', 'value' => 'CK,provinces'),
					array('name' => 'Costa Rica', 'value' => 'CR,countries'),
					array('name' => 'Costa Rica - Provinces', 'value' => 'CR,provinces'),
					array('name' => 'Cote d\'Ivoire ', 'value' => 'CI,countries'),
					array('name' => 'Cote d\'Ivoire  - Provinces', 'value' => 'CI,provinces'),
					array('name' => 'Croatia', 'value' => 'HR,countries'),
					array('name' => 'Croatia - Provinces', 'value' => 'HR,provinces'),
					array('name' => 'Cuba', 'value' => 'CU,countries'),
					array('name' => 'Cuba - Provinces', 'value' => 'CU,provinces'),
					array('name' => 'Curaçao', 'value' => 'CW,countries'),
					array('name' => 'Curaçao - Provinces', 'value' => 'CW,provinces'),
					array('name' => 'Cyprus', 'value' => 'CY,countries'),
					array('name' => 'Cyprus - Provinces', 'value' => 'CY,provinces'),
					array('name' => 'Czech Republic', 'value' => 'CZ,countries'),
					array('name' => 'Czech Republic - Provinces', 'value' => 'CZ,provinces'),
					array('name' => 'Denmark', 'value' => 'DK,countries'),
					array('name' => 'Denmark - Provinces', 'value' => 'DK,provinces'),
					array('name' => 'Djibouti', 'value' => 'DJ,countries'),
					array('name' => 'Djibouti - Provinces', 'value' => 'DJ,provinces'),
					array('name' => 'Dominica', 'value' => 'DM,countries'),
					array('name' => 'Dominica - Provinces', 'value' => 'DM,provinces'),
					array('name' => 'Dominican Republic', 'value' => 'DO,countries'),
					array('name' => 'Dominican Republic - Provinces', 'value' => 'DO,provinces'),
					array('name' => 'Ecuador', 'value' => 'EC,countries'),
					array('name' => 'Ecuador - Provinces', 'value' => 'EC,provinces'),
					array('name' => 'Egypt', 'value' => 'EG,countries'),
					array('name' => 'Egypt - Provinces', 'value' => 'EG,provinces'),
					array('name' => 'El Salvador', 'value' => 'SV,countries'),
					array('name' => 'El Salvador - Provinces', 'value' => 'SV,provinces'),
					array('name' => 'Equatorial Guinea', 'value' => 'GQ,countries'),
					array('name' => 'Equatorial Guinea - Provinces', 'value' => 'GQ,provinces'),
					array('name' => 'Eritrea', 'value' => 'ER,countries'),
					array('name' => 'Eritrea - Provinces', 'value' => 'ER,provinces'),
					array('name' => 'Estonia', 'value' => 'EE,countries'),
					array('name' => 'Estonia - Provinces', 'value' => 'EE,provinces'),
					array('name' => 'Ethiopia', 'value' => 'ET,countries'),
					array('name' => 'Ethiopia - Provinces', 'value' => 'ET,provinces'),
					array('name' => 'Falkland Islands (Malvinas)', 'value' => 'FK,countries'),
					array('name' => 'Falkland Islands (Malvinas) - Provinces', 'value' => 'FK,provinces'),
					array('name' => 'Faroe Islands', 'value' => 'FO,countries'),
					array('name' => 'Faroe Islands - Provinces', 'value' => 'FO,provinces'),
					array('name' => 'Fiji', 'value' => 'FJ,countries'),
					array('name' => 'Fiji - Provinces', 'value' => 'FJ,provinces'),
					array('name' => 'Finland', 'value' => 'FI,countries'),
					array('name' => 'Finland - Provinces', 'value' => 'FI,provinces'),
					array('name' => 'France', 'value' => 'FR,countries'),
					array('name' => 'France - Provinces', 'value' => 'FR,provinces'),
					array('name' => 'French Guiana', 'value' => 'GF,countries'),
					array('name' => 'French Guiana - Provinces', 'value' => 'GF,provinces'),
					array('name' => 'French Polynesia', 'value' => 'PF,countries'),
					array('name' => 'French Polynesia - Provinces', 'value' => 'PF,provinces'),
					array('name' => 'French Southern Territories', 'value' => 'TF,countries'),
					array('name' => 'French Southern Territories - Provinces', 'value' => 'TF,provinces'),
					array('name' => 'Gabon', 'value' => 'GA,countries'),
					array('name' => 'Gabon - Provinces', 'value' => 'GA,provinces'),
					array('name' => 'Gambia', 'value' => 'GM,countries'),
					array('name' => 'Gambia - Provinces', 'value' => 'GM,provinces'),
					array('name' => 'Georgia', 'value' => 'GE,countries'),
					array('name' => 'Georgia - Provinces', 'value' => 'GE,provinces'),
					array('name' => 'Germany', 'value' => 'DE,countries'),
					array('name' => 'Germany - Provinces', 'value' => 'DE,provinces'),
					array('name' => 'Ghana', 'value' => 'GH,countries'),
					array('name' => 'Ghana - Provinces', 'value' => 'GH,provinces'),
					array('name' => 'Gibraltar', 'value' => 'GI,countries'),
					array('name' => 'Gibraltar - Provinces', 'value' => 'GI,provinces'),
					array('name' => 'Greece', 'value' => 'GR,countries'),
					array('name' => 'Greece - Provinces', 'value' => 'GR,provinces'),
					array('name' => 'Greenland', 'value' => 'GL,countries'),
					array('name' => 'Greenland - Provinces', 'value' => 'GL,provinces'),
					array('name' => 'Grenada', 'value' => 'GD,countries'),
					array('name' => 'Grenada - Provinces', 'value' => 'GD,provinces'),
					array('name' => 'Guadeloupe', 'value' => 'GP,countries'),
					array('name' => 'Guadeloupe - Provinces', 'value' => 'GP,provinces'),
					array('name' => 'Guam', 'value' => 'GU,countries'),
					array('name' => 'Guam - Provinces', 'value' => 'GU,provinces'),
					array('name' => 'Guatemala', 'value' => 'GT,countries'),
					array('name' => 'Guatemala - Provinces', 'value' => 'GT,provinces'),
					array('name' => 'Guernsey', 'value' => 'GG,countries'),
					array('name' => 'Guernsey - Provinces', 'value' => 'GG,provinces'),
					array('name' => 'Guinea', 'value' => 'GN,countries'),
					array('name' => 'Guinea - Provinces', 'value' => 'GN,provinces'),
					array('name' => 'Guinea-Bissau', 'value' => 'GW,countries'),
					array('name' => 'Guinea-Bissau - Provinces', 'value' => 'GW,provinces'),
					array('name' => 'Guyana', 'value' => 'GY,countries'),
					array('name' => 'Guyana - Provinces', 'value' => 'GY,provinces'),
					array('name' => 'Haiti', 'value' => 'HT,countries'),
					array('name' => 'Haiti - Provinces', 'value' => 'HT,provinces'),
					array('name' => 'Heard Island and McDonald Islands', 'value' => 'HM,countries'),
					array('name' => 'Heard Island and McDonald Islands - Provinces', 'value' => 'HM,provinces'),
					array('name' => 'Holy See (Vatican City State)', 'value' => 'VA,countries'),
					array('name' => 'Honduras', 'value' => 'HN,countries'),
					array('name' => 'Honduras - Provinces', 'value' => 'HN,provinces'),
					array('name' => 'Hong Kong', 'value' => 'HK,countries'),
					array('name' => 'Hong Kong - Provinces', 'value' => 'HK,provinces'),
					array('name' => 'Hungary', 'value' => 'HU,countries'),
					array('name' => 'Hungary - Provinces', 'value' => 'HU,provinces'),
					array('name' => 'Iceland', 'value' => 'IS,countries'),
					array('name' => 'Iceland - Provinces', 'value' => 'IS,provinces'),
					array('name' => 'India', 'value' => 'IN,countries'),
					array('name' => 'India - Provinces', 'value' => 'IN,provinces'),
					array('name' => 'Indonesia', 'value' => 'ID,countries'),
					array('name' => 'Indonesia - Provinces', 'value' => 'ID,provinces'),
					array('name' => 'Iran, Islamic Republic of', 'value' => 'IR,countries'),
					array('name' => 'Iran, Islamic Republic of - Provinces', 'value' => 'IR,provinces'),
					array('name' => 'Iraq', 'value' => 'IQ,countries'),
					array('name' => 'Iraq - Provinces', 'value' => 'IQ,provinces'),
					array('name' => 'Ireland', 'value' => 'IE,countries'),
					array('name' => 'Ireland - Provinces', 'value' => 'IE,provinces'),
					array('name' => 'Isle of Man', 'value' => 'IM,countries'),
					array('name' => 'Isle of Man - Provinces', 'value' => 'IM,provinces'),
					array('name' => 'Israel', 'value' => 'IL,countries'),
					array('name' => 'Israel - Provinces', 'value' => 'IL,provinces'),
					array('name' => 'Italy', 'value' => 'IT,countries'),
					array('name' => 'Italy - Provinces', 'value' => 'IT,provinces'),
					array('name' => 'Jamaica', 'value' => 'JM,countries'),
					array('name' => 'Jamaica - Provinces', 'value' => 'JM,provinces'),
					array('name' => 'Japan', 'value' => 'JP,countries'),
					array('name' => 'Japan - Provinces', 'value' => 'JP,provinces'),
					array('name' => 'Jersey', 'value' => 'JE,countries'),
					array('name' => 'Jersey - Provinces', 'value' => 'JE,provinces'),
					array('name' => 'Jordan', 'value' => 'JO,countries'),
					array('name' => 'Jordan - Provinces', 'value' => 'JO,provinces'),
					array('name' => 'Kazakhstan', 'value' => 'KZ,countries'),
					array('name' => 'Kazakhstan - Provinces', 'value' => 'KZ,provinces'),
					array('name' => 'Kenya', 'value' => 'KE,countries'),
					array('name' => 'Kiribati', 'value' => 'KI,countries'),
					array('name' => 'Kiribati - Provinces', 'value' => 'KI,provinces'),
					array('name' => 'Korea, Democratic People\'s Republic of', 'value' => 'KP,countries'),
					array('name' => 'Korea, Democratic People\'s Republic of - Provinces', 'value' => 'KP,provinces'),
					array('name' => 'Korea, Republic of', 'value' => 'KR,countries'),
					array('name' => 'Korea, Republic of - Provinces', 'value' => 'KR,provinces'),
					array('name' => 'Kosovo', 'value' => 'XK,countries'),
					array('name' => 'Kuwait', 'value' => 'KW,countries'),
					array('name' => 'Kuwait - Provinces', 'value' => 'KW,provinces'),
					array('name' => 'Kyrgyzstan', 'value' => 'KG,countries'),
					array('name' => 'Kyrgyzstan - Provinces', 'value' => 'KG,provinces'),
					array('name' => 'Lao People\'s Democratic Republic', 'value' => 'LA,countries'),
					array('name' => 'Lao People\'s Democratic Republic - Provinces', 'value' => 'LA,provinces'),
					array('name' => 'Latvia', 'value' => 'LV,countries'),
					array('name' => 'Latvia - Provinces', 'value' => 'LV,provinces'),
					array('name' => 'Lebanon', 'value' => 'LB,countries'),
					array('name' => 'Lebanon - Provinces', 'value' => 'LB,provinces'),
					array('name' => 'Lesotho', 'value' => 'LS,countries'),
					array('name' => 'Lesotho - Provinces', 'value' => 'LS,provinces'),
					array('name' => 'Liberia', 'value' => 'LR,countries'),
					array('name' => 'Liberia - Provinces', 'value' => 'LR,provinces'),
					array('name' => 'Libya', 'value' => 'LY,countries'),
					array('name' => 'Libya - Provinces', 'value' => 'LY,provinces'),
					array('name' => 'Liechtenstein', 'value' => 'LI,countries'),
					array('name' => 'Liechtenstein - Provinces', 'value' => 'LI,provinces'),
					array('name' => 'Lithuania', 'value' => 'LT,countries'),
					array('name' => 'Lithuania - Provinces', 'value' => 'LT,provinces'),
					array('name' => 'Luxembourg', 'value' => 'LU,countries'),
					array('name' => 'Luxembourg - Provinces', 'value' => 'LU,provinces'),
					array('name' => 'Macao', 'value' => 'MO,countries'),
					array('name' => 'Macao - Provinces', 'value' => 'MO,provinces'),
					array('name' => 'Macedonia, the former Yugoslav Republic of', 'value' => 'MK,countries'),
					array('name' => 'Macedonia, the former Yugoslav Republic of - Provinces', 'value' => 'MK,provinces'),
					array('name' => 'Madagascar', 'value' => 'MG,countries'),
					array('name' => 'Madagascar - Provinces', 'value' => 'MG,provinces'),
					array('name' => 'Malawi', 'value' => 'MW,countries'),
					array('name' => 'Malawi - Provinces', 'value' => 'MW,provinces'),
					array('name' => 'Malaysia', 'value' => 'MY,countries'),
					array('name' => 'Malaysia - Provinces', 'value' => 'MY,provinces'),
					array('name' => 'Maldives', 'value' => 'MV,countries'),
					array('name' => 'Maldives - Provinces', 'value' => 'MV,provinces'),
					array('name' => 'Mali', 'value' => 'ML,countries'),
					array('name' => 'Mali - Provinces', 'value' => 'ML,provinces'),
					array('name' => 'Malta', 'value' => 'MT,countries'),
					array('name' => 'Malta - Provinces', 'value' => 'MT,provinces'),
					array('name' => 'Marshall Islands', 'value' => 'MH,countries'),
					array('name' => 'Marshall Islands - Provinces', 'value' => 'MH,provinces'),
					array('name' => 'Martinique', 'value' => 'MQ,countries'),
					array('name' => 'Martinique - Provinces', 'value' => 'MQ,provinces'),
					array('name' => 'Mauritania', 'value' => 'MR,countries'),
					array('name' => 'Mauritania - Provinces', 'value' => 'MR,provinces'),
					array('name' => 'Mauritius', 'value' => 'MU,countries'),
					array('name' => 'Mauritius - Provinces', 'value' => 'MU,provinces'),
					array('name' => 'Mayotte', 'value' => 'YT,countries'),
					array('name' => 'Mayotte - Provinces', 'value' => 'YT,provinces'),
					array('name' => 'Mexico', 'value' => 'MX,countries'),
					array('name' => 'Mexico - Provinces', 'value' => 'MX,provinces'),
					array('name' => 'Micronesia, Federated States of', 'value' => 'FM,countries'),
					array('name' => 'Micronesia, Federated States of - Provinces', 'value' => 'FM,provinces'),
					array('name' => 'Moldova, Republic of', 'value' => 'MD,countries'),
					array('name' => 'Moldova, Republic of - Provinces', 'value' => 'MD,provinces'),
					array('name' => 'Monaco', 'value' => 'MC,countries'),
					array('name' => 'Monaco - Provinces', 'value' => 'MC,provinces'),
					array('name' => 'Mongolia', 'value' => 'MN,countries'),
					array('name' => 'Mongolia - Provinces', 'value' => 'MN,provinces'),
					array('name' => 'Montenegro', 'value' => 'ME,countries'),
					array('name' => 'Montenegro - Provinces', 'value' => 'ME,provinces'),
					array('name' => 'Montserrat', 'value' => 'MS,countries'),
					array('name' => 'Montserrat - Provinces', 'value' => 'MS,provinces'),
					array('name' => 'Morocco', 'value' => 'MA,countries'),
					array('name' => 'Morocco - Provinces', 'value' => 'MA,provinces'),
					array('name' => 'Mozambique', 'value' => 'MZ,countries'),
					array('name' => 'Mozambique - Provinces', 'value' => 'MZ,provinces'),
					array('name' => 'Myanmar', 'value' => 'MM,countries'),
					array('name' => 'Myanmar - Provinces', 'value' => 'MM,provinces'),
					array('name' => 'Namibia', 'value' => 'NA,countries'),
					array('name' => 'Namibia - Provinces', 'value' => 'NA,provinces'),
					array('name' => 'Nauru', 'value' => 'NR,countries'),
					array('name' => 'Nauru - Provinces', 'value' => 'NR,provinces'),
					array('name' => 'Nepal', 'value' => 'NP,countries'),
					array('name' => 'Nepal - Provinces', 'value' => 'NP,provinces'),
					array('name' => 'Netherlands', 'value' => 'NL,countries'),
					array('name' => 'Netherlands - Provinces', 'value' => 'NL,provinces'),
					array('name' => 'New Caledonia', 'value' => 'NC,countries'),
					array('name' => 'New Caledonia - Provinces', 'value' => 'NC,provinces'),
					array('name' => 'New Zealand', 'value' => 'NZ,countries'),
					array('name' => 'New Zealand - Provinces', 'value' => 'NZ,provinces'),
					array('name' => 'Nicaragua', 'value' => 'NI,countries'),
					array('name' => 'Nicaragua - Provinces', 'value' => 'NI,provinces'),
					array('name' => 'Niger', 'value' => 'NE,countries'),
					array('name' => 'Niger - Provinces', 'value' => 'NE,provinces'),
					array('name' => 'Nigeria', 'value' => 'NG,countries'),
					array('name' => 'Nigeria - Provinces', 'value' => 'NG,provinces'),
					array('name' => 'Niue', 'value' => 'NU,countries'),
					array('name' => 'Niue - Provinces', 'value' => 'NU,provinces'),
					array('name' => 'Norfolk Island', 'value' => 'NF,countries'),
					array('name' => 'Norfolk Island - Provinces', 'value' => 'NF,provinces'),
					array('name' => 'Northern Mariana Islands', 'value' => 'MP,countries'),
					array('name' => 'Northern Mariana Islands - Provinces', 'value' => 'MP,provinces'),
					array('name' => 'Norway', 'value' => 'NO,countries'),
					array('name' => 'Norway - Provinces', 'value' => 'NO,provinces'),
					array('name' => 'Oman', 'value' => 'OM,countries'),
					array('name' => 'Oman - Provinces', 'value' => 'OM,provinces'),
					array('name' => 'Pakistan', 'value' => 'PK,countries'),
					array('name' => 'Pakistan - Provinces', 'value' => 'PK,provinces'),
					array('name' => 'Palau', 'value' => 'PW,countries'),
					array('name' => 'Palau - Provinces', 'value' => 'PW,provinces'),
					array('name' => 'Palestinian Territory, Occupied', 'value' => 'PS,countries'),
					array('name' => 'Palestinian Territory, Occupied - Provinces', 'value' => 'PS,provinces'),
					array('name' => 'Panama', 'value' => 'PA,countries'),
					array('name' => 'Panama - Provinces', 'value' => 'PA,provinces'),
					array('name' => 'Papua New Guinea', 'value' => 'PG,countries'),
					array('name' => 'Papua New Guinea - Provinces', 'value' => 'PG,provinces'),
					array('name' => 'Paraguay', 'value' => 'PY,countries'),
					array('name' => 'Paraguay - Provinces', 'value' => 'PY,provinces'),
					array('name' => 'Peru', 'value' => 'PE,countries'),
					array('name' => 'Peru - Provinces', 'value' => 'PE,provinces'),
					array('name' => 'Philippines', 'value' => 'PH,countries'),
					array('name' => 'Philippines - Provinces', 'value' => 'PH,provinces'),
					array('name' => 'Pitcairn', 'value' => 'PN,countries'),
					array('name' => 'Pitcairn - Provinces', 'value' => 'PN,provinces'),
					array('name' => 'Poland', 'value' => 'PL,countries'),
					array('name' => 'Poland - Provinces', 'value' => 'PL,provinces'),
					array('name' => 'Portugal', 'value' => 'PT,countries'),
					array('name' => 'Portugal - Provinces', 'value' => 'PT,provinces'),
					array('name' => 'Puerto Rico', 'value' => 'PR,countries'),
					array('name' => 'Puerto Rico - Provinces', 'value' => 'PR,provinces'),
					array('name' => 'Qatar', 'value' => 'QA,countries'),
					array('name' => 'Qatar - Provinces', 'value' => 'QA,provinces'),
					array('name' => 'Reunion !Réunion', 'value' => 'RE,countries'),
					array('name' => 'Reunion !Réunion - Provinces', 'value' => 'RE,provinces'),
					array('name' => 'Romania', 'value' => 'RO,countries'),
					array('name' => 'Romania - Provinces', 'value' => 'RO,provinces'),
					array('name' => 'Russian Federation', 'value' => 'RU,countries'),
					array('name' => 'Russian - Provinces', 'value' => 'RU,provinces'),
					array('name' => 'Rwanda', 'value' => 'RW,countries'),
					array('name' => 'Rwanda - Provinces', 'value' => 'RW,provinces'),
					array('name' => 'Saint Barthélemy', 'value' => 'BL,countries'),
					array('name' => 'Saint Barthélemy - Provinces', 'value' => 'BL,provinces'),
					array('name' => 'Saint Helena, Ascension and Tristan da Cunha', 'value' => 'SH,countries'),
					array('name' => 'Saint Helena, Ascension and Tristan da Cunha - Provinces', 'value' => 'SH,provinces'),
					array('name' => 'Saint Kitts and Nevis', 'value' => 'KN,countries'),
					array('name' => 'Saint Kitts and Nevis - Provinces', 'value' => 'KN,provinces'),
					array('name' => 'Saint Lucia', 'value' => 'LC,countries'),
					array('name' => 'Saint Lucia - Provinces', 'value' => 'LC,provinces'),
					array('name' => 'Saint Martin (French part)', 'value' => 'MF,countries'),
					array('name' => 'Saint Martin (French part) - Provinces', 'value' => 'MF,provinces'),
					array('name' => 'Saint Pierre and Miquelon', 'value' => 'PM,countries'),
					array('name' => 'Saint Pierre and Miquelon - Provinces', 'value' => 'PM,provinces'),
					array('name' => 'Saint Vincent and the Grenadines', 'value' => 'VC,countries'),
					array('name' => 'Saint Vincent and the Grenadines - Provinces', 'value' => 'VC,provinces'),
					array('name' => 'Samoa', 'value' => 'WS,countries'),
					array('name' => 'Samoa - Provinces', 'value' => 'WS,provinces'),
					array('name' => 'San Marino', 'value' => 'SM,countries'),
					array('name' => 'San Marino - Provinces', 'value' => 'SM,provinces'),
					array('name' => 'Sao Tome and Principe', 'value' => 'ST,countries'),
					array('name' => 'Sao Tome and Principe - Provinces', 'value' => 'ST,provinces'),
					array('name' => 'Saudi Arabia', 'value' => 'SA,countries'),
					array('name' => 'Saudi Arabia - Provinces', 'value' => 'SA,provinces'),
					array('name' => 'Senegal', 'value' => 'SN,countries'),
					array('name' => 'Senegal - Provinces', 'value' => 'SN,provinces'),
					array('name' => 'Serbia', 'value' => 'RS,countries'),
					array('name' => 'Serbia - Provinces', 'value' => 'RS,provinces'),
					array('name' => 'Seychelles', 'value' => 'SC,countries'),
					array('name' => 'Seychelles - Provinces', 'value' => 'SC,provinces'),
					array('name' => 'Sierra Leone', 'value' => 'SL,countries'),
					array('name' => 'Sierra Leone - Provinces', 'value' => 'SL,provinces'),
					array('name' => 'Singapore', 'value' => 'SG,countries'),
					array('name' => 'Sint Maarten (Dutch part)', 'value' => 'SX,countries'),
					array('name' => 'Sint Maarten (Dutch part) - Provinces', 'value' => 'SX,provinces'),
					array('name' => 'Slovakia', 'value' => 'SK,countries'),
					array('name' => 'Slovakia - Provinces', 'value' => 'SK,provinces'),
					array('name' => 'Slovenia', 'value' => 'SI,countries'),
					array('name' => 'Slovenia - Provinces', 'value' => 'SI,provinces'),
					array('name' => 'Solomon Islands', 'value' => 'SB,countries'),
					array('name' => 'Solomon Islands - Provinces', 'value' => 'SB,provinces'),
					array('name' => 'Somalia', 'value' => 'SO,countries'),
					array('name' => 'Somalia - Provinces', 'value' => 'SO,provinces'),
					array('name' => 'South Africa', 'value' => 'ZA,countries'),
					array('name' => 'South Africa - Provinces', 'value' => 'ZA,provinces'),
					array('name' => 'South Georgia and the South Sandwich Islands', 'value' => 'GS,countries'),
					array('name' => 'South Georgia and the South Sandwich Islands - Provinces', 'value' => 'GS,provinces'),
					array('name' => 'South Sudan', 'value' => 'SS,countries'),
					array('name' => 'South Sudan - Provinces', 'value' => 'SS,provinces'),
					array('name' => 'Spain', 'value' => 'ES,countries'),
					array('name' => 'Spain - Provinces', 'value' => 'ES,provinces'),
					array('name' => 'Sri Lanka', 'value' => 'LK,countries'),
					array('name' => 'Sri Lanka - Provinces', 'value' => 'LK,provinces'),
					array('name' => 'Sudan', 'value' => 'SD,countries'),
					array('name' => 'Sudan - Provinces', 'value' => 'SD,provinces'),
					array('name' => 'Suriname', 'value' => 'SR,countries'),
					array('name' => 'Suriname - Provinces', 'value' => 'SR,provinces'),
					array('name' => 'Svalbard and Jan Mayen', 'value' => 'SJ,countries'),
					array('name' => 'Svalbard and Jan Mayen - Provinces', 'value' => 'SJ,provinces'),
					array('name' => 'Swaziland', 'value' => 'SZ,countries'),
					array('name' => 'Swaziland - Provinces', 'value' => 'SZ,provinces'),
					array('name' => 'Sweden', 'value' => 'SE,countries'),
					array('name' => 'Sweden - Provinces', 'value' => 'SE,provinces'),
					array('name' => 'Switzerland', 'value' => 'CH,countries'),
					array('name' => 'Switzerland - Provinces', 'value' => 'CH,provinces'),
					array('name' => 'Syrian Arab Republic', 'value' => 'SY,countries'),
					array('name' => 'Syrian Arab Republic - Provinces', 'value' => 'SY,provinces'),
					array('name' => 'Taiwan, Province of China', 'value' => 'TW,countries'),
					array('name' => 'Taiwan, Province of China - Provinces', 'value' => 'TW,provinces'),
					array('name' => 'Tajikistan', 'value' => 'TJ,countries'),
					array('name' => 'Tajikistan - Provinces', 'value' => 'TJ,provinces'),
					array('name' => 'Tanzania, United Republic of', 'value' => 'TZ,countries'),
					array('name' => 'Tanzania, United Republic of - Provinces', 'value' => 'TZ,provinces'),
					array('name' => 'Thailand', 'value' => 'TH,countries'),
					array('name' => 'Thailand - Provinces', 'value' => 'TH,provinces'),
					array('name' => 'Timor-Leste', 'value' => 'TL,countries'),
					array('name' => 'Timor-Leste - Provinces', 'value' => 'TL,provinces'),
					array('name' => 'Togo', 'value' => 'TG,countries'),
					array('name' => 'Togo - Provinces', 'value' => 'TG,provinces'),
					array('name' => 'Tokelau', 'value' => 'TK,countries'),
					array('name' => 'Tokelau - Provinces', 'value' => 'TK,provinces'),
					array('name' => 'Tonga', 'value' => 'TO,countries'),
					array('name' => 'Tonga - Provinces', 'value' => 'TO,provinces'),
					array('name' => 'Trinidad and Tobago', 'value' => 'TT,countries'),
					array('name' => 'Trinidad and Tobago - Provinces', 'value' => 'TT,provinces'),
					array('name' => 'Tunisia', 'value' => 'TN,countries'),
					array('name' => 'Tunisia - Provinces', 'value' => 'TN,provinces'),
					array('name' => 'Turkey', 'value' => 'TR,countries'),
					array('name' => 'Turkey - Provinces', 'value' => 'TR,provinces'),
					array('name' => 'Turkmenistan', 'value' => 'TM,countries'),
					array('name' => 'Turkmenistan - Provinces', 'value' => 'TM,provinces'),
					array('name' => 'Turks and Caicos Islands', 'value' => 'TC,countries'),
					array('name' => 'Turks and Caicos Islands - Provinces', 'value' => 'TC,provinces'),
					array('name' => 'Tuvalu', 'value' => 'TV,countries'),
					array('name' => 'Tuvalu - Provinces', 'value' => 'TV,provinces'),
					array('name' => 'Uganda', 'value' => 'UG,countries'),
					array('name' => 'Uganda - Provinces', 'value' => 'UG,provinces'),
					array('name' => 'Ukraine', 'value' => 'UA,countries'),
					array('name' => 'Ukraine - Provinces', 'value' => 'UA,provinces'),
					array('name' => 'United Arab Emirates', 'value' => 'AE,countries'),
					array('name' => 'United Arab Emirates - Provinces', 'value' => 'AE,provinces'),
					array('name' => 'United Kingdom', 'value' => 'GB,countries'),
					array('name' => 'United Kingdom - Provinces', 'value' => 'GB,provinces'),
					array('name' => 'United States', 'value' => 'US,countries'),
					array('name' => 'United States - Provinces', 'value' => 'US,provinces'),
					array('name' => 'United States Minor Outlying Islands', 'value' => 'UM,countries'),
					array('name' => 'United States Minor Outlying Islands - Provinces', 'value' => 'UM,provinces'),
					array('name' => 'Uruguay', 'value' => 'UY,countries'),
					array('name' => 'Uruguay - Provinces', 'value' => 'UY,provinces'),
					array('name' => 'Uzbekistan', 'value' => 'UZ,countries'),
					array('name' => 'Uzbekistan - Provinces', 'value' => 'UZ,provinces'),
					array('name' => 'Vanuatu', 'value' => 'VU,countries'),
					array('name' => 'Vanuatu - Provinces', 'value' => 'VU,provinces'),
					array('name' => 'Venezuela, Bolivarian Republic of', 'value' => 'VE,countries'),
					array('name' => 'Venezuela, Bolivarian Republic of - Provinces', 'value' => 'VE,provinces'),
					array('name' => 'Viet Nam', 'value' => 'VN,countries'),
					array('name' => 'Viet Nam - Provinces', 'value' => 'VN,provinces'),
					array('name' => 'Virgin Islands, British', 'value' => 'VG,countries'),
					array('name' => 'Virgin Islands, British - Provinces', 'value' => 'VG,provinces'),
					array('name' => 'Virgin Islands, U.S.', 'value' => 'VI,countries'),
					array('name' => 'Virgin Islands, U.S. - Provinces', 'value' => 'VI,provinces'),
					array('name' => 'Vietnam', 'value' => 'Vietnam,countries'),
					array('name' => 'Wallis and Futuna', 'value' => 'WF,countries'),
					array('name' => 'Wallis and Futuna - Provinces', 'value' => 'WF,provinces'),
					array('name' => 'Western Sahara', 'value' => 'EH,countries'),
					array('name' => 'Western Sahara - Provinces', 'value' => 'EH,provinces'),
					array('name' => 'Yemen', 'value' => 'YE,countries'),
					array('name' => 'Yemen - Provinces', 'value' => 'YE,provinces'),
					array('name' => 'Zambia', 'value' => 'ZM,countries'),
					array('name' => 'Zambia - Provinces', 'value' => 'ZM,provinces'),
					array('name' => 'Zimbabwe', 'value' => 'ZW,countries'),
					array('name' => 'Zimbabwe - Provinces', 'value' => 'ZW,provinces'),
					array('name' => 'India', 'value' => 'IN,india'),
					array('name' => 'Russian ', 'value' => 'RU,Russian '),
					array('name' => 'Ireland ', 'value' => 'Ireland, '),
					
				);
				return $regions;
				}
				
//
function sim_map_build_location_select_options() {

	$location = array (
			array('name' => 'Afghanistan' , 'value'=> 'Afghanistan'),
			array('name' => 'Albania' , 'value'=> 'Albania'),
			array('name' => 'Algeria' , 'value'=> 'Algeria'),
			array('name' => 'American Samoa' , 'value'=> 'American Samoa'),
			array('name' => 'Andorra' , 'value'=> 'Andorra'),
			array('name' => 'Angola' , 'value'=> 'Angola'),
			array('name' => 'Anguilla' , 'value'=> 'Anguilla'),
			array('name' => 'Antarctica' , 'value'=> 'Antarctica'),
			array('name' => 'Antigua and Barbuda' , 'value'=> 'Antigua and Barbuda'),
			array('name' => 'Argentina' , 'value'=> 'Argentina'),
			array('name' => 'Armenia' , 'value'=> 'Armenia'),
			array('name' => 'Aruba' , 'value'=> 'Aruba'),
			array('name' => 'Australia' , 'value'=> 'Australia'),
			array('name' => 'Austria' , 'value'=> 'Austria'),
			array('name' => 'Azerbaijan' , 'value'=> 'Azerbaijan'),
			array('name' => 'Bahamas' , 'value'=> 'Bahamas'),
			array('name' => 'Bahrain' , 'value'=> 'Bahrain'),
			array('name' => 'Bangladesh' , 'value'=> 'Bangladesh'),
			array('name' => 'Barbados' , 'value'=> 'Barbados'),
			array('name' => 'Belarus' , 'value'=> 'Belarus'),
			array('name' => 'Belgium' , 'value'=> 'Belgium'),
			array('name' => 'Belize' , 'value'=> 'Belize'),		
			array('name' => 'Benin' , 'value'=> 'Benin'),
			array('name' => 'Bermuda' , 'value'=> 'Bermuda'),
			array('name' => 'Bhutan' , 'value'=> 'Bhutan'),
			array('name' => 'Brazil' , 'value'=> 'Brazil'),
			array('name' => 'Bulgaria' , 'value'=> 'Bulgaria'),
			array('name' => 'Burkina Faso' , 'value'=> 'Burkina Faso'),
			array('name' => 'Burundi' , 'value'=> 'Burundi'),
			array('name' => 'Cabo Verde' , 'value'=> 'Cabo Verde'),
			array('name' => 'Cambodia' , 'value'=> 'Cambodia'),
			array('name' => 'Cameroon' , 'value'=> 'Cameroon'),
			array('name' => 'Canada' , 'value'=> 'Canada'),
			array('name' => 'Cayman Islands' , 'value'=> 'Cayman Islands'),
			array('name' => 'Central African Republic' , 'value'=> 'Central African Republic'),
			array('name' => 'Chad' , 'value'=> 'Chad'),
			array('name' => 'Chile' , 'value'=> 'Chile'),
			array('name' => 'China' , 'value'=> 'China'),
			array('name' => 'Christmas Island' , 'value'=> 'Christmas Island'),
			array('name' => 'Colombia' , 'value'=> 'Colombia'),
			array('name' => 'Comoros' , 'value'=> 'Comoros'),
			array('name' => 'Congo' , 'value'=> 'Congo'),
			array('name' => 'Cook Islands' , 'value'=> 'Cook Islands'),
			array('name' => 'Costa Rica' , 'value'=> 'Costa Rica'),
			array('name' => 'Croatia' , 'value'=> 'Croatia'),
			array('name' => 'Cuba' , 'value'=> 'Cuba'),
			array('name' => 'Curaçao' , 'value'=> 'Curaçao'),
			array('name' => 'Cyprus' , 'value'=> 'Cyprus'),
			array('name' => 'Denmark' , 'value'=> 'Denmark'),
			array('name' => 'Djibouti' , 'value'=> 'Djibouti'),
			array('name' => 'Dominica' , 'value'=> 'Dominica'),
			array('name' => 'Ecuador' , 'value'=> 'Ecuador'),
			array('name' => 'Egypt' , 'value'=> 'Egypt'),
			array('name' => 'El Salvador' , 'value'=> 'El Salvador'),
			array('name' => 'Equatorial Guinea' , 'value'=> 'Equatorial Guinea'),
			array('name' => 'Eritrea' , 'value'=> 'Eritrea'),
			array('name' => 'Estonia' , 'value'=> 'Estonia'),
			array('name' => 'Ethiopia' , 'value'=> 'Ethiopia'),
			array('name' => 'Faroe Islands' , 'value'=> 'Faroe Islands'),
			array('name' => 'Fiji' , 'value'=> 'Fiji'),
			array('name' => 'Finland' , 'value'=> 'Finland'),
			array('name' => 'France' , 'value'=> 'France'),			
			array('name' => 'French Polynesia' , 'value'=> 'French Polynesia'),
			array('name' => 'Gabon' , 'value'=> 'Gabon'),
			array('name' => 'Gambia' , 'value'=> 'Gambia'),
			array('name' => 'Georgia' , 'value'=> 'Georgia'),
			array('name' => 'Germany' , 'value'=> 'Germany'),
			array('name' => 'Ghana' , 'value'=> 'Ghana'),
			array('name' => 'Gibraltar' , 'value'=> 'Gibraltar'),
			array('name' => 'Greece' , 'value'=> 'Greece'),
			array('name' => 'Greenland' , 'value'=> 'Greenland'),
			array('name' => 'Grenada' , 'value'=> 'Grenada'),
			array('name' => 'Guadeloupe' , 'value'=> 'Guadeloupe'),
			array('name' => 'Guam' , 'value'=> 'Guam'),
			array('name' => 'Guatemala' , 'value'=> 'Guatemala'),
			array('name' => 'Guernsey' , 'value'=> 'Guernsey'),
			array('name' => 'Guinea' , 'value'=> 'Guinea'),
			array('name' => 'Guinea-Bissau' , 'value'=> 'Guinea-Bissau'),
			array('name' => 'Guyana' , 'value'=> 'Guyana'),
			array('name' => 'Haiti' , 'value'=> 'Haiti'),
			array('name' => 'Heard Island and McDonald Islands' , 'value'=> 'Heard Island and McDonald Islands'),
			array('name' => 'Holy See' , 'value'=> 'Holy See'),			
			array('name' => 'Honduras' , 'value'=> 'Honduras'),
			array('name' => 'Hong Kong' , 'value'=> 'Hong Kong'),
			array('name' => 'Hungary' , 'value'=> 'Hungary'),
			array('name' => 'Iceland' , 'value'=> 'Iceland'),
			array('name' => 'Indonesia' , 'value'=> 'Indonesia'),
			array('name' => 'Iraq' , 'value'=> 'Iraq'),
			array('name' => 'Ireland' , 'value'=> 'Ireland'),
			array('name' => 'Isle of Man' , 'value'=> 'Isle of Man'),
			array('name' => 'Israel' , 'value'=> 'Israel'),
			array('name' => 'Italy' , 'value'=> 'Italy'),
			array('name' => 'Jamaica' , 'value'=> 'Jamaica'),
			array('name' => 'Japan' , 'value'=> 'Japan'),
			array('name' => 'Jersey' , 'value'=> 'Jersey'),
			array('name' => 'Jordan' , 'value'=> 'Jordan'),
			array('name' => 'Kazakhstan' , 'value'=> 'Kazakhstan'),
			array('name' => 'Kenya' , 'value'=> 'Kenya'),			
			array('name' => 'Kiribati' , 'value'=> 'Kiribati'),
			array('name' => 'Kuwait' , 'value'=> 'Kuwait'),
			array('name' => 'Kyrgyzstan' , 'value'=> 'Kyrgyzstan'),
			array('name' => 'Latvia' , 'value'=> 'Latvia'),
			array('name' => 'Lebanon' , 'value'=> 'Lebanon'),
			array('name' => 'Lesotho' , 'value'=> 'Lesotho'),
			array('name' => 'Liberia' , 'value'=> 'Liberia'),
			array('name' => 'Libya' , 'value'=> 'Libya'),
			array('name' => 'Liechtenstein' , 'value'=> 'Liechtenstein'),
			array('name' => 'Lithuania' , 'value'=> 'Lithuania'),
			array('name' => 'Luxembourg' , 'value'=> 'Luxembourg'),
			array('name' => 'Macao' , 'value'=> 'Macao'),
			array('name' => 'Madagascar' , 'value'=> 'Madagascar'),
			array('name' => 'Malawi' , 'value'=> 'Malawi'),
			array('name' => 'Malaysia' , 'value'=> 'Malaysia'),			
			array('name' => 'Maldives' , 'value'=> 'Maldives'),
			array('name' => 'Mali' , 'value'=> 'Mali'),
			array('name' => 'Malta' , 'value'=> 'Malta'),
			array('name' => 'Marshall Islands' , 'value'=> 'Marshall Islands'),
			array('name' => 'Martinique' , 'value'=> 'Martinique'),
			array('name' => 'Mauritania' , 'value'=> 'Mauritania'),
			array('name' => 'Mauritius' , 'value'=> 'Mauritius'),
			array('name' => 'Mayotte' , 'value'=> 'Mayotte'),
			array('name' => 'Mexico' , 'value'=> 'Mexico'),
			array('name' => 'Monaco' , 'value'=> 'Monaco'),
			array('name' => 'Mongolia' , 'value'=> 'Mongolia'),
			array('name' => 'Montenegro' , 'value'=> 'Montenegro'),
			array('name' => 'Montserrat' , 'value'=> 'Montserrat'),
			array('name' => 'Morocco' , 'value'=> 'Morocco'),
			array('name' => 'Mozambique' , 'value'=> 'Mozambique'),
			array('name' => 'Myanmar' , 'value'=> 'Myanmar'),			
			array('name' => 'Namibia' , 'value'=> 'Namibia'),
			array('name' => 'Nauru' , 'value'=> 'Nauru'),
			array('name' => 'Nepal' , 'value'=> 'Nepal'),
			array('name' => 'Netherlands' , 'value'=> 'Netherlands'),
			array('name' => 'New Caledonia' , 'value'=> 'New Caledonia'),
			array('name' => 'New Zealand' , 'value'=> 'New Zealand'),
			array('name' => 'Nicaragua' , 'value'=> 'Nicaragua'),
			array('name' => 'Niger' , 'value'=> 'Niger'),
			array('name' => 'Nigeria' , 'value'=> 'Nigeria'),
			array('name' => 'Niue' , 'value'=> 'Niue'),
			array('name' => 'Norfolk Island' , 'value'=> 'Norfolk Island'),
			array('name' => 'Northern Mariana Islands' , 'value'=> 'Northern Mariana Islands'),
			array('name' => 'Norway' , 'value'=> 'Norway'),
			array('name' => 'Oman' , 'value'=> 'Oman'),
			array('name' => 'Pakistan' , 'value'=> 'Pakistan'),
			array('name' => 'Palau' , 'value'=> 'Palau'),
			array('name' => 'Palestine, State of' , 'value'=> 'Palestine, State of'),
			array('name' => 'Panama' , 'value'=> 'Panama'),
			array('name' => 'Papua New Guinea' , 'value'=> 'Papua New Guinea'),
			array('name' => 'Paraguay' , 'value'=> 'Paraguay'),
			array('name' => 'Peru' , 'value'=> 'Peru'),
			array('name' => 'Philippines' , 'value'=> 'Philippines'),
			array('name' => 'Pitcairn' , 'value'=> 'Pitcairn'),
			array('name' => 'Poland' , 'value'=> 'Poland'),			
			array('name' => 'Portugal' , 'value'=> 'Portugal'),
			array('name' => 'Puerto Rico' , 'value'=> 'Puerto Rico'),
			array('name' => 'Qatar' , 'value'=> 'Qatar'),
			array('name' => 'Réunion' , 'value'=> 'Réunion'),
			array('name' => 'Romania' , 'value'=> 'Romania'),
			array('name' => 'Russian Federation' , 'value'=> 'Russian Federation'),
			array('name' => 'Russian Republic' , 'value'=> 'Russian Embassy Republic of Singapore'),
			array('name' => 'Rwanda' , 'value'=> 'Rwanda'),
			array('name' => 'Saint Lucia' , 'value'=> 'Saint Lucia'),
			array('name' => 'Samoa' , 'value'=> 'Samoa'),
			array('name' => 'San Marino' , 'value'=> 'San Marino'),
			array('name' => 'Sao Tome and Principe' , 'value'=> 'Sao Tome and Principe'),
			array('name' => 'Saudi Arabia' , 'value'=> 'Saudi Arabia'),			
			array('name' => 'Senegal' , 'value'=> 'Senegal'),
			array('name' => 'Serbia' , 'value'=> 'Serbia'),
			array('name' => 'Seychelles' , 'value'=> 'Seychelles'),
			array('name' => 'Sierra Leone' , 'value'=> 'Sierra Leone'),
			array('name' => 'Singapore' , 'value'=> 'Singapore'),		
			array('name' => 'Slovakia' , 'value'=> 'Slovakia'),
			array('name' => 'Slovenia' , 'value'=> 'Slovenia'),
			array('name' => 'Somalia' , 'value'=> 'Somalia'),
			array('name' => 'South Africa' , 'value'=> 'South Africa'),
			array('name' => 'South Sudan' , 'value'=> 'South Sudan'),			
			array('name' => 'Spain' , 'value'=> 'Spain'),
			array('name' => 'Sri Lanka' , 'value'=> 'Senegal'),
			array('name' => 'Senegal' , 'value'=> 'Sri Lanka'),
			array('name' => 'Sudan' , 'value'=> 'Sudan'),
			array('name' => 'Suriname' , 'value'=> 'Suriname'),
			array('name' => 'Swaziland' , 'value'=> 'Swaziland'),
			array('name' => 'Sweden' , 'value'=> 'Sweden'),
			array('name' => 'Switzerland' , 'value'=> 'Switzerland'),
			array('name' => 'Tajikistan' , 'value'=> 'Tajikistan'),
			array('name' => 'Thailand' , 'value'=> 'Thailand'),
			array('name' => 'Timor-Leste' , 'value'=> 'Timor-Leste'),
			array('name' => 'Togo' , 'value'=> 'Togo'),
			array('name' => 'Tokelau' , 'value'=> 'Tokelau'),
			array('name' => 'Tonga' , 'value'=> 'Tonga'),
			array('name' => 'Trinidad and Tobago' , 'value'=> 'Trinidad and Tobago'),
			array('name' => 'Tunisia' , 'value'=> 'Tunisia'),
			array('name' => 'Turkey' , 'value'=> 'Turkey'),
			array('name' => 'Turkmenistan' , 'value'=> 'Turkmenistan'),
			array('name' => 'Tuvalu' , 'value'=> 'Tuvalu'),
			array('name' => 'Uganda' , 'value'=> 'Uganda'),
			array('name' => 'Ukraine' , 'value'=> 'Ukraine'),
			array('name' => 'United Arab Emirates' , 'value'=> 'United Arab Emirates'),
			array('name' => 'United States of America' , 'value'=> 'United States of America'),
			array('name' => 'Uruguay' , 'value'=> 'Uruguay'),
			array('name' => 'Uzbekistan' , 'value'=> 'Uzbekistan'),
			array('name' => 'Vanuatu' , 'value'=> 'Vanuatu'),
			array('name' => 'Viet Nam' , 'value'=> 'Viet Nam'),
			array('name' => 'Virgin Islands British' , 'value'=> 'Virgin Islands (British)'),
			array('name' => 'Virgin Islands US' , 'value'=> 'Virgin Islands (U.S.)'),
		    array('name' => 'Vietnam' , 'value'=> 'Vietnam'),
			array('name' => 'Wallis and Futuna' , 'value'=> 'Wallis and Futuna'),
			array('name' => 'Western Sahara' , 'value'=> 'Western Sahara'),
			array('name' => 'Yemen' , 'value'=> 'Yemen'),
			array('name' => 'Zambia' , 'value'=> 'Zambia'),
			array('name' => 'Zimbabwe' , 'value'=> 'Zimbabwe'),		
			array('name' => 'India' , 'value'=> 'India'),
			array('name' => 'US-AL' , 'value'=> 'US-AL'),
			array('name' => 'US-AK' , 'value'=> 'US-AK'),
			array('name' => 'US-AZ' , 'value'=> 'US-AZ'),
			array('name' => 'US-CO' , 'value'=> 'US-CO'),
			array('name' => 'US-CT' , 'value'=> 'US-CT'),
			array('name' => 'US-CA' , 'value'=> 'US-CA'),
			array('name' => 'US-ID' , 'value'=> 'US-ID'),
			array('name' => 'US-HI' , 'value'=> 'US-HI'),
			array('name' => 'US-ME' , 'value'=> 'US-ME'),
			array('name' => 'US-MI' , 'value'=> 'US-MI'),
			array('name' => 'US-MO' , 'value'=> 'US-MO'),
			array('name' => 'US-IA' , 'value'=> 'US-IA'),
			array('name' => 'US-NE' , 'value'=> 'US-NE'),
			array('name' => 'US-TN' , 'value'=> 'US-TN'),
			array('name' => 'US-AR' , 'value'=> 'US-AR'),
			array('name' => 'US-WV' , 'value'=> 'US-WV'),
			array('name' => 'US-KY' , 'value'=> 'US-KY'),
			array('name' => 'US-MA' , 'value'=> 'US-MA'),
			array('name' => 'US-MD' , 'value'=> 'US-MD'),
			array('name' => 'US-DE' , 'value'=> 'US-DE'),
			array('name' => 'US-DC' , 'value'=> 'US-DC'),
			array('name' => 'US-KS' , 'value'=> 'US-KS'),
			array('name' => 'US-LA' , 'value'=> 'US-LA'),
			array('name' => 'US-IL' , 'value'=> 'US-IL'),
			array('name' => 'US-NH' , 'value'=> 'US-NH'),
			array('name' => 'US-SC' , 'value'=> 'US-SC'),
			array('name' => 'US-ND' , 'value'=> 'US-ND'),
			array('name' => 'US-MS' , 'value'=> 'US-MS'),
			array('name' => 'US-PA' , 'value'=> 'US-PA'),
			array('name' => 'US-VA' , 'value'=> 'US-VA'),
			array('name' => 'US-NY' , 'value'=> 'US-NY'),
			array('name' => 'US-WI' , 'value'=> 'US-WI'),
			array('name' => 'US-GA' , 'value'=> 'US-GA'),
			array('name' => 'US-SD' , 'value'=> 'US-SD'),
			array('name' => 'US-NJ' , 'value'=> 'US-SD'),
			array('name' => 'US-FL' , 'value'=> 'US-FL'),
			array('name' => 'US-VT' , 'value'=> 'US-VT'),
			array('name' => 'US-IN' , 'value'=> 'US-IN'),
			array('name' => 'US-MN' , 'value'=> 'US-MN'),
			array('name' => 'US-NC' , 'value'=> 'US-NC'),
			array('name' => 'US-OH' , 'value'=> 'US-OH'),
			array('name' => 'US-MT' , 'value'=> 'US-MT'),
			array('name' => 'US-NV' , 'value'=> 'US-NV'),
			array('name' => 'US-NM' , 'value'=> 'US-NM'),
			array('name' => 'US-OK' , 'value'=> 'US-OK'),
			array('name' => 'US-OR' , 'value'=> 'US-OR'),
			array('name' => 'US-RI' , 'value'=> 'US-RI'),
			array('name' => 'US-TX' , 'value'=> 'US-TX'),
			array('name' => 'US-UT' , 'value'=> 'US-UT'),
			array('name' => 'US-WA' , 'value'=> 'US-WA'),
			array('name' => 'US-WY' , 'value'=> 'US-WY'),
			array('value' => 'DZ' , 'name'=> 'Northern Africa ,DZ'),
			array('value' => 'EG' , 'name'=> 'Northern Africa ,EG'),
			array('value' => 'EH' , 'name'=> 'Northern Africa ,EH'),
			array('value' => 'LY' , 'name'=> 'Northern Africa ,LY'),
			array('value' => 'MA' , 'name'=> 'Northern Africa ,MA'),
			array('value' => 'SD' , 'name'=> 'Northern Africa ,SD'),
			array('value' => 'TN' , 'name'=> 'Northern Africa ,TN'),
			//Western Africa
			array('value' => 'BF' , 'name'=> 'Western Africa ,BF'),
			array('value' => 'BJ' , 'name'=> 'Western Africa ,BJ'),
			array('value' => 'CI' , 'name'=> 'Western Africa ,CI'),
			array('value' => 'CV' , 'name'=> 'Western Africa ,CV'),
			array('value' => 'GH' , 'name'=> 'Western Africa ,GH'),
			array('value' => 'GN' , 'name'=> 'Western Africa ,GN'),
			array('value' => 'GW' , 'name'=> 'Western Africa ,GW'),
			array('value' => 'LR' , 'name'=> 'Western Africa ,LR'),
			array('value' => 'ML' , 'name'=> 'Western Africa ,ML'),
			array('value' => 'MR' , 'name'=> 'Western Africa ,MR'),
			array('value' => 'NE' , 'name'=> 'Western Africa ,NE'),
			array('value' => 'NG' , 'name'=> 'Western Africa ,NG'),
			array('value' => 'SH' , 'name'=> 'Western Africa ,SH'),
			array('value' => 'SL' , 'name'=> 'Western Africa ,SL'),
			array('value' => 'SN' , 'name'=> 'Western Africa ,SN'),
			array('value' => 'TG' , 'name'=> 'Western Africa ,TG'),
			//Middle Africa 
			array('value' => 'AO' , 'name'=> 'Middle Africa ,AO'),
			array('value' => 'CD' , 'name'=> 'Middle Africa ,CD'),
			array('value' => 'ZR' , 'name'=> 'Middle Africa ,ZR'),
			array('value' => 'CF' , 'name'=> 'Middle Africa ,CF'),
			array('value' => 'CG' , 'name'=> 'Middle Africa ,CG'),
			array('value' => 'CM' , 'name'=> 'Middle Africa ,CM'),
			array('value' => 'GA' , 'name'=> 'Middle Africa ,GA'),
			array('value' => 'GQ' , 'name'=> 'Middle Africa ,GQ'),
			array('value' => 'ST' , 'name'=> 'Middle Africa ,ST'),
			array('value' => 'TD' , 'name'=> 'Middle Africa ,TD'),
			//Eastern Africa
			array('value' => 'BI' , 'name'=> 'Eastern Africa ,BI'),
			array('value' => 'DJ' , 'name'=> 'Eastern Africa ,DJ'),
			array('value' => 'ER' , 'name'=> 'Eastern Africa ,ER'),
			array('value' => 'ET' , 'name'=> 'Eastern Africa ,ET'),
			array('value' => 'KE' , 'name'=> 'Eastern Africa ,KE'),
			array('value' => 'KM' , 'name'=> 'Eastern Africa ,KM'),
			array('value' => 'MG' , 'name'=> 'Eastern Africa ,MG'),
			array('value' => 'MU' , 'name'=> 'Eastern Africa ,MU'),
			array('value' => 'MW' , 'name'=> 'Eastern Africa ,MW'),
			array('value' => 'MZ' , 'name'=> 'Eastern Africa ,MZ'),
			array('value' => 'RE' , 'name'=> 'Eastern Africa ,RE'),
			array('value' => 'RW' , 'name'=> 'Eastern Africa ,RW'),
			array('value' => 'SC' , 'name'=> 'Eastern Africa ,SO'),
			array('value' => 'TZ' , 'name'=> 'Eastern Africa ,TZ'),
			array('value' => 'UG' , 'name'=> 'Eastern Africa ,UG'),
			array('value' => 'YT' , 'name'=> 'Eastern Africa ,YT'),
			array('value' => 'ZM' , 'name'=> 'Eastern Africa ,ZM'),
			array('value' => 'ZW' , 'name'=> 'Eastern Africa ,ZW'),
			//Southern Africa
			array('value' => 'BW' , 'name'=> 'Southern Africa ,BW'),
			array('value' => 'LS' , 'name'=> 'Southern Africa ,LS'),
			array('value' => 'NA' , 'name'=> 'Southern Africa ,NA'),
			array('value' => 'SZ' , 'name'=> 'Southern Africa ,SZ'),
			array('value' => 'ZA' , 'name'=> 'Southern Africa ,ZA'),
			//Northern Europe
			array('value' => 'GG' , 'name'=> 'Northern Europe ,GG'),
			array('value' => 'JE' , 'name'=> 'Northern Europe ,JE'),
			array('value' => 'AX' , 'name'=> 'Northern Europe ,AX'),
			array('value' => 'DK' , 'name'=> 'Northern Europe ,DK'),
			array('value' => 'EE' , 'name'=> 'Northern Europe ,EE'),
			array('value' => 'FI' , 'name'=> 'Northern Europe ,FI'),
			array('value' => 'FO' , 'name'=> 'Northern Europe ,FO'),
			array('value' => 'GB' , 'name'=> 'Northern Europe ,GB'),
			array('value' => 'IE' , 'name'=> 'Northern Europe ,IE'),
			array('value' => 'IM' , 'name'=> 'Northern Europe ,IM'),
			array('value' => 'IS' , 'name'=> 'Northern Europe ,IS'),
			array('value' => 'LT' , 'name'=> 'Northern Europe ,LT'),
			array('value' => 'LV' , 'name'=> 'Northern Europe ,LV'),
			array('value' => 'NO' , 'name'=> 'Northern Europe ,NO'),
			array('value' => 'SE' , 'name'=> 'Northern Europe ,SE'),
			array('value' => 'SJ' , 'name'=> 'Northern Europe ,SJ'),
			//Western Europe
			array('value' => 'AT' , 'name'=> 'Western Europe ,AT'),
			array('value' => 'BE' , 'name'=> 'Western Europe ,BE'),
			array('value' => 'CH' , 'name'=> 'Western Europe ,CH'),
			array('value' => 'DE' , 'name'=> 'Western Europe ,DE'),
			array('value' => 'BD' , 'name'=> 'Western Europe ,BD'),
			array('value' => 'FR' , 'name'=> 'Western Europe ,FR'),
			array('value' => 'FX' , 'name'=> 'Western Europe ,FX'),
			array('value' => 'LI' , 'name'=> 'Western Europe ,LI'),
			array('value' => 'LU' , 'name'=> 'Western Europe ,LU'),
			array('value' => 'MC' , 'name'=> ' Western Europe,MC'),
			array('value' => 'NL' , 'name'=> 'Western Europe ,NL'),
			//Eastern Europe
			array('value' => 'BG' , 'name'=> 'Eastern Europe ,BG'),
			array('value' => 'BY' , 'name'=> 'Eastern Europe ,BY'),
			array('value' => 'CZ' , 'name'=> 'Eastern Europe ,CZ'),
			array('value' => 'HU' , 'name'=> 'Eastern Europe ,HU'),
			array('value' => 'MD' , 'name'=> 'Eastern Europe ,MD'),
			array('value' => 'PL' , 'name'=> 'Eastern Europe ,PL'),
			array('value' => 'RO' , 'name'=> 'Eastern Europe ,RO'),
			array('value' => 'RU' , 'name'=> 'Eastern Europe ,RU'),
			array('value' => 'SU' , 'name'=> 'Eastern Europe ,SU'),
			array('value' => 'SK' , 'name'=> 'Eastern Europe ,SK'),
			array('value' => 'UA' , 'name'=> 'Eastern Europe ,UA'),
			//Southern Europe
			array('value' => 'AD' , 'name'=> 'Southern Europe ,AD'),
			array('value' => 'AL' , 'name'=> 'Southern Europe ,AL'),
			array('value' => 'BA' , 'name'=> 'Southern Europe ,BA'),
			array('value' => 'ES' , 'name'=> 'Southern Europe ,ES'),
			array('value' => 'GI' , 'name'=> 'Southern Europe ,GI'),
			array('value' => 'GR' , 'name'=> 'Southern Europe ,GR'),
			array('value' => 'HR' , 'name'=> 'Southern Europe ,HR'),
			array('value' => 'IT' , 'name'=> 'Southern Europe ,IT'),
			array('value' => 'ME' , 'name'=> 'Southern Europe ,ME'),
			array('value' => 'MK' , 'name'=> 'Southern Europe ,MK'),
			array('value' => 'MT' , 'name'=> 'Southern Europe ,MT'),
			array('value' => 'CS' , 'name'=> 'Southern Europe ,CS'),
			array('value' => 'RS' , 'name'=> 'Southern Europe ,RS'),
			array('value' => 'PT' , 'name'=> 'Southern Europe ,PT'),
			array('value' => 'SI' , 'name'=> 'Southern Europe ,SI'),
			array('value' => 'SM' , 'name'=> 'Southern Europe ,SN'),
			array('value' => 'VA' , 'name'=> 'Southern Europe ,VA'),
			array('value' => 'YU' , 'name'=> 'Southern Europe ,YU'),
			//Northern America
			array('value' => 'BM' , 'name'=> 'Northern America ,BM'),
			array('value' => 'CA' , 'name'=> 'Northern America ,CA'),
			array('value' => 'GL' , 'name'=> 'Northern America ,GL'),
			array('value' => 'PM' , 'name'=> 'Northern America ,PM'),
			array('value' => 'US' , 'name'=> 'Northern America ,US'),
			//Caribbean
			array('value' => 'AG' , 'name'=> ' Caribbean ,AG'),
			array('value' => 'AI' , 'name'=> ' Caribbean ,AI'),
			array('value' => 'AN' , 'name'=> ' Caribbean ,AN'),
			array('value' => 'AW' , 'name'=> ' Caribbean ,AW'),
			array('value' => 'BB' , 'name'=> ' Caribbean ,BB'),
			array('value' => 'BL' , 'name'=> ' Caribbean ,BL'),
			array('value' => 'BS' , 'name'=> ' Caribbean ,BS'),
			array('value' => 'CU' , 'name'=> ' Caribbean ,CU'),
			array('value' => 'DM' , 'name'=> ' Caribbean ,DM'),
			array('value' => 'DU' , 'name'=> ' Caribbean ,DO'),
			array('value' => 'GD' , 'name'=> ' Caribbean ,GD'),
			array('value' => 'GP' , 'name'=> ' Caribbean ,GP'),
			array('value' => 'HT' , 'name'=> ' Caribbean ,HT'),
			array('value' => 'JM' , 'name'=> ' Caribbean ,JM'),
			array('value' => 'KN' , 'name'=> ' Caribbean ,KN'),
			array('value' => 'KY' , 'name'=> ' Caribbean ,KY'),
			array('value' => 'LC' , 'name'=> ' Caribbean ,LC'),
			array('value' => 'MF' , 'name'=> ' Caribbean ,MF'),
			array('value' => 'MQ' , 'name'=> ' Caribbean ,MQ'),
			array('value' => 'MS' , 'name'=> ' Caribbean ,MS'),
			array('value' => 'PR' , 'name'=> ' Caribbean ,PR'),
			array('value' => 'TC' , 'name'=> ' Caribbean ,TC'),
			array('value' => 'TT' , 'name'=> ' Caribbean ,TT'),
			array('value' => 'VC' , 'name'=> ' Caribbean ,VC'),
			array('value' => 'VG' , 'name'=> ' Caribbean ,VG'),
			array('value' => 'VI' , 'name'=> ' Caribbean ,VI'),
			//Central America
			array('value' => 'BZ' , 'name'=> ' Central America ,BZ'),
			array('value' => 'CR' , 'name'=> ' Central America ,CR'),
			array('value' => 'GT' , 'name'=> ' Central America ,GT'),
			array('value' => 'HN' , 'name'=> ' Central America ,HN'),
			array('value' => 'MX' , 'name'=> ' Central America ,MX'),
			array('value' => 'NI' , 'name'=> ' Central America ,NI'),
			array('value' => 'PA' , 'name'=> ' Central America ,PA'),
			array('value' => 'SV' , 'name'=> ' Central America ,SV'),
			//South America
			array('value' => 'AR' , 'name'=> ' South America ,AR'),
			array('value' => 'BO' , 'name'=> ' South America ,BO'),
			array('value' => 'BR' , 'name'=> ' South America ,BR'),
			array('value' => 'CV' , 'name'=> ' South America ,CV'),
			array('value' => 'CO' , 'name'=> ' South America ,CO'),
			array('value' => 'EC' , 'name'=> ' South America ,EC'),
			array('value' => 'FK' , 'name'=> ' South America ,FK'),
			array('value' => 'GF' , 'name'=> ' South America ,GF'),
			array('value' => 'GY' , 'name'=> ' South America ,GY'),
			array('value' => 'PE' , 'name'=> ' South America ,PE'),
			array('value' => 'PY' , 'name'=> ' South America ,PY'),
			array('value' => 'SR' , 'name'=> ' South America ,SR'),
			array('value' => 'UY' , 'name'=> ' South America ,UY'),
			array('value' => 'VE' , 'name'=> ' South America ,VE'),
			//Central Asia
			array('value' => 'TM' , 'name'=> ' Central Asia ,TM'),
			array('value' => 'TJ' , 'name'=> ' Central Asia ,TJ'),
			array('value' => 'KG' , 'name'=> ' Central Asia ,KG'),
			array('value' => 'KZ' , 'name'=> ' Central Asia ,KZ'),
			array('value' => 'UZ' , 'name'=> ' Central Asia ,UZ'),
			//Eastern Asia
			array('value' => 'CN' , 'name'=> ' Eastern Asia ,CN'),
			array('value' => 'HK' , 'name'=> ' Eastern Asia ,HK'),
			array('value' => 'JP' , 'name'=> ' Eastern Asia ,JP'),
			array('value' => 'KP' , 'name'=> ' Eastern Asia ,KP'),
			array('value' => 'KR' , 'name'=> ' Eastern Asia ,KR'),
			array('value' => 'MN' , 'name'=> ' Eastern Asia ,MN'),
			array('value' => 'MO' , 'name'=> ' Eastern Asia ,MO'),
			array('value' => 'TW' , 'name'=> ' Eastern Asia ,TW'),
			//Southern Asia
			array('value' => 'AF' , 'name'=> ' Southern Asia ,AF'),
			array('value' => 'BD' , 'name'=> ' Southern Asia ,BD'),
			array('value' => 'BT' , 'name'=> ' Southern Asia ,BT'),
			array('value' => 'IN' , 'name'=> ' Southern Asia ,IN'),
			array('value' => 'IK' , 'name'=> ' Southern Asia ,IK'),
			array('value' => 'LK' , 'name'=> ' Southern Asia ,LK'),
			array('value' => 'MV' , 'name'=> ' Southern Asia ,MV'),
			array('value' => 'NP' , 'name'=> ' Southern Asia ,NP'),
			array('value' => 'PK' , 'name'=> ' Southern Asia ,PK'),
			//South-Eastern Asia
			array('value' => 'BN' , 'name'=> ' Southern Asia ,BN'),
			array('value' => 'ID' , 'name'=> ' Southern Asia ,ID'),
			array('value' => 'KH' , 'name'=> ' Southern Asia ,KH'),
			array('value' => 'LA' , 'name'=> ' Southern Asia ,LA'),
			array('value' => 'MM' , 'name'=> ' Southern Asia ,MM'),
			array('value' => 'BU' , 'name'=> ' Southern Asia ,BU'),
			array('value' => 'MY' , 'name'=> ' Southern Asia ,MY'),
			array('value' => 'PH' , 'name'=> ' Southern Asia ,PH'),
			array('value' => 'SG' , 'name'=> ' Southern Asia ,SG'),
			array('value' => 'TH' , 'name'=> ' Southern Asia ,TH'),
			array('value' => 'TL' , 'name'=> ' Southern Asia ,TL'),
			array('value' => 'TP' , 'name'=> ' Southern Asia ,TP'),
			array('value' => 'VN' , 'name'=> ' Southern Asia ,VN'),
			//France
			/*array('value' => 'FR-A' , 'name'=> 'Alsace'),
			array('value' => 'FR-B' , 'name'=> 'Aquitaine'),
			array('value' => 'FR-C' , 'name'=> 'Auvergne'),
			array('value' => 'FR-P' , 'name'=> 'Basse-Normandie'),
			array('value' => 'FR-D' , 'name'=> 'Bourgogne'),
			array('value' => 'FR-E' , 'name'=> 'Bretagne'),
			array('value' => 'FR-F' , 'name'=> 'Centre-Val de Loire'),
			array('value' => 'FR-G' , 'name'=> 'Champagne-Ardenne'),
			array('value' => 'FR-H' , 'name'=> 'Corse'),
			array('value' => 'FR-I' , 'name'=> 'Franche-Comté'),
			array('value' => 'FR-Q' , 'name'=> 'Haute-Normandie'),
			array('value' => 'FR-J' , 'name'=> 'Île-de-France'),
			array('value' => 'FR-K' , 'name'=> 'Languedoc-Roussillon'),
			array('value' => 'FR-L' , 'name'=> 'Limousin'),
			array('value' => 'FR-M' , 'name'=> 'Lorraine'),
			array('value' => 'FR-N' , 'name'=> 'Midi-Pyrénées'),
			array('value' => 'FR-O' , 'name'=> 'Nord-Pas-de-Calais'),
			array('value' => 'FR-R' , 'name'=> 'Pays de la Loire'),
			array('value' => 'FR-S' , 'name'=> 'Picardie'),
			array('value' => 'FR-T' , 'name'=> 'Poitou-Charentes'),
			array('value' => 'FR-U' , 'name'=> 'Provence-Alpes-Côte'),
			array('value' => 'FR-V' , 'name'=> 'Rhône-Alpes'),*/
	);
return $location;
}



/*---------------------------------------*/
function sim_wp_location_form($mode="add", $pre_html="", $post_html=""){
     $regions = sim_map_build_region_select_options();
	 global $sim_wp_vars;
    $group='';
	foreach ($regions as $region)  {
		    $group .="<option value='".$region['value']."'>".$region['name']."</option>";
} 
$aspectRadioCk='';
if($sim_wp_vars['aspect_ratio']=='true'){
 $aspectRadioCk="checked";
 $valaspectRadio='true';
}
else{
$valaspectRadio='false';
}
$defualt=0;

	$html="<div class='input_section'>
	<form name='manualAddForm' method='post' enctype='multipart/form-data'>
	$pre_html
					<div class='input_title'>
					<h3><span class='fa fa-pencil'>&nbsp;</span>Add New Map</h3>
					<span class='submit'>
					<a href='".sim_WP_ADMIN_NAV_BASE.sim_WP_ADMIN_DIR."/pages/maps.php' style='margin-right:10px;'>
					<input type='button' value='".__("Cancel", sim_WP_TEXT_DOMAIN)."' class='button-primary'></a>
					<input type='submit' value='".__("Save this Map", sim_WP_TEXT_DOMAIN)."' class='button-primary'>
					</span>
					<div class='clearfix'></div>
					</div>
					<div class='all_options'>	
					<div class='option_input option_text'>
					<div id='top_input_panel'>
					<div class='top_input_panel_inner'>
					<label for='shortname_logo'>
					Name :</label>
					<input type='text' name='sim_wp_name'>
					</div>
					
					<div class='top_input_panel_inner'>
					<label for='shortname_logo'>
					Description :</label>
					<input type='text' name='sim_wp_description'>
					</div>
					</div>
					
					<div class='clearfix'></div>
					</div>
					 
					<div class='option_input option_text'>
					
					<div id='top_input_panel'>
					<div class='top_input_color_panel'>
					<label for='shortname_logo'>
					BG Color :</label>
					<input type='text' value='$sim_wp_vars[style_bg_color]' class='my-color-field wp-color-picker' id='sim_wp_bg_color' name='sim_wp_bg_color'>
					</div>
					
					<div class='top_input_color_panel'>
					<label for='shortname_logo'>
					FG Color :</label>
					<input type='text' value='$sim_wp_vars[style_map_color]' class='my-color-field wp-color-picker' id='sim_wp_border_color' name='sim_wp_border_color'>
					</div>
					
					<div class='top_input_color_panel'>
					<label for='shortname_logo'>
					Map Hover :</label>
					<input type='text'  class='my-color-field wp-color-picker' id='sim_wp_map_hover' name='sim_wp_map_hover'>
					</div>
					
					</div>
					<div  id='super-inter-active-map-block'>
					<div class='sim_maps_blcok' >
					<div id='sim-control-box'>
					<div id='super-arrow'>
					<a id='up' title='Up'><img src='".sim_WP_BASE."/images/icons/up.png'></a>
					<a id='left' title='Left'><img src='".sim_WP_BASE."/images/icons/left.png'></a>
					<a id='clearzoom' title='Clear Effect'><img src='".sim_WP_BASE."/images/icons/reset.png'></a>
					<a id='right' title='Right'><img src='".sim_WP_BASE."/images/icons/right.png'></a>
					<a id='down' title='Down'><img src='".sim_WP_BASE."/images/icons/down.png'></a>
					</div>
					<div id='super-arrows'>		
                    
					<div class='SimZoomBlock'>	
					<a id='widthplus' title='Zoom In'><img src='".sim_WP_BASE."/images/icons/zoomout.png'></a>
					<a id='verticalplus'><img src='".sim_WP_BASE."/images/icons/heightup.png' height='32' width='32'></a>
					</div>	  

					<div class='SimZoomBlock'>					
					<a id='widthminus' title='Zoom Out'><img src='".sim_WP_BASE."/images/icons/zoomin.png'></a>
					<a id='verticalminus' title='Height'><img src='".sim_WP_BASE."/images/icons/heightdown.png'></a>
					</div>

					
					</div>										
					</div>
					<div class=''  id='sim_interactive_map'>
					</div>
					</div>
					</div>
					</div>
					
				
				<input type='hidden' id='sim_wp_zoom' name='sim_wp_zoom' value=''/>
				<input type='hidden' id='sim_wp_map_heights' name='sim_wp_map_height' value=''/>
				<input type='hidden' id='sim_wp_left' name='sim_wp_left' value=''/>
				<input type='hidden' id='sim_wp_top' name='sim_wp_top' value=''/>
					
				<div class='option_input option_text' id='chosenSelectBox'>
					<label for='shortname_logo'>
					Map Region :</label>
					 <select name='sim_wp_locations'  class='chosen-select'>
                        ".$group."
                    </select>
                </div>	
					
					<div class='option_input option_text'>
					<div id='top_input_panels'>
					<div class='top_input_panel_inner'>
					<label for='shortname_logo'>
					Display Style :</label>
					<select name='sim_wp_map_region' id='sim_wp_map_region'>
					  <option value='regions'>Region</option>
					  <option value='markers'>Marker</option>
					  <option value='text'>Text Labels</option>
					</select>
					</div>
					
					<div class='top_input_panel_inner' id='sim_wp_marker_show' style='display:none'>
					<label for='shortname_logo'>
					Text/Marker size :</label>
					<input type='number' max='100' min='1' id='sim_wp_marker_size' name='sim_wp_marker_size' value='$sim_wp_vars[style_marker_size]'>
					</div>
					</div>
					
					<div class='clearfix'></div>
					</div>	
					
					
					<div class='option_input option_text'>
					<div id='top_input_panels'>
					<div class='top_input_panel_inner'>
					<label for='shortname_logo'>
					Hide Title :</label>
					 <input type='checkbox' name='sim_wp_hide_title' value='true' >
					</div>
					
					<div class='top_input_panel_inner'>
					<label for='shortname_logo'>
					  Aspect Ratio :</label>
					  <input type='checkbox' class='changeCheckVal' id='change_aspect_ratio' name='sim_wp_aspect_ratio' value='$valaspectRadio' $aspectRadioCk>
					 <input type='hidden'  id='change_aspect_ratio_val'  name='sim_wp_aspect_ratio' value='$valaspectRadio'>
					</div>
					</div>
					<div class='clearfix'></div>
					</div>	
					
					
					
					<div class='option_input option_text'>
					<label for='shortname_logo'>
					  Responsive Mode :</label>
					 <input type='checkbox' name='sim_wp_use_default' checked value='true' >
					<small>Use default map responsive or uncheck responsive mode and put the Width/height ex. 600 and 400. </small>
					</br></br>
					<div id='top_input_panels'>
					
					<div class='top_input_panel_inner'>
					<label for='shortname_logo'>
					Width :</label>
					<input type='text' name='sim_wp_width' id='sim_wp_map_width'>
					</div>
					
					<div class='top_input_panel_inner'>
					<label for='shortname_logo'>
					Height :</label>
					<input type='text' name='sim_wp_height' id='sim_wp_map_height'>
					</div>
					</div>
					

					<div class='clearfix'></div>
					</div>				
					
					<input type='hidden' name='sim_wp_image' id='sim_wp_mapimage'>
					<div class='option_input option_text'>
					<label for='shortname_logo'>LOCATIONS :</label>
					</div>
					
					<div class='option_input option_text'>
					<a  id='openDataModel'  data-plugins='open-modal' data-template='modal-photo-viewer'>
							<div class='sim_add_location'> <span class='fa fa-plus'></span>    Add Location</div>
						</a>
					</div>		

                    <table cellspacing='0' id='loc_table' class='widefat'>
					<thead><th>Location</th>
					<th>Title</th>
					<th>Description</th>
					<th>Call to action</th>
					<th>Color</th>
					<th>Action</th></thead>
					<tbody id='sim_map_record'>
					
					</tbody>
					</table>
					<input  type='hidden' id='numberofmap' value='0'  name='numberofmap'/>
					<input type='hidden' id='intMapObj' name='intMapObj'/>
                          					
					
					<div class='input_title'>

						<span class='submit'>
						<a href='".sim_WP_ADMIN_NAV_BASE.sim_WP_ADMIN_DIR."/pages/maps.php' style='margin-right:10px;'>
						<input type='button' value='".__("Cancel", sim_WP_TEXT_DOMAIN)."' class='button-primary'></a>
						<input type='submit' value='".__("Save this Map", sim_WP_TEXT_DOMAIN)."' class='button-primary'>

						</span>

						<div class='clearfix'></div>

					</div></div>"; 

		$html.=(function_exists("do_sim_wp_hook"))? do_sim_wp_hook("sim_wp_add_location_fields",  "append-return") : "" ;

		$html.=wp_nonce_field("add-location_single", "_wpnonce", true, false);

		$html.="

	$post_html

</form></div>";

$locationName=sim_map_build_location_select_options();
 $group='';
	foreach ($locationName as $state)  {
		    $group .="<option value='".$state['value']."'>".$state['name']."</option>";
} 
$html.="<div class='main-popup-holder' id='mainPopupContat'>
                     <div class='sim-popup' id='modernBrowserConatct'>
                        <a href='javascript:void(0);'  class='popup-closer simlinks hideDataModel'>Close</a> 
						<form id='sim-contact-form' action='#' method='post' name='form' role='form'>
						<h3 class='sim_cont_store'>Add Location</h3><h4 id='sim-msg-status'></h4>
						</label>
						<div class='input_section'>
						<div class='all_options'>
						<div class='sim_option_input option_text'>
						<lable for='shortname_logo'>Location :</logo>
						<input placeholder='Search a location' id='sim_search_location' value='NY, United States' name='sim_search_location' type='text'>
						<select name='sim_search_location_select' id='sim_search_location_select'  class='chosen-select'>
                        ".$group."
                       </select>
					    <button id='generalRegionList' class='regionListBtn' type='button' name='submit'>General Region List</button>
						<button id='enterlRegions' class='regionListBtn' type='button' name='submit'>Enter Region Manually</button>
						<a class='tag' target='new' href='https://developers.google.com/chart/interactive/docs/gallery/geochart#continent-hierarchy-and-codes'>learn more about Region code</a>
						<div id='map_canvas' class='newstore_map'>
						</div>
						</div>
						
						<div class='option_input option_text'>
						<label for='shortname_logo'>
						Search ID :</label>
						<input type='text' name='ssf_wp_search_id' id='ssf_wp_search_id' readonly>
						<div class='clearfix'></div>
						</div>
						
						
						<div class='option_input option_text'>	
							<div id='top_input_panel'>
							 <div class='top_input_first' style='vertical-align: top;'>
								<label for='shortname_logo'>
									Title :</label>
								<input type='text' name='ssf_wp_title' id='ssf_wp_title'>
							 </div>
							 <div class='top_input_second' style='vertical-align: top;'>
								<a class='tag' target='new' href='http://superstorefinder.net/superinteractivemaps/custom-marker-map-icon'>learn more about custom marker</a>
							 </div>
							</div>
							<div class='clearfix'></div>
						</div>
						
						
						
						<div class='option_input option_text' id='RegionMarkercolor'>
						<label for='shortname_logo'>
						Region/Marker color :</label>
						<input type='text' name='ssf_wp_data_color' value='".$sim_wp_vars['marker_map_color']."' class='my-color-field wp-color-picker' id='ssf_wp_data_color'>
						<div class='clearfix'></div>
						</div>
						<input type='hidden' id='editIdValue'>
						<div class='option_input option_text' id='sim_discriptions'>
						<label for='shortname_logo'>
						Description :</label>
						<textarea id='sim_wp_html_discription' name='sim_wp_html_discription' style='width:500px'> </textarea>
						<div class='clearfix'></div>
						</div>
				   <div class='option_input option_text'>	
				   <div id='top_input_panel'>
					<div class='top_input_panel_inner' style='vertical-align: top;'>
					<label for='shortname_logo'>
					Call to action :</label>
					<select name='sim_wp_display_mode' id='sim_wp_display_mode'>
						  <option value='1' selected> Link to existing window</option>
						  <option value='2'>Link to new window </option>
						  <option value='3'>Pop up information </option>
						  <option value='4'>Link to Super Store Finder (Existing Window)</option>
						  <option value='5'>Link to Super Store Finder (New Window)</option>
						</select>
					</div>
					

					
					<div class='top_input_panel_inner' id='sim_wp_display_mode1'>
					<label for='shortname_logo'>
					URL :</label>
					<input type='text' name='sim_wp_url' id='sim_wp_url'>
					</div>
					
					<div class='top_input_panel_inner' id='sim_wp_display_mode3' style='display:none; margin-left:375px;'>
					<label for='shortname_logo'>
					Location :</label>
					<input type='text' name='sim_wpd_boxsearch' id='sim_wpd_boxsearch'>
					</div>
					
					<div class='top_input_panel_inner' id='superStoreLearnn' style='display:none;'>
					<a style='left: 126px;' class='tag' target='new' href='http://superstorefinder.net/superinteractivemaps/link-to-your-store-locator/'>Learn more</a>
					</div>
					
					<div class='top_input_panel_inner' id='sim_wp_display_mode2' style='display:none;'>
					<label for='shortname_logo'>
					Information :</label>
					<textarea id='sim_wp_information' name='sim_wp_information' style='width:370px'> </textarea>
					</div>
					</div>
					</div>
						<div class='option_input option_text'>
						<button name='submit' type='button'  class='hideDataModel sim_close_location'>Close</button>
						<button name='submit' type='button'  class='sim_add_location' id='add-location-submit'>Save Location</button>
						</div>
						</div>
						</div>
                        </form>
                     </div>
                  </div>";
	return $html;
}

function sim_wp_add_location() {

	global $wpdb;
	$fieldList=""; $valueList="";
	foreach ($_POST as $key=>$value) {
		if (preg_match("@sim_wp_@", $key)) {
			$fieldList.="$key,";
			if (is_array($value)){
				$value=serialize($value); //for arrays being submitted
				$valueList.="'$value',";
			} else {
				$valueList.=$wpdb->prepare("%s", sim_comma(stripslashes($value))).",";
			}
		}
	}

	$fieldList=substr($fieldList, 0, strlen($fieldList)-1);
	$valueList=substr($valueList, 0, strlen($valueList)-1);
	$wpdb->query("INSERT INTO ".sim_WP_TABLE." ($fieldList) VALUES ($valueList)");
	$new_loc_id=$wpdb->insert_id;	
 	if (!empty($_POST['numberofmap']) && $_POST['numberofmap']>0){
		sim_wp_process_map_data($_POST , "insert", $new_loc_id);
	}

}

/* map data table query */
/*-----------------------------------------------------------*/

function sim_wp_process_map_data($map_data, $db_action="insert", $ssf_wp_id="") {

	global $wpdb;
	$id_string="";
	if (!is_array($ssf_wp_id) && preg_match("@,@", $ssf_wp_id)) {
		$id_string=$ssf_wp_id;
		$ssf_wp_id=explode(",",$id_string);
		$rplc_arr=array_fill(0, count($ssf_wp_id), "%d"); 
		$id_string=implode(",", array_map(array($wpdb, "prepare"), $rplc_arr, $ssf_wp_id)); 

	} elseif (is_array($ssf_wp_id)) {
		$rplc_arr=array_fill(0, count($ssf_wp_id), "%d"); 
 		$id_string=implode(",", array_map(array($wpdb, "prepare"), $rplc_arr, $ssf_wp_id)); 
	} else {
		$id_string=$wpdb->prepare("%d", $ssf_wp_id); 
	}
	
if ($db_action=="insert") {
$_POST['sim_wpd_data_id']=$ssf_wp_id;	
$postedData = $_POST["intMapObj"];
$tempData = str_replace("\\", "",$postedData);
$cleanData=json_decode($tempData,true);
if(!empty($cleanData)){
foreach ($cleanData as $fetcharr){   
		$fieldList=""; $valueList="";
		foreach ($fetcharr as $key=>$value){
		   if ($key=="id") {
				//$key='sim_wpd_id';
			}
			else{
			if($key=="sim_color_box")
			{
				$key='sim_wpd_data_color';
			}
				$fieldList.="$key,";
				if (is_array($value)){
					$value=serialize($value); //for arrays being submitted
					$valueList.="'$value',";
				} else {
					$valueList.=$wpdb->prepare("%s", $value).",";
				}	
			}
						
		}
		$key='sim_wpd_data_id';
		$fieldList.="$key,";
		$valueList.="'$ssf_wp_id',";
		$fieldList=substr($fieldList, 0, strlen($fieldList)-1);
		$valueList=substr($valueList, 0, strlen($valueList)-1);
		$wpdb->query("INSERT INTO ".sim_WP_TABLE_DATA." ($fieldList) VALUES ($valueList)");
	} 
 } 
} elseif ($db_action=="delete") {
	        $data_wp_id=explode(",",$id_string);
			foreach($data_wp_id as $value){
				$query="DELETE FROM ".sim_WP_TABLE_DATA." WHERE sim_wpd_data_id IN ($value)";
				$wpdb->query($query);
			}
			}
}
/* end map data query */

/*--------------------------------------------------*/

function sim_wp_define_db_tables() {
	global $wpdb; 
	$sim_wp_db_prefix = $wpdb->prefix; 
	if (!defined('sim_WP_DB_PREFIX')){ define('sim_WP_DB_PREFIX', $sim_wp_db_prefix); }
	if (!empty($sim_wp_db_prefix)) {
		if (!defined('sim_WP_TABLE')){ define('sim_WP_TABLE', sim_WP_DB_PREFIX."sim_wp_maps"); }
		if (!defined('sim_WP_TABLE_DATA')){ define('sim_WP_TABLE_DATA', sim_WP_DB_PREFIX."sim_wp_maps_data"); }
		if (!defined('sim_WP_SETTING_TABLE')){ define('sim_WP_SETTING_TABLE', sim_WP_DB_PREFIX."sim_wp_setting"); }
	}

}

sim_wp_define_db_tables(); 

/*----------------------------------------------------*/

function sim_wp_single_location_info($value, $colspan, $bgcol) {
	global $sim_wp_hooks, $wpdb,$admin_int_array;
	$regions = sim_map_build_region_select_options();
    $group='';
	$defualt=0;
	$dataValue ='';
	$j=0;
	$sim_wp_locations=simParseToHXML($value['sim_wp_locations']);
	foreach ($regions as $region)  {
	        if($sim_wp_locations==$region['value']){ $selected='selected'; } else { $selected=''; }
		    $group .="<option value='".$region['value']."' ".$selected.">".$region['name']."</option>";
	} 
	$_GET['edit'] = $value['sim_wp_id']; 
	$mapDataId=$value['sim_wp_id'];
	print "<tr style='background-color:$bgcol' id='sim_wp_tr_data-$value[sim_wp_id]'>";
	$cancel_onclick = "location.href=\"".str_replace("&edit=$_GET[edit]", "",$_SERVER['REQUEST_URI'])."\"";
	$markerSelect='';
	$regionSelect='';
	$textSelect='';
	$fontAwesome='';
	$markers='';
	if($value['sim_wp_map_region']=='markers'){ $markerSelect='selected'; $displayMarker='display:inline-block';  }
	else if($value['sim_wp_map_region']=='regions'){ $regionSelect='selected'; $displayMarker='display:none'; }
	else{ $textSelect='selected'; $fontAwesome='sim_interactive_map'; $markers='marker'; $displayMarker='inline-block'; }
	if($value['sim_wp_hide_title']=='true') { $hideTitle = "checked"; } else { $hideTitle =""; }
	if($value['sim_wp_aspect_ratio']=='true') { $aspect_ratio = "checked"; } else { $aspect_ratio =""; }
	
	$ZoomDisable=$ZoomEnable='';
	if($value['sim_wp_zoom_setting']=='false') { $ZoomDisable = "selected"; } else { $ZoomDisable =""; }
	if($value['sim_wp_zoom_setting']=='true') { $ZoomEnable = "selected"; } else { $ZoomEnable =""; }

	
	if($value['sim_wp_use_default']=='true') { $defualtmode = "checked"; } else{ $defualtmode = ""; }
	print "<td colspan='$colspan'>
	<div class='input_section'>
	<a name='a$value[sim_wp_id]'></a>
	<form name='manualAddForm'  method='post' enctype='multipart/form-data'>
					<div class='input_title'>
						<h3><span class='fa fa-pencil'>&nbsp;</span> Edit Map</h3>
						<span class='submit'>
						<input type='submit' value='".__("Save", sim_WP_TEXT_DOMAIN)."' class='button-primary'> <input type='button' class='sim-button' value='".__("Cancel", sim_WP_TEXT_DOMAIN)."' onclick='$cancel_onclick'>
						</span>
						<div class='clearfix'></div>
					</div>

					<div class='all_options'>	
					<div class='option_input option_text'>
					<div id='top_input_panel'>
					<div class='top_input_panel_inner'>
					<label for='shortname_logo'>
					Name :</label>
					<input type='hidden' id='mapDataId' value='$value[sim_wp_id]'>
					<input type='text' name='sim_wp_name-$value[sim_wp_id]' value='$value[sim_wp_name]'>
					</div>
					<input type='hidden' id='editIdValue'>
					
					<div class='top_input_panel_inner'>
					<label for='shortname_logo'>
					Description :</label>
					<input type='text' name='sim_wp_description-$value[sim_wp_id]'  value='$value[sim_wp_description]'>
					</div>
					</div>
					
					<div class='clearfix'></div>
					</div>
					 
					<div class='option_input option_text'>
					
					<div id='top_input_panel'>
					<div class='top_input_color_panel'>
					<label for='shortname_logo'>
					BG Color :</label>
					<input type='text' class='my-color-field wp-color-picker' id='sim_wp_bg_color' name='sim_wp_bg_color-$value[sim_wp_id]' value='$value[sim_wp_bg_color]'>
					</div>
					
					<div class='top_input_color_panel'>
					<label for='shortname_logo'>
					FG Color :</label>
					<input type='text' class='my-color-field wp-color-picker' id='sim_wp_border_color' name='sim_wp_border_color-$value[sim_wp_id]' value='$value[sim_wp_border_color]'>
					</div>
					
					
					<div class='top_input_color_panel'>
					<label for='shortname_logo'>
					Map Hover :</label>
					<input type='text' value='$value[sim_wp_map_hover]' class='my-color-field wp-color-picker' id='sim_wp_map_hover' name='sim_wp_map_hover-$value[sim_wp_id]'>
					</div>
					
					</div>
					
					<div  id='super-inter-active-map-block'>
					<div class='sim_maps_blcok'>
					
					<div id='sim-control-box'>
					<div id='super-arrow'>
						<a id='up' title='Up'><img src='".sim_WP_BASE."/images/icons/up.png'></a>
						<a id='left' title='Left'><img src='".sim_WP_BASE."/images/icons/left.png'></a>
						<a id='clearzoom' title='Clear Effect'><img src='".sim_WP_BASE."/images/icons/reset.png'></a>
						<a id='right' title='Right'><img src='".sim_WP_BASE."/images/icons/right.png'></a>
						<a id='down' title='Down'><img src='".sim_WP_BASE."/images/icons/down.png'></a>
					</div>
					<div id='super-arrows'>		
                    
					<div class='SimZoomBlock'>	
						<a id='widthplus' title='Zoom In'><img src='".sim_WP_BASE."/images/icons/zoomout.png'></a>
						<a id='verticalplus'><img src='".sim_WP_BASE."/images/icons/heightup.png' height='32' width='32'></a>
					</div>	

					<div class='SimZoomBlock'>					
						<a id='widthminus' title='Zoom Out'><img src='".sim_WP_BASE."/images/icons/zoomin.png'></a>
						<a id='verticalminus' title='Height'><img src='".sim_WP_BASE."/images/icons/heightdown.png'></a>
					</div>
					
					</div>										
				</div>

				<div class='$fontAwesome'  id='sim_interactive_map'>
				</div>
				</div>
				</div>
				</div>
						
				<input type='hidden' id='sim_wp_zoom'  name='sim_wp_zoom-$value[sim_wp_id]' value='$value[sim_wp_zoom]'/>
				<input type='hidden' id='sim_wp_map_heights' name='sim_wp_map_height-$value[sim_wp_id]' value='$value[sim_wp_map_height]'/>
				<input type='hidden' id='sim_wp_left' name='sim_wp_left-$value[sim_wp_id]' value='$value[sim_wp_left]'/>
				<input type='hidden' id='sim_wp_top' name='sim_wp_top-$value[sim_wp_id]' value='$value[sim_wp_top]'/>
				
					<div class='option_input option_text' id='chosenSelectBox'>
					<label for='shortname_logo'>
					Map Region :</label>
					 <select name='sim_wp_locations-$value[sim_wp_id]' class='chosen-select'>
                        ".$group."
                    </select>
                    </div>
					
					<div class='option_input option_text'>
					<div id='top_input_panels'>
					<div class='top_input_panel_inner'>
					<label for='shortname_logo'>
					Display Style :</label>
					<select name='sim_wp_map_region-$value[sim_wp_id]' id='sim_wp_map_region'>
					  <option value='regions' $regionSelect >Region</option>
					  <option value='markers' $markerSelect>Marker</option>
					   <option value='text' $textSelect>Text Labels</option>
					</select>
					</div>
					
					<div class='top_input_panel_inner' id='sim_wp_marker_show' style='$displayMarker'>
					<label for='shortname_logo'>
					Text/Marker size :</label>
					<input type='number' max='100' min='1' id='sim_wp_marker_size' name='sim_wp_marker_size-$value[sim_wp_id]' value='$value[sim_wp_marker_size]'>
					</div>
					</div>
					
					<div class='clearfix'></div>
					</div>	
					
					
					<div class='option_input option_text'>
					<div id='top_input_panels'>
					<div class='top_input_panel_inner'>
					<label for='shortname_logo'>
					Hide Title :</label>
					 <input type='checkbox' class='changeCheckVal'  id='change_hide_title'  name='sim_wp_hide_title-$value[sim_wp_id]' value='$value[sim_wp_hide_title]' $hideTitle>
					 <input type='hidden'  id='change_hide_title_val'  name='sim_wp_hide_title-$value[sim_wp_id]' value='$value[sim_wp_hide_title]'>
					</div>
					
					<div class='top_input_panel_inner'>
					<label for='shortname_logo'>
					  Aspect Ratio :</label> 
					<input type='checkbox' class='changeCheckVal' id='change_aspect_ratio' name='sim_wp_aspect_ratio-$value[sim_wp_id]' value='$value[sim_wp_aspect_ratio]' $aspect_ratio>
					 <input type='hidden'  id='change_aspect_ratio_val'  name='sim_wp_aspect_ratio-$value[sim_wp_id]' value='$value[sim_wp_aspect_ratio]'>
					</div>
					</div>
					<div class='clearfix'></div>
					</div>	
					
					<div class='option_input option_text'>
					<label for='shortname_logo'>
					  Responsive Mode :</label>
					 <input type='checkbox' class='changeCheckVal'  id='change_use_default' name='sim_wp_use_default-$value[sim_wp_id]'  value='$value[sim_wp_use_default]' $defualtmode>
					 <input type='hidden'  id='change_use_default_val'  name='sim_wp_use_default-$value[sim_wp_id]' value='$value[sim_wp_use_default]'>
					<small>Use default map responsive or uncheck responsive mode and put the Width/height ex. 600 and 400. </small>
					</br></br>
					<div id='top_input_panels'>
					<div class='top_input_panel_inner'>
					<label for='shortname_logo'>
					Width(px):</label>
					<input type='text' id='sim_wp_map_width' name='sim_wp_width-$value[sim_wp_id]' value='$value[sim_wp_width]'>
					</div>
					
					<div class='top_input_panel_inner'>
					<label for='shortname_logo'>
					Height(px) :</label>
					<input type='text' id='sim_wp_map_height' name='sim_wp_height-$value[sim_wp_id]' value='$value[sim_wp_height]'>
					</div>
					</div>
					
					<div class='clearfix'></div>
					</div>
					
					
					<input type='hidden' name='sim_wp_image-$value[sim_wp_id]' id='sim_wp_mapimage'>
					<div class='option_input option_text'>
					<label for='shortname_logo'>LOCATIONS :</label>
					</div>
					
					<div class='option_input option_text'>
					<a id='openDataModel'  data-plugins='open-modal' data-template='modal-photo-viewer'>
							<div class='sim_add_location'> <span class='fa fa-plus'></span>Add Location</div>
						</a>
					</div>		

                    <table cellspacing='0' id='loc_table' class='widefat'>
					<thead><th>Location</th>
					<th>Title</th>
					<th>Description</th>
					<th>Call to action</th>
					<th>Color</th>
					<th>Action</th></thead>
					<tbody id='sim_map_record'>";

if($mapDataRecord=$wpdb->get_results("SELECT * FROM ".sim_WP_TABLE_DATA." where sim_wpd_data_id=".$mapDataId." ", ARRAY_A)) {
$j=1;
foreach ($mapDataRecord as $row) {	
$discription=urldecode($row['sim_wpd_description']);
$discription = substr($discription, 0, 100);
if($row['sim_wpd_call_to_action']=='1'){ $display_mode='Link to existing window'; } 
	else if($row['sim_wpd_call_to_action']=='2') { $display_mode='Link to new window'; }else if($row['sim_wpd_call_to_action']=='4' || $row['sim_wpd_call_to_action']=='5') { $display_mode='Link to Super Store Finder'; } else{
	$display_mode='Pop up information';
	}
				
print "<tr id='sim_row_".$row['sim_wpd_id']."'>
<td>$row[sim_wpd_locations]</td>
<td><span class='$markers'>$row[sim_wpd_title]</span>
</td>
<td>$discription
</td>
<td>
$display_mode
</td>
<td>
<div class='sim_color_box' style='background-color:".$row['sim_wpd_data_color']."' id='sim_color_box".$row['sim_wpd_id']."'></div>
</td>
<td>
<a class='edit_loc_link add_edit_loc_link' id='".$row['sim_wpd_id']."'><span class='fa fa-pencil'>&nbsp;</span>
 Edit </a> |
<a class='del_loc_link edit_del_loc_link' id='".$row['sim_wpd_id']."'><span class='fa fa-trash'>&nbsp;</span>
Delete </a>
</td>
</tr>";

$sim_int_array = array(
	 "id" => $row['sim_wpd_id'],
	 "sim_wpd_search_id" => $row['sim_wpd_search_id'],
	 "sim_wpd_locations"=>$row['sim_wpd_locations'],
	 "sim_wpd_title"=>$row['sim_wpd_title'],
	 "sim_wpd_description"=>$row['sim_wpd_description'],
	 "sim_wpd_call_to_action"=>$row['sim_wpd_call_to_action'],
	 "sim_color_box"=>$row['sim_wpd_data_color'],
	 "sim_wpd_url"=>$row['sim_wpd_url'],
	 "sim_wpd_information"=>$row['sim_wpd_information'],
	 "sim_wpd_boxsearch"=>$row['sim_wpd_boxsearch'],
	);
			
array_push($admin_int_array, $sim_int_array);
$j++; ?>
<script> mapDataCount.push('<?php echo $row['sim_wpd_id']; ?>'); superIntArray=<?php echo json_encode($admin_int_array); ?>; </script>
<?php }
wp_localize_script('settingMap', 'superIntArray', $admin_int_array);
}
$dataValue = rtrim($dataValue, ',');
				
					print "</tbody>
					</table>
					
					<div class='input_title'>

						<span class='submit'>
						<a href='".sim_WP_ADMIN_NAV_BASE.sim_WP_ADMIN_DIR."/pages/maps.php' style='margin-right:10px;'>
						<input type='button' value='".__("Cancel", sim_WP_TEXT_DOMAIN)."' class='button-primary'></a>
						<input type='submit' value='".__("Save this Map", sim_WP_TEXT_DOMAIN)."' class='button-primary'>

						</span>

						<div class='clearfix'></div>

					</div></div>";

		if (function_exists("do_sim_wp_hook")) {
			sim_wp_show_custom_fields();
		}
	if (function_exists("do_sim_wp_hook")) {do_sim_wp_hook("sim_wp_single_location_edit", "select-top");}
	print "</form></td>";
$locationName=sim_map_build_location_select_options();
 $group='';
	foreach ($locationName as $state)  {
		    $group .="<option value='".$state['value']."'>".$state['name']."</option>";
} 

print "</tr>";

print "<div class='main-popup-holder' id='mainPopupContat'>
                     <div class='sim-popup' id='modernBrowserConatct'>
                        <a href='javascript:void(0);' class='popup-closer hideDataModel simlinks'>Close</a> 
						<form id='sim-contact-form' enctype='multipart/form-data' action='#' method='post' name='form' role='form'>
						<h3 class='sim_cont_store'>Add Location</h3><h4 id='sim-msg-status'></h4>
						</label>
						<div class='input_section'>
						<div class='all_options'>
						<div class='sim_option_input option_text'>
						<lable for='shortname_logo'>Location :   </logo>
						<input placeholder='Search a location' id='sim_search_location' name='sim_search_location' type='text'>
						<select name='sim_search_location_select' id='sim_search_location_select'  class='chosen-select'>
                        ".$group."
                       </select>
						<button id='generalRegionList' class='regionListBtn' type='button' name='submit'>General Region List</button>
						<button id='enterlRegions' class='regionListBtn' type='button' name='submit'>Enter Region Manually</button>
						<a class='tag' target='new' href='https://developers.google.com/chart/interactive/docs/gallery/geochart#continent-hierarchy-and-codes'>learn more about Region code</a>
						
						<div id='map_canvas' class='newstore_map'>
						</div>
						</div>
						
						
						<div class='option_input option_text'>
						<label for='shortname_logo'>
						Search ID :</label>
						<input type='text' name='ssf_wp_search_id' id='ssf_wp_search_id' readonly>
						<div class='clearfix'></div>
						</div>
						
						
						<div class='option_input option_text'>	
							<div id='top_input_panel'>
							 <div class='top_input_first' style='vertical-align: top;'>
								<label for='shortname_logo'>
									Title :</label>
								<input type='text' name='ssf_wp_title' id='ssf_wp_title'>
							 </div>
							 <div class='top_input_second' style='vertical-align: top;'>			
								<a class='tag' target='new' href='http://superstorefinder.net/superinteractivemaps/custom-marker-map-icon'>learn more about custom marker</a>
							 </div>
							</div>
							<div class='clearfix'></div>
						</div>
						
						
						<div class='option_input option_text' id='RegionMarkercolor'>
						<label for='shortname_logo'>
						Region/Marker color :</label>
						<input type='text' name='ssf_wp_data_color' class='my-color-field wp-color-picker' id='ssf_wp_data_color' >
						<div class='clearfix'></div>
						</div>
						
						<div class='option_input option_text' id='sim_discriptions'>
						<label for='shortname_logo'>
						Description :</label>
						<textarea id='sim_wp_html_discription' name='sim_wp_html_discription' style='width:500px'> </textarea>
						<div class='clearfix'></div>
						</div>
				   <div class='option_input option_text'>	
				   <div id='top_input_panel'>
					<div class='top_input_panel_inner' style='vertical-align: top;'>
					<label for='shortname_logo'>
					Call to action :</label>
					<select name='sim_wp_display_mode' id='sim_wp_display_mode'>
						  <option value='1' selected> Link to existing window</option>
						  <option value='2'>Link to new window </option>
						  <option value='3'>Pop up information </option>
						  <option value='4'>Link to Super Store Finder (Existing Window)</option>
						  <option value='5'>Link to Super Store Finder (New Window)</option>
						</select>
					</div>
					
					<div class='top_input_panel_inner' id='sim_wp_display_mode1'>
					<label for='shortname_logo'>
					URL :</label>
					<input type='text' name='sim_wp_url' id='sim_wp_url'>
					</div>
					
					<div class='top_input_panel_inner' id='sim_wp_display_mode3' style='display:none; margin-left:375px;'>
					<label for='shortname_logo'>
					Location :</label>
					<input type='text' name='sim_wpd_boxsearch' id='sim_wpd_boxsearch'>
					</div>
					
					 <div class='top_input_panel_inner' id='superStoreLearnn' style='display:none;'>
					<a style='left: 126px;' class='tag' target='new' href='http://superstorefinder.net/superinteractivemaps/link-to-your-store-locator/'>Learn more</a>
					</div>
					
					<div class='top_input_panel_inner' id='sim_wp_display_mode2' style='display:none;'>
					<label for='shortname_logo'>
					Information :</label>
					<textarea id='sim_wp_information' name='sim_wp_information' style='width:370px'> </textarea>
					</div>
					</div>
					</div>
					<div class='option_input option_text'>
					<button name='submit' type='button' id='editOpenDataModel' class='sim_add_location'>Save Location</button>
					<button name='submit' type='button'  class='hideDataModel sim_close_location'>Close</button>
					</div>
					</div>
					</div>
					</form>
				 </div>
			  </div>";

	}

/*-------------------------------------------*/

function sim_wp_module($mod_name, $mod_heading="", $height="") {

	global $sim_wp_vars, $wpdb;

	if (file_exists(sim_WP_INCLUDES_PATH."/module-{$mod_name}.php")) {

		$css=(!empty($height))? "height:$height;" : "" ;

		print "<table class='widefat' style='background-color:transparent; border:0px; padding:4px; {$css}'>";

		if ($mod_heading){

			print "<thead><tr><th style='font-weight:bold; height:22px;'>$mod_heading</th></tr></thead>";

		}

		print "<tbody style='background-color:transparent; border:0px;'><tr><td style='background-color:transparent; border:0px;'>";

		include(sim_WP_INCLUDES_PATH."/module-{$mod_name}.php");

		print "</td></tr></tbody></table><br>";

	}

}

/*--------------------------------------------*/

function sim_wp_readme_parse($path_to_readme, $path_to_env){

include($path_to_env);
ob_start();
include($path_to_readme);
$txt=ob_get_contents();
ob_clean();
$toc=$txt;
	preg_match_all("@\=\=\=[ ]([^\=\=\=]+)[ ]\=\=\=@", $toc, $toc_match_0);
	preg_match_all("@\=\=[ ]([^\=\=]+)[ ]\=\=@", $toc, $toc_match_1); 
	preg_match_all("@\=[ ]([^\=]+)[ ]\=@", $toc, $toc_match_2); 
	$toc_cont="";
	foreach ($toc_match_2[1] as $heading) {
	    if (!in_array($heading, $toc_match_1[1]) && !in_array($heading, $toc_match_0[1]) && !preg_match("@^[0-9]+\.[0-9]+@", $heading)) {
		$toc_cont.="<li style='margin-left:30px; list-style-type:circle'><a href='#".sim_comma($heading)."' style='text-decoration:none'>$heading</a></li></li>";
	    } elseif (!in_array($heading, $toc_match_0[1]) && !preg_match("@^[0-9]+\.[0-9]+@", $heading)) { 
	    	$toc_cont.="<li style='margin-left:15px; list-style-type:disc'><b><a href='#".sim_comma($heading)."' style='text-decoration:none'>$heading</a></b></li>";
	    }
	}

$th_start="<th style='font-size:125%; font-weight:bold;'>";
$h2_start="<h2 style='font-family:Georgia; margin-bottom:0.05em;'>";
$h3_start="<h3 style='font-family:Georgia; margin-bottom:0.05em; margin-top:0.3em'>";
$txt=str_replace("=== ", "$h2_start", $txt);
$txt=str_replace(" ===", "</h2>", $txt);
$txt=str_replace("== ", "<table class='widefat' ><thead>$th_start", $txt);
$txt=str_replace(" ==", "</th></thead></table><!--a style='float:right' href='#readme_toc'>Table of Contents</a-->", $txt);
$txt=str_replace("= ", "$h3_start", $txt);
$txt=str_replace(" =", "</h3><a style='float:right; position:relative; top:-1.5em; font-size:10px' href='#readme_toc'>".__("table of contents", sim_WP_TEXT_DOMAIN)."</a>", $txt);
$txt=preg_replace("@Tags:[ ]?[^\r\n]+\r\n@", "", $txt);
$txt=str_replace("</h2>", "</h2><a name='readme_toc'></a><div style='float:right;  width:500px; border-radius:1em; border:solid silver 1px; padding:7px; padding-top:0px; margin:10px; margin-right:0px;'><h3>".__("Table of Contents", sim_WP_TEXT_DOMAIN)."</h2>$toc_cont</div>", $txt);
$txt=preg_replace_callback("@$h2_start<u>([^<.]*)</u></h1>@s", create_function('$matches', 
	'return "<h2 style=\'font-family:Georgia; margin-bottom:0.05em;\'><a name=\'".sim_comma($matches[1])."\'></a>$matches[1]</u></h1>";'), $txt);

$txt=preg_replace_callback("@$th_start([^<.]*)</th>@s", create_function('$matches',
	'return "<th style=\'font-size:125%; font-weight:bold;\'><a name=\'".sim_comma($matches[1])."\'></a>$matches[1]</th>";'), $txt);
$txt=preg_replace_callback("@$h3_start( )*([^<.]*)( )*</h3>@s", create_function('$matches',
	'return "<h3 style=\'font-family:Georgia; margin-bottom:0.05em; margin-top:0.3em\'><a name=\"".sim_comma($matches[2])."\"></a>{$matches[1]}$matches[2]</h3>";'), $txt);
$txt=preg_replace("@\[([a-zA-Z0-9_/?&amp;\&\ \.%20,=\-\+\-\']+)*\]\(([a-zA-Z]+://)(([.]?[a-zA-Z0-9_/?&amp;%20,=\-\+\-\#]+)*)\)@s", "<a onclick=\"window.parent.open('\\2'+'\\3');return false;\" href=\"#\">\\1</a>", $txt);
$txt=preg_replace("@\*[ ]?[ ]?([^\r\n]+)*(\r\n)?@s", "<li style='margin-left:15px; margin-bottom:0px;'>\\1</li>", $txt);
$txt=preg_replace("@`([^`]+)*`@", "<strong class='sim_wp_code code' style='padding:2px; border:0px'>\\1</strong>", $txt);
$txt=preg_replace("@__([^__]+)__@", "<strong>\\1</strong>", $txt);
$txt=preg_replace("@\r\n([0-9]\.)@", "\r\n&nbsp;&nbsp;&nbsp;\\1", $txt);
$txt=preg_replace("@([A-Za-z-0-9\/\\&;# ]+): @", "<strong>\\1: </strong>", $txt);
$txt=sim_do_hyperlink($txt, "'_blank'", "protocol");
print nl2br($txt);
}

/*---------------------------------------------------------------*/

function sim_wp_translate_stamp($dateVar="",$mode="return", $date_only=0, $abbreviate_month=0) {
if ($dateVar!="") {

		$mm=substr($dateVar,4,2);

		$dd=substr($dateVar,6,2);

		if ($dd<10) {$dd=str_replace("0","",$dd); } 		$yyyy=substr($dateVar,0,4);

		if (strlen($yyyy)==2 && $yyyy>=50) {

			$yyyy="19".$yyyy;

		}

		elseif (strlen($yyyy)==2 && $yyyy>=00 && $yyyy<50) {

			$yyyy="20".$yyyy;

		}

}

$months=array("January","February","March","April","May","June","July","August","September","October","November","December");

$dt="";

if (!empty($mm)) {

	$dt=$months[$mm-1];

	

	if ($abbreviate_month!=0) 

		$dt=substr($dt,0,3).".";

	

	if ($dd!="" && $yyyy!="")

		$dt.=" $dd, $yyyy";

}



if ($date_only==0) {

$hr=substr($dateVar,8,2);

$min=substr($dateVar,10,2);

$sec=substr($dateVar,12,2);

if ($hr<12) {$hr=str_replace("0","",$hr); }

if ($hr>12) {$hr=$hr-12; $suffix="pm";} else {$suffix="am";}

if ($hr==12) {$suffix="pm";}

if ($hr==0) {$hr=12;}



$dt.=" $hr:$min:$sec $suffix";



}



if ($mode!="print")

	return $dt;

elseif ($mode=="print")

	print $dt;



}

/*---------------------------------------------------------------*/

function sim_wp_translate_date($dateVar="",$mode="return") {

if ($dateVar!="") {

		$parts=explode("/",$dateVar);

		$mm=trim($parts[0]);

		$dd=trim($parts[1]);

		if ($dd<10) {$dd=str_replace("0","",$dd); } 		$yyyy=trim($parts[2]);

		if (strlen($yyyy)==2 && $yyyy>=50) {

			$yyyy="19".$yyyy;

		}

		elseif (strlen($yyyy)==2 && $yyyy>=00 && $yyyy<50) {

			$yyyy="20".$yyyy;

		}

}

$months=array("January","February","March","April","May","June","July","August","September","October","November","December");



if ($mm!="") {

	$dt=$months[$mm-1];

	

	if ($dd!="" && $yyyy!="")

		$dt.="&nbsp;$dd,&nbsp;$yyyy";

}



if ($mode=="return")

	return $dt;

elseif ($mode=="print")

	print $dt;



}

/*---------------------------------------------------------------*/

function sim_wp_permissions_check() {

	global $sim_wp_vars;

	if (!empty($_POST['sim_wp_folder_permission'])) {

		@array_map("chmod", $_POST['sim_wp_folder_permission'], array_fill(0, count($_POST['sim_wp_folder_permission']), 0755) );

	}

	if (!empty($_POST['sim_wp_file_permission'])) {

		@array_map("chmod", $_POST['sim_wp_file_permission'], array_fill(0, count($_POST['sim_wp_file_permission']), 0644) );

	}

	$f_to_check = array(sim_WP_UPLOADS_PATH);

	foreach ($f_to_check as $slf) {

		$dir_iterator = new RecursiveDirectoryIterator($slf);

		$iterator = new RecursiveIteratorIterator($dir_iterator, RecursiveIteratorIterator::SELF_FIRST);

		$files = new RegexIterator($iterator, "/\.(php|gif|jpe?g|png|css|js|csv|xml|json|txt)/");

	}

	clearstatcache();

	$needs=0;

	

	foreach($iterator as $value) {

		if (is_dir($value) && 0755 !== (fileperms($value) & 0777)) {

			$needs_update["folder"][] = "$value - <b>".decoct(fileperms($value) & 0777)."</b>";

			$needs++;

		}

	}

	foreach($files as $value) {

		if (!is_dir($value) && 0644 !== (fileperms($value) & 0777)) {

			$needs_update["file"][] = "$value - <b>".decoct(fileperms($value) & 0777)."</b>";

			$needs++;

		}

	}

	$button_note = __("Note: Clicking this button should update permissions, however, if it doesn\'t, you may need to update permissions by using an FTP program.  Click &quot;OK&quot; or &quot;Confirm&quot; to continue ...", sim_WP_TEXT_DOMAIN);
	if ($needs > 0){

		$output = "";

		print "<br><div class='sim-wp-menu-alert' style='display:none;'><b>".__("Important Note", sim_WP_TEXT_DOMAIN).":</b><br>".__("Some of your folders / files may need updating to the proper permissions (folders: 755 / files: 644), otherwise, all functionality may not work as intended.  View folders / files below", sim_WP_TEXT_DOMAIN)." - <a href='#' onclick='show(\"file_perm_table\"); return false;'>".__("display / hide list of folders & files", sim_WP_TEXT_DOMAIN)."</a>:<br>";

		print "<div style='float:right'>(<a href='".$_SERVER['REQUEST_URI']."&file_perm_msg=1'>".__("Hide This Notice Permanently", sim_WP_TEXT_DOMAIN)."</a>)</div><br><br><table cellpadding='7px' id='file_perm_table' style='display:none;'><tr>";
	}

	if (!empty($needs_update["folder"])) {

		$output .= "<td style='vertical-align: top; width:50%'><form method='post'  onsubmit=\"return confirm('".$button_note."');\"><strong>".__("Folders", sim_WP_TEXT_DOMAIN).":</strong><br><input type='submit' class='button-primary' value=\"".__("Update Checked Folders' Permissions", sim_WP_TEXT_DOMAIN)."\"><br><br>";

		foreach ($needs_update["folder"] as $value) {

			$output .= "\n<input name='sim_wp_folder_permission[]' checked='checked' type='checkbox' value='".substr($value, 0, -13)."'>&nbsp;/".str_replace(ABSPATH, '', $value)."<br>"; // "-13", removes 13 chars: " - <b> 777 </b>" at end of value

		}

		$output .= "</form></td>";	

	}

	if (!empty($needs_update["file"])) {

		$output .= "<td style='vertical-align: top; style: 50%;'><form method='post' onsubmit=\"return confirm('".$button_note."');\"><strong>".__("Files", sim_WP_TEXT_DOMAIN).":</strong><br><input type='submit' class='button-primary' value=\"".__("Update Checked Files' Permissions", sim_WP_TEXT_DOMAIN)."\"><br><br>";

		foreach ($needs_update["file"] as $value) {

			$output .= "\n<input name='sim_wp_file_permission[]' checked='checked' type='checkbox' value='".substr($value, 0, -13)."'>&nbsp;/".str_replace(ABSPATH, '', $value)."<br>";

		}

		$output .= "</form></td>";	

	}

	if ($needs > 0){

		

		print $output."</tr></table></div>";

		$sim_wp_vars['perms_need_update'] = 1;

	}

	

	if ($needs == 0) {

		$sim_wp_vars['perms_need_update'] = 0;

	}

	

}

/*---------------------------------------------------------------*/

function sim_wp_remote_data($val_arr, $decode_mode = 'json') {

	$pagetype = (!empty($val_arr['pagetype']))? $val_arr['pagetype'] : "none" ;

	$dir = (!empty($val_arr['dir']))? $val_arr['dir'] : "none" ;

	$key = (!empty($val_arr['key']))? "__".$val_arr['key'] : "" ;

	$start = (!empty($val_arr['start']))? $val_arr['start'] : 0 ;

	$val_host = (!empty($val_arr['host']))? $val_arr['host'] : 'superstorefinder.net' ;

	$val_url = (!empty($val_arr['url']))? $val_arr['url'] : "/show-data/". $pagetype ."/". $dir ."$key" ."/". $start ;

	$useragent = (!empty($val_arr['ua']))? $val_arr['ua'] : "Super Interactive Maps Wordpress Plugin" ;

	

	$target = "http://" . $val_host . $val_url;

  	

	$remote_access_fail = false;

	if (extension_loaded("curl") && function_exists("curl_init")) {

    			ob_start();

    			$ch = curl_init();

    			if (!empty($useragent) && $useragent != 'none'){ curl_setopt($ch, CURLOPT_USERAGENT, $useragent); }

    			curl_setopt($ch, CURLOPT_URL,$target);

    			curl_exec($ch);

		    	$returned_value = ob_get_contents();

			

   			ob_end_clean();

		} else {

	  		$request = '';

	  		$http_request  = "GET ". $val_url ." HTTP/1.0\r\n";

			$http_request .= "Host: ".$val_host."\r\n";

			$http_request .= "Content-Type: application/x-www-form-urlencoded; charset=" . sim_WP_BLOG_CHARSET . "\r\n";

			$http_request .= "Content-Length: " . strlen($request) . "\r\n";

			if (!empty($useragent) && $useragent != 'none'){ $http_request .= "User-Agent: $useragent\r\n"; }

			$http_request .= "\r\n";

			$http_request .= $request;

			$response = '';

			if (false != ( $fs = @fsockopen($val_host, 80, $errno, $errstr, 10) ) ) {

				fwrite($fs, $http_request);

				while ( !feof($fs) )

					$response .= fgets($fs, 1160); 

				fclose($fs);

			}

			$returned_value = trim($response);

	}

	

	if (!empty($returned_value)) {

		$the_data = ($decode_mode != "serial")? json_decode($returned_value, true) : $returned_value;

		return $the_data;

	} else {

		return false;

	}

}

/*-----------------------------------------------*/

/// Loading SL Variables ///
global $wpdb;
if(defined('sim_WP_SETTING_TABLE') && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", sim_WP_SETTING_TABLE)) == sim_WP_SETTING_TABLE)
{
$sim_wp_vars=sim_wp_data('sim_wp_vars');

if (!is_array($sim_wp_vars)) {

	function sim_wp_fix_corrupted_serialized_string($string) {

		$tmp = explode(':"', $string);

		$length = count($tmp);

		for($i = 1; $i < $length; $i++) {    

			list($string) = explode('"', $tmp[$i]);

        		$str_length = strlen($string);    

        		$tmp2 = explode(':', $tmp[$i-1]);

        		$last = count($tmp2) - 1;    

        		$tmp2[$last] = $str_length;         

        		$tmp[$i-1] = join(':', $tmp2);

    		}

    		return join(':"', $tmp);

	}

	$sim_wp_vars = sim_wp_fix_corrupted_serialized_string($sim_wp_vars); 

	sim_wp_data('sim_wp_vars', 'update', $sim_wp_vars);

	$sim_wp_vars = unserialize($sim_wp_vars); 

	}

}

if (defined('sim_WP_ADDONS_PLATFORM_FILE') && file_exists(sim_WP_ADDONS_PLATFORM_FILE)) {

	sim_wp_initialize_variables(); 

	include_once(sim_WP_ADDONS_PLATFORM_FILE);

}

/*-------------------------------*/
if (!function_exists("sim_wp_template")){
	
   function sim_wp_template($content) {
	global $sim_wp_dir, $sim_wp_base, $sim_wp_uploads_base, $sim_wp_path, $sim_wp_uploads_path, $text_domain, $wpdb, $sim_wp_vars;
    global $superintermap_array;
	global $superinteractivemap;
	
	if(! preg_match('|\[super-interactive-map|i', $content)) {

		return $content;

	}

	else {

		//End WPML
		/***.*** front end code multiple and single ***.***/
		$start='[SUPER-INTERACTIVE-MAP ID=';
		$end=']';
		$string = $content;
		$i=0;
		$rplc='';
		$sim_post_id='';
		 $superinteractivemap ="";
		preg_match_all('~\[SUPER-INTERACTIVE-MAP ID=(.*?)\]~', $string, $matches);
		if(!empty($matches[1])){
		foreach($matches[1] as $key => $val){   
         

		$query=$wpdb->get_results("SELECT *  FROM ".sim_WP_TABLE." WHERE sim_wp_id=".$val."", ARRAY_A);
		foreach ($query as $row) {
			$mapDataQuery=$wpdb->get_results("SELECT *  FROM ".sim_WP_TABLE_DATA." WHERE sim_wpd_data_id=".$row['sim_wp_id']." ", ARRAY_A);
			$mapLocationDta='';
	
		foreach ($mapDataQuery as $record) {
			$record['sim_wpd_information']=str_replace('\"','"',$record['sim_wpd_information']); 
			$record['sim_wpd_description']=str_replace('\"','"',$record['sim_wpd_description']);
	        $mapdata=$record['sim_wpd_id'].'::'.$record['sim_wpd_title'].'::'.$record['sim_wpd_locations'].'::'.$record['sim_wpd_data_color'].'::'.$record['sim_wpd_search_id'].'::'.$record['sim_wpd_url'].'::'.$record['sim_wpd_information'].'::'.$record['sim_wpd_description'].'::'.$record['sim_wpd_boxsearch'].'::'.$record['sim_wpd_call_to_action'];
			$mapLocationDta .= $mapdata.'@;@';
		}
	$height=$row['sim_wp_height'];
	$width=$row['sim_wp_width'];
	if($row['sim_wp_use_default']=='true'){ $height=''; $width='';  }
		$new_iwm_array = array(
   						 "apiversion" => 1,
   						 "content" => $row['sim_wp_locations'],
   						 "id" => $val,
   						 "colorsmap"=>$row['sim_wp_border_color'],
						 "sim_bg_color"=>$row['sim_wp_bg_color'],
						 "display"=>$row['sim_wp_map_region'],
						 "markersize"=>$row['sim_wp_marker_size'],
						 "sim_wp_height"=>$height,
						 "sim_wp_width"=>$width,
						 "placestxt"=>$mapLocationDta,
						 "hideTitle"=>$row['sim_wp_hide_title'],
						 "sim_wp_aspect_ratio"=>$row['sim_wp_aspect_ratio'],
						 "map_zoom"=>$row['sim_wp_zoom_setting'],
						);
							
	array_push($superintermap_array, $new_iwm_array);
	$superinterac="<div class='sim-main-content ' role='main' id='mainContent'>
						<div id='super-inter-active-map-block'>
							<div class='sim_maps_blcok' >
                                 <div id='sim_interactive_map$val' class='sim_map_area'></div>
							</div>
						</div>
					</div>";

	if($row['sim_wp_map_region']=='text'){
	$superinterac.="<style>
		#sim_interactive_map$val text {
		  font-family: FontAwesome;
		}</style>";
		//set margin left
	}
	$styles='';
	if(isset($row['sim_wp_left']) && $row['sim_wp_left'] != '') {
		$styles .= "\n#sim_interactive_map".$val." { margin-left: ".$row['sim_wp_left']."%; }";
	}

	//set margin top
	if(isset($row['sim_wp_top']) && $row['sim_wp_top'] != '') {
		$styles .= "\n#sim_interactive_map".$val." { margin-top: ".$row['sim_wp_top']."%; }";
	}

	//set size %
	if(isset($row['sim_wp_zoom']) && $row['sim_wp_zoom'] != '' && $row['sim_wp_zoom'] != '100') {
		$styles .= "\n#sim_interactive_map".$val." { width: ".$row['sim_wp_zoom']."%; height: ".$row['sim_wp_zoom']."%; }";
	}
	//set vertical override size
	if(isset($row['sim_wp_map_height']) && $row['sim_wp_map_height'] !='' && $row['sim_wp_map_height'] != '61.7') {
		$overrideh = true;
		$styles .= '#sim_interactive_map'.$val.':after { padding-top:'.$row['sim_wp_map_height'].'%; }';
	}
	if(isset($row['sim_wp_map_hover']) && $row['sim_wp_map_hover'] != ''){
		
	 $styles .= '#sim_interactive_map'.$val.' path:hover { fill: '.$row['sim_wp_map_hover'].' !important;}';

	}
	$superinterac.="<style>$styles</style>";
	$rplc='[SUPER-INTERACTIVE-MAP ID='.$val.']';
	
	}
	
	$SimBorderColor=(trim($sim_wp_vars['sim_border_color'])!="")? simParseToXML($sim_wp_vars['sim_border_color']) : "";
	$SimBorderHover=(trim($sim_wp_vars['sim_border_hover'])!="")? simParseToXML($sim_wp_vars['sim_border_hover']) : "false";
	$SimBorderPixel=(trim($sim_wp_vars['sim_border_pixel'])!="")? simParseToXML($sim_wp_vars['sim_border_pixel']) : "1px";
	$SimHoverPixel=(trim($sim_wp_vars['sim_hover_pixel'])!="")? simParseToXML($sim_wp_vars['sim_hover_pixel']) : "1px";
	$SimHoverColor=(trim($sim_wp_vars['sim_hover_color'])!="")? simParseToXML($sim_wp_vars['sim_hover_color']) : "";
	if($SimBorderColor!=''){
		$styles= '.sim_maps_blcok path{
			stroke:'.$SimBorderColor.';
			stroke-width: '.$SimBorderPixel.';
		}';
	}else{
		  $styles= '#super-inter-active-map-block path{ stroke-width: '.$SimBorderPixel.'}';
		
	}
	
	if($SimBorderHover=='true' && $SimHoverColor!=''){
		$styles .= '.sim_maps_blcok path:hover {
			stroke-width: '.$SimHoverPixel.' !important;
			stroke:'.$SimHoverColor.' !important;
		}';
	}else if($SimBorderHover=='true' && $SimHoverColor==''){
		$styles .= '#super-inter-active-map-block path:hover {
			stroke-width: '.$SimHoverPixel.' !important;
		}';
	}else{
		$styles .= '#super-inter-active-map-block path:hover {
			stroke-width: 1px !important;
		}';
	}
	$superinterac.="<style>$styles</style>";
	$content=str_replace($rplc,$superinterac,$content); 
}

 	
sim_wp_head_scripts($superintermap_array);
}
$superinteractivemap.=$content;
/***.*** end front end code multiple and single ***.***/
	return $superinteractivemap;
	}
  }
} ?>