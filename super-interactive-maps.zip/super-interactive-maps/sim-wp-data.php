<?php
include("sim-wp-inc/includes/sim-wp-env.php");
global $wpdb;

$query=$wpdb->get_results("SELECT *  FROM ".sim_WP_TABLE." WHERE sim_wp_id=".$_POST['id']."", ARRAY_A);
echo json_maps_data($query);
	
function json_maps_data($query) {
global $wpdb;
	$json = array();
	$json['mainData'] = array();
    $json['location']=array();
	foreach ($query as $row) {
	$mapDataQuery=$wpdb->get_results("SELECT *  FROM ".sim_WP_TABLE_DATA." WHERE sim_wpd_data_id=".$row['sim_wp_id']." ", ARRAY_A);
	$mapDataCount='';
	foreach ($mapDataQuery as $record) {
	$json['location'][] = array(
				'mapDataCount'=>$record['sim_wpd_id'],
				'ttitle'=>simParseToHXML($record['sim_wpd_title']),
				'location'=>simParseToHXML($record['sim_wpd_locations']),
				'dataColor'=>$record['sim_wpd_data_color'],
				'latLong'=>$record['sim_wpd_search_id'],
				'sim_url_val'=>$record['sim_wpd_url'],
				'sim_url_action'=>$record['sim_wpd_call_to_action'],
				'sim_information'=>simParseToHXML($record['sim_wpd_information']),
				'sim_wpd_description'=>simParseToHXML($record['sim_wpd_description']),
				'sim_wpd_boxsearch'=>$record['sim_wpd_boxsearch']
			);
	
	}
	
    $json['mainData'][] = array(
				'content'=>$row['sim_wp_locations'],
				'colorsmap'=>$row['sim_wp_border_color'],
				'sim_bg_color'=>$row['sim_wp_bg_color'],
				'display'=>$row['sim_wp_map_region']
				
			);
	}
return json_encode($json);
}
?>