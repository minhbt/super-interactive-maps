<?php


if (empty($_POST)) {sim_wp_move_upload_directories();}
if (empty($_GET['pg'])) {
	include(sim_WP_PAGES_PATH."/manage-maps.php");
} else {
	$the_page = sim_WP_PAGES_PATH."/".$_GET['pg'].".php";
	if (file_exists($the_page)) {
		include($the_page);
	}
}


?>