<?php
include("../../sim-wp-inc/includes/sim-wp-env.php");
if(isset($_POST['img']))
{
	 $dir=sim_WP_UPLOADS_PATH."/images/icons/";
	 if($_POST['img']=='a')
	 {
		unlink($dir.'custom-marker.png');
	 }
	 else if($_POST['img']=='b')
	 {
		unlink($dir.'custom-marker-active.png'); 
	 }
}

 if(isset($_POST['img_mrk']))
 {
   $dir=sim_WP_UPLOADS_PATH.'/images/icons/'.$_POST['img_mrk'];
			if (is_dir($dir)){ 
			$it = new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS);
			$files = new RecursiveIteratorIterator($it,
			RecursiveIteratorIterator::CHILD_FIRST);
			foreach($files as $file) {
			if ($file->isDir()){
			rmdir($file->getRealPath());
			} else {
			unlink($file->getRealPath());
			}
			}
			rmdir($dir);
			}
 
 }
 else
 {   
    $dir=sim_WP_UPLOADS_PATH.'/images/'.$_POST['img'];
			if (is_dir($dir)){ 
			$it = new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS);
			$files = new RecursiveIteratorIterator($it,
			RecursiveIteratorIterator::CHILD_FIRST);
			foreach($files as $file) {
			if ($file->isDir()){
			rmdir($file->getRealPath());
			} else {
			unlink($file->getRealPath());
			}
			}
			rmdir($dir);
			}
 }
?>
