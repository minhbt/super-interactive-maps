<?php
include_once(sim_WP_INCLUDES_PATH."/top-nav.php");
?>
<div class='wrap'>
<?php

if (!empty($_GET['edit'])){ print "<style>#wpadminbar {display:none !important;}</style>"; }

$hidden="";
foreach($_GET as $key=>$val) {
	
	if ($key!="q" && $key!="o" && $key!="d" && $key!="changeView" && $key!="start") {
		$hidden.="<input type='hidden' value='$val' name='$key'>\n"; 
	}
}

include(sim_WP_ACTIONS_PATH."/process-maps.php");

print "<table style='width:100%'><tr><td>";
print "<div class='mng_loc_forms_links'>";

if (empty($_GET['q'])){ $_GET['q']=""; }
$search_value = ($_GET['q']==="")? "" : sim_comma(stripslashes($_GET['q'])) ;

print "<div><form name='searchForm'><!--input type='button' class='button-primary' value='Add New' onclick=\"\$aLD=jQuery('#addLocationsDiv');if(\$aLD.css('display')!='block'){\$aLD.fadeIn();}else{\$aLD.fadeOut();}return false;\">&nbsp;&nbsp;--><input value='".$search_value."' name='q' type='text' placeholder='Search'>$hidden</form></div>";

print "<div>
<nobr><select name='sim_wp_admin_locations_per_page' onchange=\"LF=document.forms['locationForm'];salpp=document.createElement('input');salpp.type='hidden';salpp.value=this.value;salpp.name='sim_wp_admin_locations_per_page';LF.appendChild(salpp);LF.act.value='locationsPerPage';LF.submit();\">
<optgroup label='# ".__("Locations", sim_WP_TEXT_DOMAIN)."'>";

$opt_arr=array(10,25,50,100,200,300,400,500,1000,2000,4000,5000,10000);
foreach ($opt_arr as $value) {
	$selected=($sim_wp_admin_locations_per_page==$value)? " selected " : "";
	print "<option value='$value' $selected>$value</option>";
}
print "</optgroup></select>
</nobr>
</div>";

if (!empty($_GET['_wpnonce'])){ $_SERVER['REQUEST_URI'] = str_replace("&_wpnonce=".$_GET['_wpnonce'], "", $_SERVER['REQUEST_URI']);}

$is_normal_view = ($sim_wp_vars['location_table_view']=="Normal");

function regeocoding_link(){
	global $wpdb, $where, $master_check, $sim_wp_uploads_path, $web_domain, $extra, $sim_wp_base, $sim_wp_uploads_base, $text_domain;
	if (file_exists(sim_WP_ADDONS_PATH."/csv-xml-importer-exporter/re-geo-link.php")) {
		include(sim_WP_ADDONS_PATH."/csv-xml-importer-exporter/re-geo-link.php");	
	}
}
if (function_exists("addto_sim_wp_hook")) {addto_sim_wp_hook('sim_wp_mgmt_bar_links', 'regeocoding_link', '', '', 'csv-xml-importer-exporter');} 
else {regeocoding_link();}

if (file_exists(sim_WP_ADDONS_PATH."/multiple-field-updater/multiLocationUpdate.php") && !function_exists("do_sim_wp_hook")) {
	print "<div> | ".$updater_type."</div>";
}

print "</div>";
print "</td><td>";


sim_wp_sim_set_query_defaults();

if(file_exists(sim_WP_ADDONS_PATH."/csv-xml-importer-exporter/re-geo-query.php")){
	include(sim_WP_ADDONS_PATH."/csv-xml-importer-exporter/re-geo-query.php");
}


	$numMembers=$wpdb->get_results("SELECT sim_wp_id FROM ".sim_WP_TABLE." $where");
	$numMembers2=count($numMembers); 
	$start=(empty($_GET['start']))? 0 : $_GET['start'];
	$num_per_page=$sim_wp_vars['admin_locations_per_page']; //edit this to determine how many locations to view per page of 'Manage Locations' page
	if ($numMembers2!=0) {include(sim_WP_INCLUDES_PATH."/search-links.php");}


print "</td></tr></table>";

print "<form name='locationForm' method='post' enctype='multipart/form-data'>";

if(empty($_GET['d'])) {$_GET['d']="";} if(empty($_GET['o'])) {$_GET['o']="";}


$master_check = (!empty($master_check))? $master_check : "" ;
include(sim_WP_INCLUDES_PATH."/maps-management.php");
print "<table class='widefat' cellspacing=0 id='loc_table'>
<thead><tr >
<th colspan='1'><input type='checkbox' onclick='checkAll(this,document.forms[\"locationForm\"])' id='master_checkbox' $master_check></th>

<th><a href='".str_replace("&o=$_GET[o]&d=$_GET[d]", "", $_SERVER['REQUEST_URI'])."&o=sim_wp_id&d=$d'>".__("ID", sim_WP_TEXT_DOMAIN)."</a></th>";

if (function_exists("do_sim_wp_hook") && !empty($sim_wp_columns)){
	do_sim_wp_location_table_header();
} else {
	
	$th_co = ($is_normal_view)? "</th>\n<th>" : ", " ;
	$th_style = ($is_normal_view)? "" : "style='white-space: nowrap;' " ;
	
	print "<th {$th_style}><a href='".str_replace("&o=$_GET[o]&d=$_GET[d]", "", $_SERVER['REQUEST_URI'])."&o=sim_wp_name&d=$d'>".__("Name", sim_WP_TEXT_DOMAIN)."</a>{$th_co}
<a href='".str_replace("&o=$_GET[o]&d=$_GET[d]", "", $_SERVER['REQUEST_URI'])."&o=sim_wp_description&d=$d'>".__("Description", sim_WP_TEXT_DOMAIN)."</a>{$th_co}
<a href='".str_replace("&o=$_GET[o]&d=$_GET[d]", "", $_SERVER['REQUEST_URI'])."&o=sim_wp_map_region&d=$d'>".__("Map Region", sim_WP_TEXT_DOMAIN)."</a>{$th_co}
<a href='".str_replace("&o=$_GET[o]&d=$_GET[d]", "", $_SERVER['REQUEST_URI'])."&o=sim_wp_display_mode&d=$d'>".__("Display Style", sim_WP_TEXT_DOMAIN)."</a></th>
<th>".__("Short code", sim_WP_TEXT_DOMAIN)."</th>
<th style='padding-left:100px;'>
".__("Map", sim_WP_TEXT_DOMAIN)."</th>
";

}

print "<th colspan='1'>".__("Actions", sim_WP_TEXT_DOMAIN)."</th>
</tr></thead>";

	$o=esc_sql($o); $d=esc_sql($d); 
	$start=esc_sql($start); $num_per_page=esc_sql($num_per_page); 
	if ($locales=$wpdb->get_results("SELECT * FROM ".sim_WP_TABLE." $where ORDER BY $o $d LIMIT $start, $num_per_page", ARRAY_A)) { 
		if (function_exists("do_sim_wp_hook") && !empty($sim_wp_columns)){
			
			$colspan=($sim_wp_vars['location_table_view']!="Normal")? 	(count($sim_wp_columns)-count($sim_wp_omitted_columns)+4) : (count($sim_wp_normal_columns)-3+4);
		} else {
			$colspan=($sim_wp_vars['location_table_view']!="Normal")? 	18 : 11;
		}
		
		$bgcol="";
		
		foreach ($locales as $value) {
			$bgcol=($bgcol==="" || $bgcol=="#eee")?"#fff":"#eee";				
			$value=array_map("trim",$value);
			
			if (!empty($_GET['edit']) && $value['sim_wp_id']==$_GET['edit']) {
				sim_wp_single_location_info($value, $colspan, $bgcol);
			}
			else {

			
				if(empty($_GET['edit'])) {$_GET['edit']="";}
				$edit_link = str_replace("&edit=$_GET[edit]", "",$_SERVER['REQUEST_URI'])."&edit=" . $value['sim_wp_id'] ."#a$value[sim_wp_id]'";
				
				print "<tr style='background-color:$bgcol' id='sim_wp_tr-$value[sim_wp_id]'>
			<th><input type='checkbox' name='sim_wp_id[]' value='$value[sim_wp_id]'></th>
			
			<td> $value[sim_wp_id] </td>";

				if (function_exists("do_sim_wp_hook") && !empty($sim_wp_columns)){
					do_sim_wp_location_table_body($value);
				} else {

// print "<td> $value[sim_wp_name]
// $value[sim_wp_address]
// $value[sim_wp_address2]
// $value[sim_wp_city]
// $value[sim_wp_state]
// $value[sim_wp_zip]</td>
// <td>$value[sim_wp_tags]</td>";
 if(isset($value['sim_wp_image']) && $value['sim_wp_image']!='') { $image= "<div style='background-image:url(".$value['sim_wp_image']."); background-size:cover; background-position:center center; height:60px; max-width:110px;'></div>"; } else { $image= ''; }

 //background-image: url(http://superstorefinder.net/products/superlogoshowcasewp/stg/wp-content/plugins/superstorefinder-wp/images/NoImage.png);
 // if ($sim_wp_vars['location_table_view']!="Normal") {
	print "<td>$value[sim_wp_name]</td>
<td>$value[sim_wp_description]</td>
<td>$value[sim_wp_map_region]</td>
<td>$value[sim_wp_locations]</td>
<td>[SUPER-INTERACTIVE-MAP  ID=".$value['sim_wp_id']."]</td>
<td>$image</td>";

					// }
				}print "<td><a class='del_loc_link' href='".wp_nonce_url("$_SERVER[REQUEST_URI]&copy=$value[sim_wp_id]", "copy-location_".$value['sim_wp_id'])."' onclick=\"confirmClick('Are you sure you wish to copy this map?', this.href); return false;\" id='$value[sim_wp_id]'><span class='fa fa-copy'>&nbsp;</span>".__("Copy", sim_WP_TEXT_DOMAIN)."</a>&nbsp;| <a class='edit_loc_link' href='".$edit_link." id='$value[sim_wp_id]'><span class='fa fa-pencil'>&nbsp;</span>".__("Edit", sim_WP_TEXT_DOMAIN)."</a>&nbsp;| <a class='del_loc_link' href='".wp_nonce_url("$_SERVER[REQUEST_URI]&delete=$value[sim_wp_id]", "delete-location_".$value['sim_wp_id'])."' onclick=\"confirmClick('Are you sure you wish to delete this store?', this.href); return false;\" id='$value[sim_wp_id]'><span class='fa fa-trash'>&nbsp;</span>".__("Delete", sim_WP_TEXT_DOMAIN)."</a></td>
				</tr>";
			}
		}
	} else {
		$cleared=(!empty($_GET['q']))? str_replace("q=".str_replace(" ", "+", $_GET['q']) , "", $_SERVER['REQUEST_URI']) : $_SERVER['REQUEST_URI'] ;
		$notice=(!empty($_GET['q']))? __("No Locations Showing for this Search of ", sim_WP_TEXT_DOMAIN)."<b>\"$_GET[q]\"</b> | <a href='$cleared'>".__("Clear&nbsp;Results", sim_WP_TEXT_DOMAIN)."</a> $sim_view_link" : __("You have no available maps", sim_WP_TEXT_DOMAIN);
		print "<tr><td colspan='5'>$notice | <a href='".sim_WP_ADD_LOCATIONS_PAGE."'>".__("Add a Maps", sim_WP_TEXT_DOMAIN)."</a></td></tr>";
	}
	print "</table>
	<input name='act' type='hidden'><br>";
	wp_nonce_field("manage-locations_bulk");

if ($numMembers2!=0) {include(sim_WP_INCLUDES_PATH."/search-links.php");}

print "</form>"; 
?>
</div>
<?php include(sim_WP_INCLUDES_PATH."/sim-wp-footer.php"); ?>