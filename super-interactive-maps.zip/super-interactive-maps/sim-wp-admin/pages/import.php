<?php
include_once(sim_WP_INCLUDES_PATH."/top-nav.php");

if (!function_exists("sim_wp_initialize_variables")) { include("../sim-wp-functions.php"); }
?>
<div class='wrap'>
<?php 

    /*if(isset($_POST["export"])){
	
	   echo "asdas";
	
	}*/
    $msg="";
    if(isset($_FILES["default_location"]["name"])){
	
	    $extension= explode(".", $_FILES['default_location']['name']);
         // isset Determines if a variable is set and is not NULL. Set Size Limit less then 10 MB=10485760 bytes. Extension must be CSV.
		if (isset($_FILES['default_location']) && $_FILES['default_location']['size'] < 10485760 && $extension[1]== 'csv')
		{
            $dest="../".$_FILES["default_location"]["name"];
			if(move_uploaded_file($_FILES["default_location"]["tmp_name"],$dest)){
			
			   $msg=csvSave($dest,$wpdb);
			   print "<div class='sim_wp_admin_success'>".__(" $msg",sim_WP_TEXT_DOMAIN).". $view_link</div> <!--meta http-equiv='refresh' content='0'-->"; 
			   unlink($dest);
				
			}else{
			 
			 
			  print "<div class='sim-wp-menu-alert'>".__(" CSV Upload failed to the database.",sim_WP_TEXT_DOMAIN).". $view_link</div>"; 
			   
			}
		}else{
		
		     
			 print "<div class='sim-wp-menu-alert'>".__(" Error in File.",sim_WP_TEXT_DOMAIN).". $view_link</div>"; 
			 
		}
 
    }
	
if (empty($_POST)) {sim_wp_move_upload_directories();}
if (!empty($_POST['sim_wp_map_settings'])) { 
    
    function sim_wp_md_save($data) {
	global $sim_wp_vars;
	

	
	$sim_wp_vars['sensor']=(empty($_POST['sim_wp_geolocate']))? "false" : "true";
	

	foreach ($data as $value) {
	    
	    if (!empty($value['field_name'])) {
		$fname = $value['field_name'];
	
		if (!empty($value['field_type']) && $value['field_type'] == "checkbox") {
			
			if (is_array($fname)) {
				foreach ($fname as $the_field) {
					$sim_wp_vars[$the_field] = (empty($_POST["sim_wp_".$the_field]))? 0 : $_POST["sim_wp_".$the_field] ;
				}
			} else {
				$sim_wp_vars[$fname] = (empty($_POST["sim_wp_".$fname]))? 0 : $_POST["sim_wp_".$fname] ;
			}
		} else {
			if (is_array($fname)) {
				$fctr = 0;
				foreach ($fname as $the_field) {
					$post_data = (isset($_POST["sim_wp_".$the_field]))? $_POST["sim_wp_".$the_field] : $_POST[$the_field] ;
					$post_data = (!empty($value['stripslashes'][$fctr]) && $value['stripslashes'][$fctr] == 1)? stripslashes($post_data) : $post_data;
					$post_data = (!empty($value['numbers_only'][$fctr]) && $value['numbers_only'][$fctr] == 1)? preg_replace("@[^0-9]@", "", $post_data) : $post_data;
					$sim_wp_vars[$the_field] = $post_data;
					$fctr++;
				}
			} else {
				$post_data = (isset($_POST["sim_wp_".$fname]))? $_POST["sim_wp_".$fname] : $_POST[$fname] ;
				$post_data = (!empty($value['stripslashes']) && $value['stripslashes'] == 1)? stripslashes($post_data) : $post_data;
				$post_data = (!empty($value['numbers_only']) && $value['numbers_only'] == 1)? preg_replace("@[^0-9]@", "", $post_data) : $post_data;
				$sim_wp_vars[$fname] = $post_data;
			}
		}
	    }
	    
	}

	sim_wp_data('sim_wp_vars', 'update', $sim_wp_vars);
	
    }
    
  sim_wp_initialize_variables();
    include(sim_WP_INCLUDES_PATH."/export.php");
    sim_wp_md_save($sim_wp_mdo);
    unset($sim_wp_mdo);  
 
 sim_wp_initialize_variables(); 
 
	print "<div class='sim_wp_admin_success' >".__(" Settings succesimully saved.", sim_WP_TEXT_DOMAIN)." $view_link</div> <!--meta http-equiv='refresh' content='0'-->";
}




$update_button="<input type='button'  onclick='document.location.href=\"".sim_WP_BASE."/csv/sample-data.csv\"' value='".__("Download Sample CSV", sim_WP_TEXT_DOMAIN)."' class='button-primary'> <input type='submit'  value='".__("Import & Geo Code", sim_WP_TEXT_DOMAIN)."' class='button-primary'>";

print "
<div class='input_section'>
	<form method='post' name='settings' enctype='multipart/form-data'>
	
					<div class='input_title'>
						
						<h3><span class='fa fa-globe'>&nbsp;</span> Import</h3>
						<span class='submit'>
						$update_button
						</span>
						<div class='clearfix'></div>
					</div>
					<div class='all_options'>
";

function sim_wp_md_display($data, $input_zone, $template, $additional_classes = "") {
    $GLOBALS['input_zone_type'] = $input_zone;
    $filtered_data = array_filter($data, "filter_sim_wp_mdo");
    unset($GLOBALS['input_zone_type']);
	$showregion=0;
    
    $labels_ctr = 0;
    foreach ($filtered_data as $key => $value) {
     
    	if ($template == 1) {
		
		$the_row_id = (!empty($value["row_id"]))? " id = '$value[row_id]' " : "";
		$hide_row = (!empty($value['hide_row']) && $value['hide_row'] == true)? "style='display:none' " : "" ;
		$colspan = (!empty($value['colspan']) && $value['colspan'] > 1)? "colspan = '$value[colspan]'" : "" ;
		
		print "<div class='option_input option_text'>
					<label for='shortname_logo'>".$value['label'];
		if (!empty($value['more_info_label'])) {
			print "&nbsp;(<a href='#$value[more_info_label]' rel='sim_wp_pop'>?</a>)&nbsp;";
		}
		print "</label>";
	   if (empty($value['colspan']) || $value['colspan'] < 2) {
		print "".$value['input_template']."<div class='clearfix'></div></div>";

	    }
	   
		
    	} elseif ($template == 2) {
		
		
		if ($labels_ctr % 3 == 0) {
			$the_row_id = (!empty($value["row_id"]))? " id = '$value[row_id]' " : "";
			
		}	
		
		if($value['label']=="Search bar caption"){
		print "<div class='input_title'>
						
						<h3><span class='fa fa-bookmark'>&nbsp;</span> Labels</h3>
						
						<div class='clearfix'></div>
					</div>";
		}
		
		
		if($value['label']=="Loading Google Maps..."){
		print "<div class='input_title'>
						
						<h3><span class='fa fa-exclamation-circle'>&nbsp;</span> Notification</h3>
						
						<div class='clearfix'></div>
					</div>";
		}
		
		
		if($value['label']=="We have encountered an error."){
		  $showregion=1;
		}
		
		
		
		
		print "<div class='option_input option_text'>";
		print "<label for='shortname_logo'>".$value['label']."</label>".$value['input_template']."<small></small><div class='clearfix'></div></div>";
	
if($showregion==1){
$showregion=0;
		print "<div class='input_title'>
						
						<h3><span class='fa fa-map-marker'>&nbsp;</span> Regions</h3>
						
						<div class='clearfix'></div>
					</div>";
		}

	//}
    	}
    	
      //}
    	
    }
    
    print "</div>";
}

include(sim_WP_INCLUDES_PATH."/export.php");


sim_wp_md_display($sim_wp_mdo, 'defaults', 1);

if (function_exists('icl_register_string')) {
    
	$GLOBALS['input_zone_type'] = "labels";
	$labels_arr = array_filter($sim_wp_mdo, "filter_sim_wp_mdo");
	unset($GLOBALS['input_zone_type']);
	
	
	foreach ($labels_arr as $value) {
		$the_field = $value['field_name'];
		$varname = "sim_wp_".$the_field;
		
		icl_register_string(sim_WP_DIR, $value['label'], $sim_wp_vars[$the_field]);
	}
	
	
	icl_register_string(sim_WP_DIR, 'Search Button Filename', "search_button.png");
	icl_register_string(sim_WP_DIR, 'Search Button Filename (Down State)', "search_button_down.png");
	icl_register_string(sim_WP_DIR, 'Search Button Filename (Over State)', "search_button_over.png");
}

print "</form>";
print "<form method=\"post\">";
print "<input type=\"hidden\" name='export' value=\"export\">
				<div class='input_title'>
					<label for=\"shortname_logo\"><h3><span class='fa fa-sign-out'>&nbsp;</span> Export</h3></label>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"button\" onclick=\"exportmaps();\" class=\"button-primary\" value=\"Export maps\" style=\"float:right; margin-right:20px;\">
			     <div class=\"clearfix\"></div>
				</div>
				</div>";
//sim_wp_md_display($sim_wp_mdo, 'labels', 2, "right_side");

print "</form>";

   
?>

</div>
<?php include(sim_WP_INCLUDES_PATH."/sim-wp-footer.php"); ?>
<?php
function csvSave($file,$wpdb){
   
			    //$handle is a valid file pointer to a file succesimully opened by fopen(), popen(), or fsockopen(). fopen() used to open file.
                 $handle = fopen($file, "r"); 
   $import=array();
   if ($handle !== FALSE) 
				{
		
	// fgets() Gets a line from file pointer and read the first line from $handle and ignore it.   
					fgets($handle);
	// While loop used here and  fgetcsv() parses the line it reads for fields in CSV format and returns an array containing the fields read.
					ini_set('auto_detect_line_endings',TRUE);
					
					while (($data = fgetcsv($handle)) !== FALSE)
					{
					
					$address= str_replace('\'', '\\\'',$data[2]);
					$address.= ", ".str_replace('\'', '\\\'',$data[3]);
					$address .= ", ".str_replace('\'', '\\\'',$data[4]);
					$address.= ", ".str_replace('\'', '\\\'',$data[5]);
					$address.= ", ".str_replace('\'', '\\\'',$data[6]);

					$arrayLatLong=geolocate($address);

					$qry="INSERT INTO ".sim_WP_TABLE."(`sim_wp_id`, `sim_wp_store`, `sim_wp_tags`,`sim_wp_address`,
   					 `sim_wp_city`, `sim_wp_state`, `sim_wp_country`, `sim_wp_zip`, 
					 `sim_wp_phone`, `sim_wp_fax`, `sim_wp_email`,`sim_wp_url`, 
					  `sim_wp_description`, `sim_wp_hours`,`sim_wp_image`,`sim_wp_latitude`, 
					  `sim_wp_longitude`)
					VALUES (null,%s,%s,%s,
					%s,%s,%s,%s,
					%s,%s,%s,%s,
					%s,%s,%s,%s,
					%s)";
					if (!empty($data[1])){
						$tag =sim_wp_prepare_tag_string($data[1]);
						$tag = preg_replace('/[ ,]+/', '&#44; ', $tag);
					}else{ $tag='';}
                   	
	$q = $wpdb->prepare($qry,$data[0],$tag,$data[2],$data[3],$data[4],$data[5],$data[6],$data[7],$data[8]
	                                ,$data[9],$data[10],$data[11],$data[12],$data[13],$arrayLatLong[0],$arrayLatLong[1]); 
	
	$wpdb->query($q);
		$new_store_id=$wpdb->insert_id;
		if (!empty($data[1])){
			sim_wp_process_tags($data[1], "insert", $new_store_id);
		}
	}
	fclose($handle);
}	

     return "Insert succesimully";
}

function geolocate($address)
	{
		$lat = 0;
		$lng = 0;
		
		$data_location = "http://maps.google.com/maps/api/geocode/json?address=".str_replace(" ", "+", $address)."&sensor=false";
		
		//if ($this->region!="" && strlen($this->region)==2) { $data_location .= "&region=".$this->region; }
		$data = file_get_contents($data_location);
		usleep(200000);
		
		// turn this on to see if we are being blocked
		// echo $data;
		
		$data = json_decode($data);
		
		if ($data->status=="OK") {
			$lat = $data->results[0]->geometry->location->lat;
			$lng = $data->results[0]->geometry->location->lng;
		}
		
		// concatenate lat/long coordinates
		 $lat= (string)$lat;
		 $lng = (string)$lng;
		
		return array($lat,$lng);
	}

?>
<script>
function exportmaps(){
		
		var url='<?php echo sim_WP_BASE;?>/sim-wp-admin/pages/exportAjax.php';
		window.location=url;

	}
</script>