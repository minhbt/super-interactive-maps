<?php
include_once(sim_WP_INCLUDES_PATH."/top-nav.php");
?>
<div class='wrap'>
<?php 
if (empty($_POST)) {sim_wp_move_upload_directories();}
if (!empty($_POST['style_bg_color'])) { 
    function sim_wp_md_save($data) {
	global $sim_wp_vars;
	  
	if(!isset($sim_wp_vars['map_settings']))
	{
    $sim_wp_vars['api_key']="";
	$sim_wp_vars['google_map_country']= "United States";
	$sim_wp_vars['map_region']="";
	$sim_wp_vars['map_language']= "en";
	$sim_wp_vars['map_character_encoding']="";
	$sim_wp_vars['start']=date("Y-m-d H:i:s");
	$sim_wp_vars['name']="Super Interactive Maps";
	$sim_wp_vars['admin_locations_per_page']="100";
	$sim_wp_vars['location_table_view']="Normal";
	}
    
	foreach ($data as $value) {
	    
	    if (!empty($value['field_name'])) {
		$fname = $value['field_name'];
		
		if($value['field_name']=='sim_user_role'){
		   if(!empty($_POST['sim_user_role'])){
		     array_push($_POST['sim_user_role'],"administrator");
			  $_POST['sim_user_role']=implode(',',$_POST['sim_user_role']);
		   }else{
		     $_POST['sim_user_role']="administrator";
		   }
		}
		  
		
		if (!empty($value['field_type']) && $value['field_type'] == "checkbox") {
			
			if (is_array($fname)) {
			
			    
				foreach ($fname as $the_field) {
					$sim_wp_vars[$the_field] = (empty($_POST["sim_wp_".$the_field]))? 0 : $_POST["sim_wp_".$the_field] ;
				}
			} else {
				$sim_wp_vars[$fname] = (empty($_POST["sim_wp_".$fname]))? 0 : $_POST["sim_wp_".$fname] ;
			}
			
			 
			
		} else {
			if (is_array($fname)) {
				$fctr = 0;
				foreach ($fname as $the_field) {
					$post_data = (isset($_POST["sim_wp_".$the_field]))? $_POST["sim_wp_".$the_field] : $_POST[$the_field] ;
					$post_data = (!empty($value['stripslashes'][$fctr]) && $value['stripslashes'][$fctr] == 1)? stripslashes($post_data) : $post_data;
					$post_data = (!empty($value['numbers_only'][$fctr]) && $value['numbers_only'][$fctr] == 1)? preg_replace("@[^0-9]@", "", $post_data) : $post_data;
					$sim_wp_vars[$the_field] = $post_data;
					$fctr++;
				}
			} else {
				$post_data = (isset($_POST["sim_wp_".$fname]))? $_POST["sim_wp_".$fname] : $_POST[$fname] ;
				$post_data = (!empty($value['stripslashes']) && $value['stripslashes'] == 1)? stripslashes($post_data) : $post_data;
				$post_data = (!empty($value['numbers_only']) && $value['numbers_only'] == 1)? preg_replace("@[^0-9]@", "", $post_data) : $post_data;
				$sim_wp_vars[$fname] = $post_data;
			}
		}
	    }
	    
	}      
	          
	sim_wp_data('sim_wp_vars', 'update', $sim_wp_vars);
	
    }
    
  sim_wp_initialize_variables();
    include(sim_WP_INCLUDES_PATH."/settings-options.php");
    sim_wp_md_save($sim_wp_mdo);
    unset($sim_wp_mdo);  
 
 sim_wp_initialize_variables(); 
 
	print "<div class='sim_wp_admin_success' >".__(" Settings successfully saved.", sim_WP_TEXT_DOMAIN)." $sim_view_link</div> <!--meta http-equiv='refresh' content='0'-->";
}




$update_button="<input type='submit' value='".__("Save Settings", sim_WP_TEXT_DOMAIN)."' class='button-primary'>";

print "
<div class='input_section'>
	<form method='post' name='settings' enctype=\"multipart/form-data\">
	
					<div class='input_title'>
						
						<h3><span class='fa fa-cog'>&nbsp;</span> Settings</h3>
						<span class='submit'>
						$update_button
						</span>
						<div class='clearfix'></div>
					</div>
					<div class='all_options'>
	
";

function sim_wp_md_display($data, $input_zone, $template, $additional_classes = "") {
    
    $GLOBALS['input_zone_type'] = $input_zone;
    $filtered_data = array_filter($data, "filter_sim_wp_mdo");
    unset($GLOBALS['input_zone_type']);
	
	$showregion=0;
	$showContact=0;
    $labels_ctr = 0;
    foreach ($filtered_data as $key => $value) {
    
    	if ($template == 1) {
		
		$the_row_id = (!empty($value["row_id"]))? " id = '$value[row_id]' " : "";
		$hide_row = (!empty($value['hide_row']) && $value['hide_row'] == true)? "style='display:none' " : "" ;
		$colspan = (!empty($value['colspan']) && $value['colspan'] > 1)? "colspan = '$value[colspan]'" : "" ;
		
		print "<div class='option_input option_text'>
					<label for='shortname_logo'>".$value['label'];
		if (!empty($value['more_info_label'])) {
			print "&nbsp;(<a href='#$value[more_info_label]' rel='sim_wp_pop'>?</a>)&nbsp;";
		}
		print "</label>";
	   	if (empty($value['colspan']) || $value['colspan'] < 2) {
			print "".$value['input_template']."<div class='clearfix'></div></div>";

	    }
		
    	} elseif ($template == 2) {
		
		if ($labels_ctr % 3 == 0) {
			$the_row_id = (!empty($value["row_id"]))? " id = '$value[row_id]' " : "";
			
		}	
		
		print "<div class='option_input option_text'>";
		print "<label for='shortname_logo'>".$value['label']."</label>".$value['input_template']."<small></small><div class='clearfix'></div></div>";
	

    	}
    	
    }
    
    print "</div>";
}

include(sim_WP_INCLUDES_PATH."/settings-options.php");


sim_wp_md_display($sim_wp_mdo, 'defaults', 1);






if (function_exists('icl_register_string')) {

	
	$GLOBALS['input_zone_type'] = "labels";
	$labels_arr = array_filter($sim_wp_mdo, "filter_sim_wp_mdo");
	unset($GLOBALS['input_zone_type']);
	
	
	foreach ($labels_arr as $value) {
		$the_field = $value['field_name'];
		$varname = "sim_wp_".$the_field;
		
		icl_register_string(sim_WP_DIR, $value['label'], $sim_wp_vars[$the_field]);
	}
	
	
	icl_register_string(sim_WP_DIR, 'Search Button Filename', "search_button.png");
	icl_register_string(sim_WP_DIR, 'Search Button Filename (Down State)', "search_button_down.png");
	icl_register_string(sim_WP_DIR, 'Search Button Filename (Over State)', "search_button_over.png");
}
					
sim_wp_md_display($sim_wp_mdo, 'labels', 2, "right_side");


print "</form>";

?>
</div>
<?php include(sim_WP_INCLUDES_PATH."/sim-wp-footer.php"); ?>

	<script>
	jQuery(".changeRatioVal").click(function(){
	var id=this.id;
	var idvalue=this.value;
	if(idvalue=='true'){
		jQuery('#'+id).val('false');
		jQuery('#'+id+'_val').val('false');
		}else{
		jQuery('#'+id).val('true');
		jQuery('#'+id+'_val').val('true');
		}
 })
 
</script>
