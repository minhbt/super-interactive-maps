<?php 
include(sim_WP_INCLUDES_PATH."/top-nav.php");
sim_wp_move_upload_directories();
sim_wp_initialize_variables();

# v3.0 -- What's New
if (!empty($_GET['sim_wp_a_s_v3']) && $_GET['sim_wp_a_s_v3'] == 1){$sim_wp_vars['sim_wp_a_s_check_v3'] = 'hide'; }
if ( (empty($sim_wp_vars['sim_wp_a_s_check_v3']) || $sim_wp_vars['sim_wp_a_s_check_v3'] != 'hide') && sim_wp_data('sim_wp_a_s_check_v3')!='hide' ) { 
//shifted to $sim_wp_vars in v3.18, but sim_wp_data('sim_wp_a_s_check_v3')!='hide' left there so it won't show again to those who've already hidden it
print "<div class='wrap'>
<div class='input_section'>

	
					<div class='input_title'>
						
						<h3><span class='fa fa-bolt'>&nbsp;</span> Quick Start</h3>
						<span class='submit'>
						<a href='http://superstorefinder.net/superinteractivemaps/user-guide/' id='__information' class='button button-primary' target='new'><span class='fa fa-book'>&nbsp;</span> User Guide</a> 
						<a href='http://superstorefinder.net/support' id='__information' class='button button-primary' target='new'><span class='fa fa-user-md'>&nbsp;</span> Support</a>
						</span>
						<div class='clearfix'></div>
					</div>
					<div class='all_options'>
					
					<div class='option_input option_text'>
					<div class='sim-wp-menu-alert' style='line-height: 22px;'>
<div style='padding:5px; /*background-image:url(".sim_WP_IMAGES_BASE_ORIGINAL."/logo.small.png); background-repeat:no-repeat; padding-left:45px; background-position-y:10px;*/'><img src='".sim_WP_IMAGES_BASE_ORIGINAL."/logo.small.png' style='vertical-align:middle'>&nbsp;<b>SUPER INTERACTIVE MAPS <span style='color:#FD8222;'>version {$sim_wp_version}</span></b><br></div>

<b>1.</b> Let's start with ".$addmapquick." Adding a New Map</a>.<br>

<b>2. Shortcode:</b> Use this shortcode example below on Wordpress Post, Page or Widget
<br><code class='sim-wp-menu-highlight-code'>[SUPER-INTERACTIVE-MAP ID=<font color=red>YourMapId</font>]</code>
</div> 

<div class='sim-wp-menu-alert' style='line-height: 22px;'>
<div style='padding:7px;'> <b>Important Notice</b>
<div class='sim_wp_admin_success' style='line-height: 22px;'>Since 22 June 2016, Google Maps API key is required (<a target='new' href='http://superstorefinder.net/support/knowledgebase/new-google-maps-after-22-june-2016-will-require-google-api-key/'>Read Article</a>) - <a target='new' href='https://superstorefinder.net/support/knowledgebase/how-to-use-google-api-keys-for-super-store-finder/'>Learn More</a> | <a href='".sim_WP_SETTINGS_PAGE."'>Set Key</a></div>
</div>
</div>
</div>					<div class='clearfix'></div>
					
					<div style='margin-top:15px;'><iframe width='100%' height='650' src='https://www.youtube.com/embed/iN9H0_ZlLtg' frameborder='0' allowfullscreen></iframe></div>
					</div>
					
					

	
</div></div>";
}



include(sim_WP_INCLUDES_PATH."/sim-wp-footer.php");
?>