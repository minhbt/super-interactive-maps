<?php
//if (!empty($_GET['pg']) && isset($wpdb) && $_GET['pg']=='add-maps') { 
include_once(sim_WP_INCLUDES_PATH."/top-nav.php"); 
//print "<script>jQuery('.locations').removeAttr('id');</script>"; } 

if (!isset($wpdb)){ include("../../../../wp-load.php"); }
if (!defined("sim_WP_INCLUDES_PATH")) { include("../sim-wp-define.php"); }
if (!function_exists("sim_wp_initialize_variables")) { include("../sim-wp-functions.php"); }
if (defined('sim_WP_ADDONS_PLATFORM_FILE') && file_exists(sim_WP_ADDONS_PLATFORM_FILE)) { include_once(sim_WP_ADDONS_PLATFORM_FILE); } //check if this inclusion is actually necessary here anymore - 3/19/14

print "<div class='wrap'>";
/*print "<h2>".__("Add Locations", sim_WP_TEXT_DOMAIN)."</h2><br>";*/

global $wpdb, $sim_wp_vars;
sim_wp_initialize_variables();
//Inserting addresses by manual input
if (!empty($_POST['sim_wp_name']) && (empty($_GET['mode']) || $_GET['mode']!="pca")) {
	if (!empty($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], "add-location_single")){
		sim_wp_add_location();
		print "<script>location.href='".sim_WP_ADMIN_NAV_BASE.sim_WP_ADMIN_DIR."/pages/maps.php';</script>";
		print "<div class='sim_wp_admin_success'>".__(" maps successfully added",sim_WP_TEXT_DOMAIN).". $sim_view_link</div> <!--meta http-equiv='refresh' content='0'-->"; 
	} else {
		print "<div class='sim-wp-menu-alert'>".__(" maps failed to be added to the database.",sim_WP_TEXT_DOMAIN)."</div>"; 
	}
}

//Importing addresses from an local or remote database
if (!empty($_POST['remote']) && trim($_POST['query'])!="" || !empty($_POST['finish_import'])) {
	
	if (!empty($_POST['server']) && preg_match("@.*\..{2,}@", $_POST['server'])) {
		include(sim_WP_ADDONS_PATH."/db-importer/remoteConnect.php");
	} else {
		if (file_exists(sim_WP_ADDONS_PATH."/db-importer/localImport.php")) {
			include(sim_WP_ADDONS_PATH."/db-importer/localImport.php");
		} elseif (file_exists(sim_WP_ADDONS_PATH."/csv-xml-importer-exporter/localImport.php")) {
			include(sim_WP_ADDONS_PATH."/csv-xml-importer-exporter/csv-xml-importer-exporter.php");
			include(sim_WP_ADDONS_PATH."/csv-xml-importer-exporter/localImport.php");
		}
	}
	//for intermediate step match column data to field headers
	if (empty($_POST['finish_import']) || $_POST['finish_import']!="1") {exit();}
}

//Importing CSV file of addresses
$newfile="temp-file.csv"; 
//$root=plugin_dir_path(__FILE__); //dirname(plugin_basename(__FILE__)); die($root);
$root=sim_WP_ADDONS_PATH;
$target_path="$root/";
//print_r($_FILES);
if (!empty($_FILES['csv_import']['tmp_name']) && move_uploaded_file($_FILES['csv_import']['tmp_name'], "$root/$newfile") && file_exists(sim_WP_ADDONS_PATH."/csv-xml-importer-exporter/csvImport.php")) {
	include(sim_WP_ADDONS_PATH."/csv-xml-importer-exporter/csvImport.php");
}
else{
		//echo "<div style='background-color: rgb(255, 124, 86); padding:5px'>There was an error uploading the file, please try again. </div>";
}

//If adding via the Point, Click, Add map (accepting AJAX)
if (!empty($_REQUEST['mode']) && $_REQUEST['mode']=="pca") {
	include(sim_WP_ADDONS_PATH."/point-click-add/pcaImport.php");
}

print sim_wp_location_form("add");

function csv_importer(){
	global $sim_wp_uploads_path, $sim_wp_path, $text_domain, $web_domain;
	if (file_exists(sim_WP_ADDONS_PATH."/csv-xml-importer-exporter/csv-import-form.php")) {
		include(sim_WP_ADDONS_PATH."/csv-xml-importer-exporter/csv-import-form.php");
		print "<br>";
	}
}
function db_importer(){
	global $sim_wp_uploads_path, $sim_wp_path, $text_domain, $web_domain;
	if (file_exists(sim_WP_ADDONS_PATH."/db-importer/db-import-form.php")) {
		//include(sim_WP_INCLUDES_PATH."/sim-wp-env.php");
		include(sim_WP_ADDONS_PATH."/db-importer/db-import-form.php");
	}
}
function point_click_add(){
	global $sim_wp_uploads_path, $sim_wp_path, $text_domain, $web_domain;
	if (file_exists(sim_WP_ADDONS_PATH."/point-click-add/point-click-add-form.php")) {
		include(sim_WP_ADDONS_PATH."/point-click-add/point-click-add-form.php");
	}
}
function sim_wp_csv_db_pca_forms(){
  if (file_exists(sim_WP_ADDONS_PATH."/db-importer/db-import-form.php") || file_exists(sim_WP_ADDONS_PATH."/point-click-add/point-click-add-form.php") || file_exists(sim_WP_ADDONS_PATH."/csv-xml-importer-exporter/csv-import-form.php")) {	
	print "<table><tr>";
	if (file_exists(sim_WP_ADDONS_PATH."/csv-xml-importer-exporter/csv-import-form.php") || file_exists(sim_WP_ADDONS_PATH."/db-importer/db-import-form.php")) {
		print "<td style='vertical-align:top; padding-top:0px'>";
		csv_importer();
		db_importer();
		print "</td>";
	}
	if (file_exists(sim_WP_ADDONS_PATH."/point-click-add/point-click-add-form.php")) {
		print "<td style='vertical-align:top; padding-top:0px'>";
		point_click_add();
		print "</td>";
	}	
		print "</tr></table>";
  }
}
if (function_exists("addto_sim_wp_hook")) {
	addto_sim_wp_hook('sim_wp_add_location_forms', 'csv_importer','','','csv-xml-importer-exporter');
	addto_sim_wp_hook('sim_wp_add_location_forms', 'db_importer','','','db-importer');
	addto_sim_wp_hook('sim_wp_add_location_forms', 'point_click_add','','','point-click-add');
} else {
	sim_wp_csv_db_pca_forms();
}

if (function_exists("do_sim_wp_hook")) {do_sim_wp_hook('sim_wp_add_location_forms', 'select-top');}



print "
</div>";

include(sim_WP_INCLUDES_PATH."/sim-wp-footer.php");
?>
