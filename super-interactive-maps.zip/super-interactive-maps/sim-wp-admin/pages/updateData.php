<?php
include("../../sim-wp-inc/includes/sim-wp-env.php");
global $wpdb;
if(isset($_POST['simaction']) && $_POST['simaction']=='insert')
{
	$fieldList=""; $valueList="";
	foreach ($_POST as $key=>$value) {
		if (preg_match("@sim_wpd_@", $key)) {
		  
				$fieldList.="$key,";
				if (is_array($value)){
					$value=serialize($value); //for arrays being submitted
					$valueList.="'$value',";
				} else {
				if($key=='sim_wpd_title'){
					$tempData = str_replace("\\", "",$value);
					$valueList.=$wpdb->prepare("%s", $tempData).",";
					}else{
					$valueList.=$wpdb->prepare("%s", $value).",";
					}
				}
		}
	 }	 
	$fieldList=substr($fieldList, 0, strlen($fieldList)-1);
	$valueList=substr($valueList, 0, strlen($valueList)-1);
	$wpdb->query("INSERT INTO ".sim_WP_TABLE_DATA." ($fieldList) VALUES ($valueList)");
	print $new_loc_id=$wpdb->insert_id;	
	
 }
 else if(isset($_POST['deleteid'])){
	$query="DELETE FROM ".sim_WP_TABLE_DATA." WHERE sim_wpd_id=".$_POST['deleteid']."";
	$wpdb->query($query);
 
 }else{
  		$field_value_str=""; 
		foreach ($_POST as $key=>$value) {
		    if(preg_match("@sim_wpd_@", $key)) {
				$key= $key; 
				if (is_array($value)){
					$value=serialize($value); 
					$field_value_str.=$key."='$value',";
				} else {
					$field_value_str.=$key."=".$wpdb->prepare("%s", $value).", "; 
				}
				$_POST["$key"]=$value; 
			}
		}	
		$field_value_str=substr($field_value_str, 0, strlen($field_value_str)-2);
		$wpdb->query($wpdb->prepare("UPDATE ".sim_WP_TABLE_DATA." SET ".str_replace("%", "%%", $field_value_str)." WHERE sim_wpd_id='%d'", $_POST['id'])); 
		print $_POST['id'];		
 }
?>