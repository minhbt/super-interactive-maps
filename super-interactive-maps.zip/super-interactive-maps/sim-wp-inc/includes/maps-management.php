<?php
print "<table width='100%' cellpadding='5px' cellspacing='0' style='border:solid silver 1px' id='mgmt_bar' class='widefat'>
<thead><tr>
<th style='/*background-color:#000;*/ vertical-align:middle; font-family:inherit; font-size:12px;'>$addmaps<input class='button-primary' type='button' value='".__("Delete", sim_WP_TEXT_DOMAIN)."' onclick=\"if(confirm('".__("Are you sure you want to remove the store[s)", sim_WP_TEXT_DOMAIN)."?')){LF=document.forms['locationForm'];LF.act.value='delete';LF.submit();}else{return false;}\"></th>
";
$extra=(!empty($extra))? $extra : "" ;

if (function_exists("addto_sim_wp_hook")) {addto_sim_wp_hook('sim_wp_mgmt_bar_links', 'export_links', '', '', 'csv-xml-importer-exporter');} 
$mgmt_bgcolor=((!function_exists("addto_sim_wp_hook") && file_exists(sim_WP_ADDONS_PATH."/csv-xml-importer-exporter/export-links.php")) || (!empty($sim_wp_hooks['sim_wp_mgmt_bar_links'])) )? "/*background-color:#e6e6e6; background-image:none;*/ border-left: solid #ccc 1px; border-right: solid #ccc 1px;" : "";
print "<th style='width:30%; text-align:center; color:black; font-family:inherit; font-size:12px; {$mgmt_bgcolor} /**/' class='youhave'>";
function export_links() {
		global $sim_wp_uploads_path, $web_domain, $extra, $sim_wp_base, $sim_wp_uploads_base, $text_domain;
		if (file_exists(sim_WP_ADDONS_PATH."/csv-xml-importer-exporter/export-links.php")) {
			$sim_wp_real_base=$sim_wp_base; $sim_wp_base=$sim_wp_uploads_base;
			include(sim_WP_ADDONS_PATH."/csv-xml-importer-exporter/export-links.php");
			$sim_wp_base=$sim_wp_real_base;
		}
		
} 
if (!function_exists("addto_sim_wp_hook")) {export_links();}
if (function_exists("do_sim_wp_hook")) { do_sim_wp_hook('sim_wp_mgmt_bar_links', 'select-right');  }

print "</th>";
print "</tr></thead></table>
";

?>