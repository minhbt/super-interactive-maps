<?php
if (is_dir(sim_WP_THEMES_PATH)) {
	$theme_dir=opendir(sim_WP_THEMES_PATH); 
	$theme_str="";
	while (false !== ($a_theme=readdir($theme_dir))) {
		if (!preg_match("@^\.{1,2}.*$@", $a_theme) && !preg_match("@\.(php|txt|htm(l)?)@", $a_theme)) {

			$selected=($a_theme==$sim_wp_vars['theme'])? " selected " : "";
			$theme_str.="<option value='$a_theme' $selected>$a_theme</option>\n";
		}
	}
}

$zl_arr=array();
for ($i=0; $i<=19; $i++) {
	$zl_arr[]=$i;
}


$aspect_ratio_check='';
if($sim_wp_vars['aspect_ratio']=='true'){ $aspect_ratio_check='checked';  }
// styles

$user_role_settings["".__("Administrator", sim_WP_TEXT_DOMAIN).""]="administrator";
$user_role_settings["".__("Author", sim_WP_TEXT_DOMAIN).""]="author";
$user_role_settings["".__("Subscriber", sim_WP_TEXT_DOMAIN).""]="subscriber";
$user_role_settings["".__("Contributor", sim_WP_TEXT_DOMAIN).""]="contributor";
$user_role_settings["".__("Editor", sim_WP_TEXT_DOMAIN).""]="editor";


if (function_exists("get_sim_current_user_role")){
$sim_role=get_sim_current_user_role();
}else{
$sim_role='administrator';
}
if($sim_role=='administrator'){
$user_role_set='';
$ex_cat = explode(",", $sim_wp_vars['sim_user_role']);
$ex_cat = array_map( 'trim', $ex_cat );
foreach($user_role_settings as $key=>$value) {
	$selected2=(in_array($value,$ex_cat))? 'selected="selected"' : '';	
	$desable=($value=='administrator')? 'disabled' : '';
	$user_role_set.="<option value='$value' $selected2 $desable>$key</option>\n";
}

$sim_wp_mdo[] = array("field_name" => "sim_user_role", "default" => "administrator", "input_zone" => "defaults", "label" =>  __("User Role", sim_WP_TEXT_DOMAIN), "input_template" => "<select name='sim_user_role[]' class='chosen-select' multiple>\n$user_role_set</select>");
}


$sim_wp_mdo[] = array("field_name" => "style_bg_color", "default" => "#1e73be", "input_zone" => "labels", "output_zone" => "sim_wp_dyn_js", "label" => __("Background Color", sim_WP_TEXT_DOMAIN), "input_template" => "<input type='text' name='style_bg_color' value=\"$sim_wp_vars[style_bg_color]\" class=\"my-color-field\" >");

$sim_wp_mdo[] = array("field_name" => "style_map_color", "default" => "", "input_zone" => "labels", "output_zone" => "sim_wp_dyn_js", "label" => __("Map Color", sim_WP_TEXT_DOMAIN), "input_template" => "<input type='text' name='style_map_color' value=\"$sim_wp_vars[style_map_color]\" class=\"my-color-field\" >");

//$sim_wp_mdo[] = array("field_name" => "style_map_hover", "default" => "", "input_zone" => "labels", "output_zone" => "sim_wp_dyn_js", "label" => __("Map Hover", sim_WP_TEXT_DOMAIN), "input_template" => "<input type='text' name='style_map_hover' value=\"$sim_wp_vars[style_map_hover]\" class=\"my-color-field\" >");


$sim_wp_mdo[] = array("field_name" => "marker_map_color", "default" => "#1dba28", "input_zone" => "labels", "output_zone" => "sim_wp_dyn_js", "label" => __("Region/Marker Color", sim_WP_TEXT_DOMAIN), "input_template" => "<input type='text' name='marker_map_color' value=\"$sim_wp_vars[marker_map_color]\" class=\"my-color-field\" >");

$sim_wp_mdo[] = array("field_name" => "style_marker_size", "default" => "10", "input_zone" => "labels", "output_zone" => "sim_wp_dyn_js", "label" => __("Marker Size", sim_WP_TEXT_DOMAIN), "input_template" => "<input type='text' name='style_marker_size' value=\"$sim_wp_vars[style_marker_size]\" size='14'>");


$sim_wp_mdo[] = array("field_name" => "style_width", "default" => "600", "input_zone" => "labels", "output_zone" => "sim_wp_dyn_js", "label" => __("Width", sim_WP_TEXT_DOMAIN), "input_template" => "<input type='text' name='style_width' value=\"$sim_wp_vars[style_width]\" size='14' >");

$sim_wp_mdo[] = array("field_name" => "sim_map_height", "default" => "400", "input_zone" => "labels", "output_zone" => "sim_wp_dyn_js", "label" => __("Height", sim_WP_TEXT_DOMAIN), "input_template" => "<input type='text' name='sim_map_height' value=\"$sim_wp_vars[sim_map_height]\" size='14' >");

$sim_wp_mdo[] = array("field_name" => "aspect_ratio", "default" => "true", "input_zone" => "labels", "output_zone" => "sim_wp_dyn_js", "label" => __("Aspect ratio", sim_WP_TEXT_DOMAIN), "input_template" => "<input  type='checkbox' id='change_hide_title' class='changeRatioVal' value=\"$sim_wp_vars[aspect_ratio]\" $aspect_ratio_check name='aspect_ratio'><input  type='hidden' id='change_hide_title_val' value=\"$sim_wp_vars[aspect_ratio]\"  name='aspect_ratio'>");

$border_pixel_settings["".__("0px", sim_WP_TEXT_DOMAIN).""]="0px";
$border_pixel_settings["".__("1px (Default)", sim_WP_TEXT_DOMAIN).""]="1px";
$border_pixel_settings["".__("2px", sim_WP_TEXT_DOMAIN).""]="2px";
$border_pixel_settings["".__("3px", sim_WP_TEXT_DOMAIN).""]="3px";
$border_pixel_settings["".__("4px", sim_WP_TEXT_DOMAIN).""]="4px";
$border_pixel_settings["".__("5px", sim_WP_TEXT_DOMAIN).""]="5px";
$border_pixel_settings["".__("6px", sim_WP_TEXT_DOMAIN).""]="6px";
$border_pixel_settings["".__("7px", sim_WP_TEXT_DOMAIN).""]="7px";
$border_pixel_settings["".__("8px", sim_WP_TEXT_DOMAIN).""]="8px";
$border_pixel_settings["".__("9px", sim_WP_TEXT_DOMAIN).""]="9px";
$border_pixel_settings["".__("10px", sim_WP_TEXT_DOMAIN).""]="10px";

$pixel_settings_options="";
foreach($border_pixel_settings as $key=>$value) {
	$selected=($sim_wp_vars['sim_border_pixel']==$value)? " selected " : "";
	$pixel_settings_options.="<option value='$value' $selected>$key</option>\n";
}

$sim_wp_mdo[] = array("field_name" => "sim_border_pixel", "default" => "1px", "input_zone" => "labels", "output_zone" => "sim_wp_dyn_js", "label" => __("Border Pixel", sim_WP_TEXT_DOMAIN), "input_template" => "<select name='sim_border_pixel'>\n$pixel_settings_options</select>");

$sim_wp_mdo[] = array("field_name" => "sim_border_color", "default" => "", "input_zone" => "labels", "output_zone" => "sim_wp_dyn_js", "label" => __("Border Color", sim_WP_TEXT_DOMAIN), "input_template" => "<input type='text' name='sim_border_color' value=\"$sim_wp_vars[sim_border_color]\" class=\"my-color-field\" >");

$sim_wp_mdo[] = array("field_name" => "sim_hover_color", "default" => "", "input_zone" => "labels", "output_zone" => "sim_wp_dyn_js", "label" => __("Border Hover Color", sim_WP_TEXT_DOMAIN), "input_template" => "<input type='text' name='sim_hover_color' value=\"$sim_wp_vars[sim_hover_color]\" class=\"my-color-field\" >");

$border_hover_settings["".__("No (Default)", sim_WP_TEXT_DOMAIN).""]="false";
$border_hover_settings["".__("Yes", sim_WP_TEXT_DOMAIN).""]="true";
$hover_settings_options="";
foreach($border_hover_settings as $key=>$value) {
	$selected=($sim_wp_vars['sim_border_hover']==$value)? " selected " : "";
	$hover_settings_options.="<option value='$value' $selected>$key</option>\n";
}

$sim_wp_mdo[] = array("field_name" => "sim_border_hover", "default" => "true", "input_zone" => "labels", "output_zone" => "sim_wp_dyn_js", "label" => __("Border Hover", sim_WP_TEXT_DOMAIN), "input_template" => "<select name='sim_border_hover'>\n$hover_settings_options</select>");

$pixel_hover_options="";
foreach($border_pixel_settings as $key=>$value) {
	$selected=($sim_wp_vars['sim_hover_pixel']==$value)? " selected " : "";
	$pixel_hover_options.="<option value='$value' $selected>$key</option>\n";
}

$sim_wp_mdo[] = array("field_name" => "sim_hover_pixel", "default" => "1px", "input_zone" => "labels", "output_zone" => "sim_wp_dyn_js", "label" => __("Border Hover Pixel", sim_WP_TEXT_DOMAIN), "input_template" => "<select name='sim_hover_pixel'>\n$pixel_hover_options</select>");


$sim_wp_mdo[] = array("field_name" => "sim_google_api_key", "default" => "", "input_zone" => "labels", "output_zone" => "sim_wp_dyn_js", "label" => __("Google API key", sim_WP_TEXT_DOMAIN), "input_template" => "<input type='text' name='sim_google_api_key' value=\"$sim_wp_vars[sim_google_api_key]\">");
?>