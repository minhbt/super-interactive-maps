<?php
if ($_POST) {extract($_POST);}
if (is_array($sim_wp_id)==1) {
	$rplc_arr=array_fill(0, count($sim_wp_id), "%d");
	$id_string=implode(",", array_map(array($wpdb, "prepare"), $rplc_arr, $sim_wp_id)); 
} else { 
	$id_string=$wpdb->prepare("%d", $sim_wp_id); 
}
$wpdb->query("DELETE FROM ".sim_WP_TABLE." WHERE sim_wp_id IN ($id_string)");
sim_wp_process_map_data("", "delete", $id_string);
?>