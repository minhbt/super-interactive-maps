<?php
	if (!empty($_GET['delete'])) {
		if (!empty($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], "delete-location_".$_GET['delete'])){
			$wpdb->query($wpdb->prepare("DELETE FROM ".sim_WP_TABLE." WHERE sim_wp_id='%d'", $_GET['delete'])); 
			sim_wp_process_map_data("", "delete", $_GET['delete']); 
		} 
	}
	if (!empty($_GET['copy'])) {
		if (!empty($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], "copy-location_".$_GET['copy'])){
			$copyRecord=$wpdb->get_results("SELECT * FROM ".sim_WP_TABLE." WHERE sim_wp_id=".$_GET['copy']." ", ARRAY_A);
			
			/***
			 ***Copy Main Map Data ***
			***/
			
			if($copyRecord){
				$fieldList=""; $valueList="";
				foreach ($copyRecord[0] as $key=>$value) {
					if ($key!='sim_wp_id') {
						$fieldList.="$key,";
						if (is_array($value)){
							$valueList.="'$value',";
						} else {
							$valueList.=$wpdb->prepare("%s", $value).",";
						}
					}
				}
				$fieldList=substr($fieldList, 0, strlen($fieldList)-1);
				$valueList=substr($valueList, 0, strlen($valueList)-1);
				$wpdb->query("INSERT INTO ".sim_WP_TABLE." ($fieldList) VALUES ($valueList)");
				$new_loc_id=$wpdb->insert_id;	
			
			    /***
				***Copy Associated Map Data ***
				***/
			
				$copyDataRecord=$wpdb->get_results("SELECT * FROM ".sim_WP_TABLE_DATA." WHERE 	sim_wpd_data_id=".$_GET['copy']." ", ARRAY_A);
				if($copyDataRecord){
					for($i=0;$i<count($copyDataRecord);$i++){
						$fieldList=""; $valueList="";
						foreach ($copyDataRecord[$i] as $key=>$value) {
							if ('sim_wpd_data_id'!=$key && $key!='sim_wpd_id') {
								$fieldList.="$key,";
								if (is_array($value)){
									$valueList.="'$value',";
								} else {
									$valueList.=$wpdb->prepare("%s", $value).",";
								}
							}
							if($key=='sim_wpd_data_id'){
								$fieldList.="sim_wpd_data_id,";
								$valueList.=$wpdb->prepare("%s", $new_loc_id).",";
							}
							
						}
						$fieldList=substr($fieldList, 0, strlen($fieldList)-1);
						$valueList=substr($valueList, 0, strlen($valueList)-1);
						$wpdb->query("INSERT INTO ".sim_WP_TABLE_DATA." ($fieldList) VALUES ($valueList)");
					}
				}
			}
			
			
		}
        print "<script>location.replace('".str_replace("&copy=$_GET[copy]", "", $_SERVER['REQUEST_URI'])."');</script>";		
	}
	if (!empty($_POST) && !empty($_GET['edit']) && $_POST['act']!="delete" && $_POST['act']!="copy") {
		$field_value_str=""; 
		foreach ($_POST as $key=>$value) {
			if (preg_match("@\-$_GET[edit]@", $key)) {
				$key=str_replace("-$_GET[edit]", "", $key); 
				if (is_array($value)){
					$value=serialize($value); 
					$field_value_str.=$key."='$value',";
				} else {
					$field_value_str.=$key."=".$wpdb->prepare("%s", trim(sim_comma(stripslashes($value)))).", "; 
				}
				$_POST["$key"]=$value; 
			}
		}
		
		$field_value_str=substr($field_value_str, 0, strlen($field_value_str)-2);
		$edit=$_GET['edit']; extract($_POST);
		 
		$wpdb->query($wpdb->prepare("UPDATE ".sim_WP_TABLE." SET ".str_replace("%", "%%", $field_value_str)." WHERE sim_wp_id='%d'", $_GET['edit'])); 
		
		//if(!empty($_POST['sim_wp_tags'])){sim_wp_process_map_data($_POST['sim_wp_tags'], "insert", $_GET['edit']);}
		
		print "<script>location.replace('".str_replace("&edit=$_GET[edit]", "", $_SERVER['REQUEST_URI'])."');</script>";
	 }
	if (!empty($_POST['act']) && !empty($_POST['sim_wp_id']) && $_POST['act']=="delete") {
		
		if (!empty($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], "manage-locations_bulk")){
			include(sim_WP_ACTIONS_PATH."/delete-maps.php");
		} else {
			print "<div class='sim-wp-menu-alert'>Security check doesn't validate for bulk deletion of locations.</div>";
		}
	}
	if (!empty($_POST['act']) && !empty($_POST['sim_wp_id']) && preg_match("@tag@", $_POST['act'])) {
		
		include(sim_WP_ACTIONS_PATH."/tag-maps.php");
	}
	if (!empty($_POST['act']) && ($_POST['act']=='add_multi' || $_POST['act']=='remove_multi')) {
		
		include(sim_WP_ADDONS_PATH."/multiple-field-updater/multiLocationUpdate.php");
	}
	if (!empty($_POST['act']) && $_POST['act']=="locationsPerPage") {
		
		$sim_wp_vars['admin_locations_per_page']=$_POST['sim_wp_admin_locations_per_page'];
		sim_wp_data('sim_wp_vars', 'update', $sim_wp_vars);
		extract($_POST);
	}
	if (!empty($_POST['act']) && $_POST['act']=="regeocode" && file_exists(sim_WP_ADDONS_PATH."/csv-xml-importer-exporter/reGeo.php")) {
		include(sim_WP_ADDONS_PATH."/csv-xml-importer-exporter/reGeo.php");
	}
	if (!empty($_GET['changeView']) && $_GET['changeView']==1) {
		if ($sim_wp_vars['location_table_view']=="Normal") {
			$sim_wp_vars['location_table_view']='Expanded';
			sim_wp_data('sim_wp_vars', 'update', $sim_wp_vars);
			
		} else {
			$sim_wp_vars['location_table_view']='Normal';
			sim_wp_data('sim_wp_vars', 'update', $sim_wp_vars);
			
		}
		print "<script>location.replace('".str_replace("&changeView=1", "", $_SERVER['REQUEST_URI'])."');</script>";
	}
	if (!empty($_GET['changeUpdater']) && $_GET['changeUpdater']==1) {
		if (sim_wp_data('sim_wp_location_updater_type')=="Tagging") {
			sim_wp_data('sim_wp_location_updater_type', 'update', 'Multiple Fields');
			
		} else {
			sim_wp_data('sim_wp_location_updater_type', 'update', 'Tagging');
			
		}
		$_SERVER['REQUEST_URI']=str_replace("&changeUpdater=1", "", $_SERVER['REQUEST_URI']);
		print "<script>location.replace('$_SERVER[REQUEST_URI]');</script>";
	}
	
?>