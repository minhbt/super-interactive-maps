<?php

if (!empty($_POST)) {extract($_POST);}


if (is_array($sim_wp_id)==1) {
	$rplc_arr=array_fill(0, count($sim_wp_id), "%d");
	$id_string=implode(",", array_map(array($wpdb, "prepare"), $rplc_arr, $sim_wp_id)); 	
} else {
	$id_string=$wpdb->prepare("%d", $sim_wp_id);
}
if ($act=="add_tag") {
		$simcateGory=sim_wp_prepare_tag_string($sim_wp_tags);
		$wpdb->query($wpdb->prepare("UPDATE ".sim_WP_TABLE." SET sim_wp_tags=CONCAT(IFNULL(sim_wp_tags, ''), %s ) WHERE sim_wp_id IN ($id_string)", sim_comma(stripslashes($simcateGory)))); 
		sim_wp_process_tags(sim_wp_prepare_tag_string($sim_wp_tags), "insert", $sim_wp_id); 
}
elseif ($act=="remove_tag") {

	if (empty($sim_wp_tags)) {

		$wpdb->query("UPDATE ".sim_WP_TABLE." SET sim_wp_tags='' WHERE sim_wp_id IN ($id_string)");
		sim_wp_process_tags("", "delete", $id_string);
	}
	else {		
		
		$wpdb->query($wpdb->prepare("UPDATE ".sim_WP_TABLE." SET sim_wp_tags=REPLACE(sim_wp_tags, %s, '') WHERE sim_wp_id IN ($id_string)", $sim_wp_tags.",")); 
		$wpdb->query($wpdb->prepare("UPDATE ".sim_WP_TABLE." SET sim_wp_tags=REPLACE(sim_wp_tags, %s, '') WHERE sim_wp_id IN ($id_string)", $sim_wp_tags."&#44;")); 
		sim_wp_process_tags($sim_wp_tags, "delete", $id_string); 
	}
}
?>