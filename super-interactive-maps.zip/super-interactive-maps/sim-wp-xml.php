<?php
function xml_out($buff) {
	preg_match("@<locator>.*<\/locator>@s", $buff, $the_xml);

	return $the_xml[0];
}
if (empty($_GET['debug'])) {
	ob_start("xml_out");
}
header("Content-type: text/xml");
include("sim-wp-inc/includes/sim-wp-env.php");
global $sim_wp_vars,$wpdb;

$sim_wp_ap_xml = array("sim_wp_custom_fields", "sim_wp_xml_columns");
foreach ($sim_wp_ap_xml as $value){ if (!empty($_GET[$value])){ unset($_GET[$value]); } }

$sim_wp_custom_fields = (!empty($sim_wp_xml_columns))? ", ".implode(", ", $sim_wp_xml_columns) : "" ;

if (!empty($_GET)) { $_sl = $_GET; unset($_GET['mode']); unset($_GET['lat']); unset($_GET["lng"]); unset($_GET["radius"]); unset($_GET["edit"]);}
$_GET=array_filter($_GET);

$sim_wp_param_where_clause="";
if (function_exists("do_sim_wp_hook")){ do_sim_wp_hook("sim_wp_xml_query"); }
$query=$wpdb->get_results("SELECT sim_wp_id,sim_wp_address, sim_wp_address2, sim_wp_store, sim_wp_city, sim_wp_state, sim_wp_zip, sim_wp_latitude, sim_wp_longitude, sim_wp_description, sim_wp_url, sim_wp_ext_url, sim_wp_embed_video,sim_wp_contact_email, sim_wp_default_media, sim_wp_hours, sim_wp_phone, sim_wp_fax, sim_wp_email, sim_wp_image, sim_wp_tags FROM ".sim_WP_TABLE." WHERE sim_wp_store<>'' AND sim_wp_longitude<>'' AND sim_wp_latitude<>'' LIMIT 9999", ARRAY_A);
$query2=$wpdb->get_results("SELECT *  FROM ".sim_WP_TAG_TABLE." WHERE sim_wp_tag_id!=0 GROUP BY(sim_wp_tag_slug)", ARRAY_A);
	
echo "<locator>\n";
// Xml header

foreach ($query2 as $row2) {
   $tag=(trim($row2['sim_wp_tag_slug'])!="")? simParseToXML($row2['sim_wp_tag_slug']) : " " ;
   $tagid=(trim($row2['sim_wp_tag_id'])!="")? simParseToXML($row2['sim_wp_tag_id']) : " " ;
// tag with space
$copy= $tag;
$tag= str_replace(" ","",$tag);
$tag=str_replace(",","",$tag);
$tag=str_replace('&amp;#39;','',$tag);
$tag=str_replace("&#39;","",$tag); 
$tag=str_replace("&amp;","_n_",$tag);

echo "\n
<legend>\n
<label>\n
<tag>".$tag."</tag>\n
<copy>".$copy."</copy>\n
</label>\n
</legend>\n";

}

// Xml header
echo "<store>\n";



foreach ($query as $row) {
   $addr2=(trim($row['sim_wp_address2'])!="")? " ".simParseToXML($row['sim_wp_address2']). ", " : " " ;
 	$city=(trim($row['sim_wp_city'])!="")? " ".simParseToXML($row['sim_wp_city']). ", " : " " ;

  if(!empty($row['sim_wp_contact_email']) && $row['sim_wp_contact_email']!='0')
  {
  	$contactEmail=(trim($row['sim_wp_contact_email'])=="1")? simParseToXML($row['sim_wp_email']) : simParseToXML($sim_wp_vars['sim_conatct_email']) ;
  }
  else {
	  $contactEmail='';
  }
  $row['sim_wp_description']=(trim($row['sim_wp_description'])=="&lt;br&gt;" || trim($row['sim_wp_description'])=="")? "" : $row['sim_wp_description'];
  $row['sim_wp_hours']=(trim($row['sim_wp_hours'])=="&lt;br&gt;" || trim($row['sim_wp_hours'])=="")? "" : $row['sim_wp_hours'];
  $row['sim_wp_url']=(!sim_url_test($row['sim_wp_url']) && trim($row['sim_wp_url'])!="")? "http://".$row['sim_wp_url'] : $row['sim_wp_url'] ;
  $row['sim_wp_ext_url']=(!sim_url_test($row['sim_wp_ext_url']) && trim($row['sim_wp_ext_url'])!="")? "http://".$row['sim_wp_ext_url'] : $row['sim_wp_ext_url'] ;
  // Xml nodes 
  echo '<item>';
  echo '<location>' . simParseToXML($row['sim_wp_store']) . '</location>';
  echo '<address>' . simParseToXML($row['sim_wp_address']) .$addr2. $city. ' ' .simParseToXML($row['sim_wp_state']).' ' .simParseToXML($row['sim_wp_zip']).'</address>';
  echo '<latitude>' . $row['sim_wp_latitude'] . '</latitude>';
  echo '<longitude>' . $row['sim_wp_longitude'] . '</longitude>';
  echo '<description>' .simParseToHXML($row['sim_wp_description']). '</description>';
  echo '<website>' . simParseToXML($row['sim_wp_url']) . '</website>';
  echo '<exturl>' . simParseToXML($row['sim_wp_ext_url']) . '</exturl>';
  echo '<operatingHours>' .simParseToHXML($row['sim_wp_hours']). '</operatingHours>';
  echo '<embedvideo>'.base64_encode(htmlspecialchars_decode($row['sim_wp_embed_video'])).'</embedvideo>';
  echo '<defaultmedia>'.$row['sim_wp_default_media'].'</defaultmedia>';
  echo '<telephone>' . simParseToXML($row['sim_wp_phone']) . '</telephone>';
  echo '<fax>' . simParseToXML($row['sim_wp_fax']) . '</fax>';
  echo '<email>' . simParseToXML($row['sim_wp_email']) . '</email>';
  echo '<contactus>'.$contactEmail.'</contactus>';
  // image
  // store img
  $sim_wp_uploads=wp_upload_dir();
  $sim_wp_uploads_path=$sim_wp_uploads['basedir']."/sim-wp-uploads"; 
			$upload_dir=$sim_wp_uploads_path."/images/".$row['sim_wp_id'].'/*';
			$upload_dir_img=$sim_wp_uploads_path."/images/".$row['sim_wp_id'];
			$sim_wp_uploads_base=$sim_wp_uploads['baseurl']."/sim-wp-uploads";
			
			$img = '';
			$files = array();
			if(is_dir($upload_dir_img))
			{
			foreach (glob($upload_dir) as $file) {
			  $files[] = $file;
			}
		
			if($files !== FALSE && isset($files[0])) {
			$files[0] = str_replace('ori_', '', $files[0]);
			$files[0] = str_replace($sim_wp_uploads_path."/images/".$row['sim_wp_id'], '', $files[0]);
			
				$img = $sim_wp_uploads_base."/images/".$row['sim_wp_id'].$files[0];
			}
			}
 		    echo '<storeimage>'.simParseToXML($img).'</storeimage>';
   		   //*custom marker icon */
		    $upload_dir=$sim_wp_uploads_path."/images/icons/".$row['sim_wp_id'].'/*';
			$upload_dir_icon=$sim_wp_uploads_path."/images/icons/".$row['sim_wp_id'];
			$sim_wp_uploads_base=$sim_wp_uploads['baseurl']."/sim-wp-uploads";
			
			$mrkr = '';
			$files = array();
			
			if(is_dir($upload_dir_icon))
			{
			foreach (glob($upload_dir) as $file) {
			  $files[] = $file;
			}
				if($files !== FALSE && isset($files[0])) {
				$files[0] = str_replace($sim_wp_uploads_path."/images/icons/".$row['sim_wp_id'], '', $files[0]);
				
					$mrkr = $sim_wp_uploads_base."/images/icons/".$row['sim_wp_id'].$files[0];
				}
			}
 		  echo '<custmmarker>'.simParseToXML($mrkr).'</custmmarker>';
  /* custom marker end  */  
		
  $row['sim_wp_tags'] = str_replace('&#44;', ',', $row['sim_wp_tags']);
  $row['sim_wp_tags'] = preg_replace('/\s+/', '', $row['sim_wp_tags']);
  $tagarray = explode(',',trim($row['sim_wp_tags']));
for($i=0;$i<sizeof($tagarray)-1;$i++){
	 $tags= str_replace(" ","",$tagarray[$i]);
	 $tags=str_replace("'",'',$tags);
	 $tags=str_replace("\\","",$tags); 
	 $tags=str_replace("&#39;","",$tags); 
	 $tags=str_replace("&amp;","_n_",$tags);
	 echo '<'.$tags.'>true</'.$tags.'>';
}
  if (!empty($sim_wp_xml_columns)){ 
  $alrdy_used=array('name', 'address', 'street', 'street2', 'city', 'state', 'zip', 'lat', 'lng', 'distance', 'description', 'url', 'hours', 'phone', 'fax', 'email', 'image', 'tags');
  	foreach($sim_wp_xml_columns as $key=>$value) {
  		if (!in_array($value, $alrdy_used)) { //can't have duplicate property names in xml
	  		$row[$value]=(!isset($row[$value]))? "" : $row[$value] ;
  			 echo "$value=\"" . simParseToXML($row[$value]) . "\" ";
  			 $alrdy_used[]=$value;
  		}
  	}
  }
  echo "</item>\n";
}

// End XML file
echo "</store>\n
</locator>\n";
if (empty($_GET['debug'])) {
	ob_end_flush();
}


?>