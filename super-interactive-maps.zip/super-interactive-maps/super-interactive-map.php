<?php
/*
Plugin Name: Super Interactive Maps for Wordpress
Plugin URI: http://www.superstorefinder.net
Description: Super Interactive Maps is a fully-featured WordPress Plugin integrated with Google Geochart that allows you to create maps of country, content and regions as well as add interactivity such as map markers, interactive pop up (video/text/images), colored regions/markers and many other cool features.
Version: 1.6
Author: Joe Iz
Author URI: http://www.superstorefinder.net
*/

$sim_wp_version="1.6";
define('sim_WP_VERSION', $sim_wp_version);
$sim_wp_db_version=4.0;
include_once("sim-wp-define.php");
include_once(sim_WP_INCLUDES_PATH."/copyfolderlibrary.php");

add_action('admin_menu', 'sim_wp_add_options_page');
//add_action('wp_head', 'sim_wp_head_scripts');
add_filter('widget_text', 'sim_wp_template');
global $superinteractivemap,$superintermap_array;
	$superintermap_array = array();
include_once("sim-wp-functions.php");


register_activation_hook( __FILE__, 'sim_wp_install_tables');

add_action('the_content', 'sim_wp_template');
//add_action('the_content', 'sim_wp_map_check');

	
if (preg_match("@$sim_wp_dir@", $_SERVER['REQUEST_URI'])) {
	add_action("admin_print_scripts", 'sim_wp_add_admin_javascript');
	add_action("admin_print_styles",'sim_wp_add_admin_stylesheet');
}
load_plugin_textdomain(sim_WP_TEXT_DOMAIN, "", "../uploads/sim-wp-uploads/languages/");



function sim_wp_plugin_prevent_upgrade($opt) {
	global $update_class;
	$plugin = plugin_basename(__FILE__);
	if ( $opt && isset($opt->response[$plugin]) ) {

		$update_class="update-message";

	}
	return $opt;
}

function sim_wp_update_db_check() {
    global $sim_wp_db_version;
    if (sim_wp_data('sim_wp_db_version') != $sim_wp_db_version) {
        sim_wp_install_tables();
    }
}
add_action('plugins_loaded', 'sim_wp_update_db_check');

add_action('activated_plugin','save_errors');
function save_errors(){
    update_option('plugin_error',  ob_get_contents());
}
?>