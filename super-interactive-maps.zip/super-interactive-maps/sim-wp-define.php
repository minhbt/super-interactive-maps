<?php
$sim_wp_siteurl=get_option('siteurl'); $sim_wp_blog_charset=get_option('blog_charset'); $sim_wp_admin_email=get_option('admin_email');
$sim_wp_site_name=get_option('blogname');
$sim_wp_dir=dirname(plugin_basename(__FILE__)); 
$sim_wp_pub_dir=$sim_wp_dir."/sim-wp-pub";
$sim_wp_inc_dir=$sim_wp_dir."/sim-wp-inc";
$sim_wp_admin_dir=$sim_wp_dir."/sim-wp-admin";
$sim_wp_base=plugins_url('', __FILE__); 
$sim_wp_path=substr(plugin_dir_path(__FILE__), 0, -1); 
$sim_wp_uploads=wp_upload_dir();
$sim_wp_uploads_base=$sim_wp_uploads['baseurl']."/sim-wp-uploads";
$sim_wp_upload_base=$sim_wp_uploads_base; 
$sim_wp_uploads_path=$sim_wp_uploads['basedir']."/sim-wp-uploads"; 
$sim_wp_upload_path=$sim_wp_uploads_path; 
$top_nav_base="/".substr($_SERVER["PHP_SELF"],1)."?page=";
$admin_nav_base=$sim_wp_siteurl."/wp-admin/admin.php?page="; 
$text_domain="lol";
$sim_view_link="| <a href='".$admin_nav_base.$sim_wp_admin_dir."/pages/maps.php'>".__("View Map List", $text_domain)."</a> <script>setTimeout(function(){jQuery('.sim_wp_admin_success').fadeOut('slow');}, 6000);</script>";
$web_domain=str_replace("www.","",$_SERVER['HTTP_HOST']);

		define('sim_WP_SITEURL', $sim_wp_siteurl); define('sim_WP_BLOG_CHARSET', $sim_wp_blog_charset); define('sim_WP_ADMIN_EMAIL', $sim_wp_admin_email); define('sim_WP_SITE_NAME', $sim_wp_site_name);
		define('sim_WP_DIR', $sim_wp_dir);
		define('sim_WP_PUB_DIR', $sim_wp_dir);
		define('sim_WP_CSS_DIR', sim_WP_PUB_DIR."/css");

		define('sim_WP_JS_DIR', sim_WP_PUB_DIR."/js");

		define('sim_WP_IMAGES_DIR_ORIGINAL', sim_WP_PUB_DIR."/images");
		define('sim_WP_INC_DIR', $sim_wp_inc_dir);
		define('sim_WP_ACTIONS_DIR', sim_WP_INC_DIR."/actions");
		define('sim_WP_INCLUDES_DIR', sim_WP_INC_DIR."/includes");
		define('sim_WP_ADMIN_DIR', $sim_wp_admin_dir);
		define('sim_WP_INFO_DIR', sim_WP_ADMIN_DIR."/info");
		define('sim_WP_PAGES_DIR', sim_WP_ADMIN_DIR."/pages");

		define('sim_WP_ADDONS_DIR_ORIGINAL', sim_WP_ADMIN_DIR."/addons");
		define('sim_WP_LANGUAGES_DIR_ORIGINAL', sim_WP_ADMIN_DIR."/languages");
		define('sim_WP_THEMES_DIR_ORIGINAL', sim_WP_ADMIN_DIR."/themes");
		define('sim_WP_BASE', $sim_wp_base);
		define('sim_WP_PUB_BASE', sim_WP_BASE);
		define('sim_WP_CSS_BASE', sim_WP_PUB_BASE."/css");

		define('sim_WP_JS_BASE', sim_WP_PUB_BASE."/js");

		define('sim_WP_IMAGES_BASE_ORIGINAL', sim_WP_PUB_BASE."/images");
		define('sim_WP_INC_BASE', sim_WP_BASE."/sim-wp-inc");
		define('sim_WP_ACTIONS_BASE', sim_WP_INC_BASE."/actions");
		define('sim_WP_INCLUDES_BASE', sim_WP_INC_BASE."/includes");
		define('sim_WP_ADMIN_BASE', sim_WP_BASE."/sim-wp-admin");
		define('sim_WP_INFO_BASE', sim_WP_ADMIN_BASE."/info");
		define('sim_WP_PAGES_BASE', sim_WP_ADMIN_BASE."/pages");

		define('sim_WP_ADDONS_BASE_ORIGINAL', sim_WP_ADMIN_BASE."/addons");
		define('sim_WP_LANGUAGES_BASE_ORIGINAL', sim_WP_ADMIN_BASE."/languages");
		define('sim_WP_THEMES_BASE_ORIGINAL', sim_WP_ADMIN_BASE."/themes");
		define('sim_WP_PATH', $sim_wp_path);
		define('sim_WP_PUB_PATH', sim_WP_PATH);
		define('sim_WP_CSS_PATH', sim_WP_PUB_PATH."/css");

		define('sim_WP_JS_PATH', sim_WP_PUB_PATH."/js");

		define('sim_WP_IMAGES_PATH_ORIGINAL', sim_WP_PUB_PATH."/images");
		define('sim_WP_INC_PATH', sim_WP_PATH."/sim-wp-inc");
		define('sim_WP_ACTIONS_PATH', sim_WP_INC_PATH."/actions");
		define('sim_WP_INCLUDES_PATH', sim_WP_INC_PATH."/includes");
		define('sim_WP_ADMIN_PATH', sim_WP_PATH."/sim-wp-admin");
		define('sim_WP_INFO_PATH', sim_WP_ADMIN_PATH."/info");
		define('sim_WP_PAGES_PATH', sim_WP_ADMIN_PATH."/pages");
		define('sim_WP_CSV_PATH_ORIGINAL', sim_WP_PUB_PATH."/csv");

		define('sim_WP_ADDONS_PATH_ORIGINAL', sim_WP_ADMIN_PATH."/addons");
		define('sim_WP_LANGUAGES_PATH_ORIGINAL', sim_WP_ADMIN_PATH."/languages");
		define('sim_WP_THEMES_PATH_ORIGINAL', sim_WP_ADMIN_PATH."/themes");
		define('sim_WP_UPLOADS_BASE', $sim_wp_uploads_base);
		define('sim_WP_UPLOADS_PATH', $sim_wp_uploads_path);
		define('sim_WP_TOP_NAV_BASE', $top_nav_base);
		define('sim_WP_ADMIN_NAV_BASE', $admin_nav_base);
		define('sim_WP_TEXT_DOMAIN', $text_domain);
		define('sim_WP_VIEW_LINK', $sim_view_link);
		define('sim_WP_WEB_DOMAIN', $web_domain);

		define('sim_WP_ADDONS_BASE', sim_WP_UPLOADS_BASE."/addons");
		define('sim_WP_CACHE_BASE', sim_WP_UPLOADS_BASE."/cache");
		define('sim_WP_CUSTOM_CSS_BASE', sim_WP_UPLOADS_BASE."/custom-css");
		define('sim_WP_CUSTOM_CSV_BASE', sim_WP_UPLOADS_BASE."/csv");

		define('sim_WP_IMAGES_BASE', sim_WP_UPLOADS_BASE."/images");
		define('sim_WP_LANGUAGES_BASE', sim_WP_UPLOADS_BASE."/languages");
		define('sim_WP_THEMES_BASE', sim_WP_UPLOADS_BASE."/themes");

		define('sim_WP_ADDONS_PATH', sim_WP_UPLOADS_PATH."/addons");
		define('sim_WP_ADDONS_MARKER', sim_WP_ADDONS_PATH."/marker");
		define('sim_WP_CACHE_PATH', sim_WP_UPLOADS_PATH."/cache");
		define('sim_WP_CUSTOM_CSS_PATH', sim_WP_UPLOADS_PATH."/custom-css");
		define('sim_WP_CUSTOM_CSV_PATH', sim_WP_UPLOADS_PATH."/csv");

		define('sim_WP_IMAGES_PATH', sim_WP_UPLOADS_PATH."/images");
		define('sim_WP_LANGUAGES_PATH', sim_WP_UPLOADS_PATH."/languages");
		define('sim_WP_THEMES_PATH', sim_WP_UPLOADS_PATH."/themes");

		define('sim_WP_INFORMATION_PAGE', sim_WP_TOP_NAV_BASE.sim_WP_PAGES_DIR."/quickstart.php");
		define('sim_WP_MANAGE_LOCATIONS_PAGE', sim_WP_TOP_NAV_BASE.sim_WP_PAGES_DIR."/maps.php");
		define('sim_WP_ADD_LOCATIONS_PAGE', sim_WP_MANAGE_LOCATIONS_PAGE."&pg=add-maps");
		define('sim_WP_SETTINGS_PAGE1', sim_WP_TOP_NAV_BASE.sim_WP_PAGES_DIR."/settings.php");
		define('sim_WP_SETTINGS_PAGE', sim_WP_SETTINGS_PAGE1); 

		define('sim_WP_PARENT_PAGE', sim_WP_INFORMATION_PAGE); 
		define('sim_WP_PARENT_URL', preg_replace("@".preg_quote(sim_WP_TOP_NAV_BASE)."@", "",sim_WP_PARENT_PAGE)); 

$sim_wp_aps=glob(sim_WP_ADDONS_PATH.'/*addons-platform*', GLOB_NOSORT); 
if (!empty($sim_wp_aps)){
	$sim_wp_addons_platform_dir = basename(current($sim_wp_aps));
	foreach ($sim_wp_aps as $sim_wp_ap_path) {
		if (file_exists($sim_wp_ap_path.'/'.basename($sim_wp_ap_path).'.php')) {
			$sim_wp_addons_platform_dir = basename($sim_wp_ap_path);
			break;
		} 
	}
	define('sim_WP_ADDONS_PLATFORM_DIR', $sim_wp_addons_platform_dir);
	define('sim_WP_ADDONS_PLATFORM_PATH', sim_WP_ADDONS_PATH.'/'.sim_WP_ADDONS_PLATFORM_DIR );
	define('sim_WP_ADDONS_PLATFORM_BASE', sim_WP_ADDONS_BASE.'/'.sim_WP_ADDONS_PLATFORM_DIR );
	define('sim_WP_ADDONS_PLATFORM_FILE', sim_WP_ADDONS_PLATFORM_PATH.'/'.sim_WP_ADDONS_PLATFORM_DIR.'.php');
	
}?>